﻿using System;
using System.Runtime.InteropServices;

namespace DLS {
    public class Chunk {
        public Chunk(IntPtr ptr) {
            var riffId = Marshal.PtrToStringAnsi(ptr, 4);
            var riffSize = Marshal.PtrToStructure<uint>(ptr + 4);
            var fileType = Marshal.PtrToStringAnsi(ptr + 8, 4);
            if ("RIFF" == riffId && CheckFileType(fileType, riffSize)) {
                loop(ptr + 12, riffSize - 4);
            }
        }

        public Chunk(IntPtr ptr, uint size) {
            loop(ptr, size);
        }

        private void loop(IntPtr ptr, uint size) {
            uint pos = 0;
            while (pos < size) {
                var chunkId = Marshal.PtrToStringAnsi(ptr, 4);
                var chunkSize = Marshal.PtrToStructure<uint>(ptr + 4);
                ptr += 8;
                pos += 8;
                if (0 == chunkSize) {
                    break;
                }

                if ("LIST" == chunkId) {
                    var listType = Marshal.PtrToStringAnsi(ptr, 4);
                    if ("INFO" == listType) {
                        infoLoop(ptr + 4, chunkSize - 4);
                    } else {
                        LoadList(ptr + 4, listType, chunkSize - 4);
                    }
                } else {
                    LoadChunk(ptr, chunkId, chunkSize);
                }

                ptr += (int)chunkSize;
                pos += chunkSize;
            }
        }

        private void infoLoop(IntPtr ptr, uint size) {
            uint pos = 0;
            while (pos < size) {
                var infoType = Marshal.PtrToStringAnsi(ptr, 4);
                var infoSize = Marshal.PtrToStructure<uint>(ptr + 4);
                ptr += 8;
                pos += 8;
                if (0 == infoSize) {
                    break;
                }

                LoadInfo(ptr, infoType, infoSize);

                ptr += (int)infoSize;
                pos += infoSize;
            }
        }

        public virtual bool CheckFileType(string fileType, uint fileSize) { return false; }
        public virtual void LoadChunk(IntPtr ptr, string chunkType, uint chunkSize) { }
        public virtual void LoadList(IntPtr ptr, string listType, uint listSize) { }
        public virtual void LoadInfo(IntPtr ptr, string infoType, uint infoSize) { }
    }
}
