﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;

namespace MIDI {
    public enum E_KEY_STATE : byte {
        STANDBY,
        PRESS,
        RELEASE,
        HOLD,
        PURGE
    }

    [StructLayout(LayoutKind.Sequential, Pack = 4)]
    public struct INST_ID {
        public bool isDrum;
        public byte bankMSB;
        public byte bankLSB;
        public byte program;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 4)]
    public struct ENVELOPE {
        public double attack;
        public double decay;
        public double release;
        public double susteain;
        public double holdTime;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 4)]
    public struct SAMPLER_INFO {
        public IntPtr      pWave;
        public E_KEY_STATE state;
        public byte   chNo;
        public byte   noteNo;
        public byte   loopEnable;
        public uint   loopBegin;
        public uint   loopLength;
        public double delta;
        public double gain;
        public double amp;
        public ENVELOPE env;
    };
}
