﻿using System;
using System.IO;
using System.Runtime.InteropServices;

namespace DLS {
    public class DlsFile {
        private IntPtr mBuff;

        public DlsFile(string path) {
            var fs = new FileStream(path, FileMode.Open);
            var buff = new byte[fs.Length];
            mBuff = Marshal.AllocHGlobal((int)fs.Length);
            fs.Read(buff, 0, (int)fs.Length);
            Marshal.Copy(buff, 0, mBuff, (int)fs.Length);
            fs.Close();
            fs.Dispose();
            var tes = new DLS(mBuff);
        }
    }

    public class DLS : Chunk {
        public LINS mLins;

        public DLS(IntPtr ptr) : base(ptr) { }

        public override bool CheckFileType(string fileType, uint fileSize) {
            return "DLS " == fileType;
        }

        public override void LoadList(IntPtr ptr, string listType, uint listSize) {
            switch (listType) {
            case "lins":
                mLins = new LINS(ptr, listSize);
                break;
            case "wvpl":
                break;
            default:
                break;
            }
        }
    }

}