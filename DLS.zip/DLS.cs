﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using MIDI;

namespace DLS {
    #region enum
    public enum CC_TYPE : ushort {
        NONE = 0x0000,
        CC1  = 0x0081,
        CC7  = 0x0087,
        CC10 = 0x008A,
        CC11 = 0x008B,
        CC91 = 0x00DB,
        CC93 = 0x00DD
    }

    public enum SRC_TYPE : ushort {
        NONE             = 0x0000,
        LFO              = 0x0001,
        KEY_ON_VELOCITY  = 0x0002,
        KEY_NUMBER       = 0x0003,
        EG1              = 0x0004,
        EG2              = 0x0005,
        PITCH_WHEEL      = 0x0006,
        POLY_PRESSURE    = 0x0007,
        CHANNEL_PRESSURE = 0x0008,
        VIBRATO          = 0x0009,

        // REGISTERED PARAMETER NUMBERS
        RPN0 = 0x0100,
        RPN1 = 0x0101,
        RPN2 = 0x0102
    };

    public enum DST_TYPE : ushort {
        // GENERIC DESTINATIONS
        NONE        = 0x0000,
        ATTENUATION = 0x0001,
        RESERVED    = 0x0002,
        PITCH       = 0x0003,
        PAN         = 0x0004,
        KEY_NUMBER  = 0x0005,

        // CHANNEL OUTPUT DESTINATIONS
        LEFT         = 0x0010,
        RIGHT        = 0x0011,
        CENTER       = 0x0012,
        LFET_CHANNEL = 0x0013,
        LEFT_REAR    = 0x0014,
        RIGHT_REAR   = 0x0015,
        CHORUS       = 0x0080,
        REVERB       = 0x0081,

        // MODULATOR LFO DESTINATIONS
        LFO_FREQUENCY   = 0x0104,
        LFO_START_DELAY = 0x0105,

        // VIBRATO LFO DESTINATIONS
        VIB_FREQUENCY   = 0x0114,
        VIB_START_DELAY = 0x0115,

        // EG1 DESTINATIONS
        EG1_ATTACK_TIME   = 0x0206,
        EG1_DECAY_TIME    = 0x0207,
        EG1_RESERVED      = 0x0208,
        EG1_RELEASE_TIME  = 0x0209,
        EG1_SUSTAIN_LEVEL = 0x020A,
        EG1_DELAY_TIME    = 0x020B,
        EG1_HOLD_TIME     = 0x020C,
        EG1_SHUTDOWN_TIME = 0x020D,

        // EG2 DESTINATIONS
        EG2_ATTACK_TIME   = 0x030A,
        EG2_DECAY_TIME    = 0x030B,
        EG2_RESERVED      = 0x030C,
        EG2_RELEASE_TIME  = 0x030D,
        EG2_SUSTAIN_LEVEL = 0x030E,
        EG2_DELAY_TIME    = 0x030F,
        EG2_HOLD_TIME     = 0x0310,

        // FILTER DESTINATIONS
        FILTER_CUTOFF = 0x0500,
        FILTER_Q      = 0x0501
    };

    public enum TRN_TYPE : ushort {
        NONE    = 0x0000,
        CONCAVE = 0x0001,
        CONVEX  = 0x0002,
        SWITCH  = 0x0003
    };
    #endregion

    #region struct
    [StructLayout(LayoutKind.Sequential, Pack = 4)]
    public struct MIDI_LOCALE {
        public  byte bankLSB;
        public  byte bankMSB;
        private byte reserve1;
        public  byte bankFlags;
        public  byte programNo;
        private byte reserve2;
        private byte reserve3;
        private byte reserve4;
    };

    [StructLayout(LayoutKind.Sequential, Pack = 4)]
    public struct RANGE {
        public ushort low;
        public ushort high;
    };

    [StructLayout(LayoutKind.Sequential, Pack = 4)]
    public struct WAVE_LOOP {
        public uint size;
        public uint type;
        public uint start;
        public uint length;
    };

    [StructLayout(LayoutKind.Sequential, Pack = 4)]
    public struct CONNECTION {
        public SRC_TYPE source;
        public CC_TYPE  control;
        public DST_TYPE destination;
        public TRN_TYPE transform;
        public int      scale;
    };

    [StructLayout(LayoutKind.Sequential, Pack = 4)]
    public struct CK_INSH {
        public uint regions;
        public MIDI_LOCALE locale;
    };

    [StructLayout(LayoutKind.Sequential, Pack = 4)]
    public struct CK_WLNK {
        public ushort options;
        public ushort phaseGroup;
        public uint   channel;
        public uint   tableIndex;
    };

    [StructLayout(LayoutKind.Sequential, Pack = 4)]
    public struct CK_RGNH {
        public RANGE  key;
        public RANGE  velocity;
        public ushort options;
        public ushort keyGroup;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 2)]
    public struct CK_RGH2 {
        public RANGE  key;
        public RANGE  velocity;
        public ushort options;
        public ushort keyGroup;
        public ushort layer;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 4)]
    public struct CK_WSMP {
        public uint   size;
        public ushort unityNote;
        public short  fineTune;
        public int    gain;
        public uint   options;

        public double Gain {
            get { return Math.Pow(10.0, gain / (200 * 65536.0)); }
        }
    }

    [StructLayout(LayoutKind.Sequential, Pack = 4)]
    public struct CK_FMT {
        public ushort tag;
        public ushort channels;
        public uint   sampleRate;
        public uint   bytesPerSec;
        public ushort bytesPerSample;
        public ushort bits;
    };
    #endregion

    public class DLS : RiffChunk {
        private string mPath;
        private IntPtr mpFile;
        private LINS mLins;
        private WVPL mWvpl;

        public uint[] WaveOffets { get; private set; }

        public uint SampleRate = 44100;

        public DLS(string path) : base() {
            mPath = path;
            mpFile = Load(path);
        }

        ~DLS() {
            Marshal.FreeHGlobal(mpFile);
        }

        public INS_ GetInst(INST_ID id) {
            return mLins.Instruments[id];
        }

        public void GetSmplInfo(ref SAMPLER_INFO smpl, INS_ ins, byte noteNo, byte velocity) {
            RGN_ rgn = null;
            foreach (var tmpRgn in ins.Lrgn.Regions) {
                if (tmpRgn.Rgnh.key.low <= noteNo && noteNo <= tmpRgn.Rgnh.key.high
                    && tmpRgn.Rgnh.velocity.low <= velocity && velocity <= tmpRgn.Rgnh.velocity.high) {
                    rgn = tmpRgn;
                    break;
                }
            }

            if (null == rgn) {
                return;
            }

            var wave = mWvpl.Waves[(int)rgn.Wlnk.tableIndex];
            var wsmp = wave.Wsmp;
            var fmt = wave.Fmt;
            smpl.noteNo = noteNo;
            smpl.pWave = wave.pData;
            smpl.delta = (double)fmt.sampleRate / SampleRate / SampleRate
                * Math.Pow(2.0, (noteNo - wsmp.unityNote) / 12.0 + wsmp.fineTune / 1200.0);

            smpl.gain = velocity * wsmp.Gain / 127.0;
            if (wave.EnableLoop) {
                smpl.loopEnable = 1;
                smpl.loopBegin = wave.Loops[0].start;
                smpl.loopLength = wave.Loops[0].length;
            } else {
                smpl.loopEnable = 0;
                smpl.loopBegin = 0;
                smpl.loopLength = wave.DataSize / fmt.bytesPerSample;
            }

            smpl.amp = 0.0;

            if (ins.EnableArt) {
                smpl.env = ins.Lart.Art1.Envelope;
            } else {
                smpl.env = rgn.Lart.Art1.Envelope;
            }

            smpl.state = E_KEY_STATE.PRESS;
        }

        protected override bool CheckFileType(string fileType, uint fileSize) {
            return "DLS " == fileType;
        }

        protected override void LoadList(IntPtr ptr, string listType, uint listSize) {
            switch (listType) {
            case "lins":
                mLins = new LINS(ptr, listSize);
                break;
            case "wvpl":
                mWvpl = new WVPL(ptr, listSize);
                break;
            default:
                break;
            }
        }

        protected override void LoadChunk(IntPtr ptr, string chunkType, uint chunkSize) {
            switch (chunkType) {
            case "ptbl":
                ptr += 4;
                WaveOffets = new uint[Marshal.PtrToStructure<uint>(ptr)];
                ptr += 4;
                for(var i=0; i< WaveOffets.Length; i++) {
                    WaveOffets[i] = Marshal.PtrToStructure<uint>(ptr);
                    ptr += 4;
                }
                break;
            default:
                break;
            }
        }
    }

    public class LINS : RiffChunk {
        public Dictionary<INST_ID, INS_> Instruments = new Dictionary<INST_ID, INS_>();

        public LINS(IntPtr ptr, uint size) : base(ptr, size) { }

        protected override void LoadList(IntPtr ptr, string listType, uint listSize) {
            switch (listType) {
            case "ins ":
                var temp = new INS_(ptr, listSize);
                var id = new INST_ID();
                id.isDrum = 0 < (temp.Insh.locale.bankFlags & 0x80);
                id.bankMSB = temp.Insh.locale.bankMSB;
                id.bankLSB = temp.Insh.locale.bankLSB;
                id.program = temp.Insh.locale.programNo;
                Instruments.Add(id, temp);
                break;
            default:
                break;
            }
        }
    }

    public class INS_ : RiffChunk {
        public string Name { get; private set; }
        public CK_INSH Insh { get; private set; }
        public bool EnableArt { get; private set; }

        public LRGN Lrgn;
        public LART Lart;

        public INS_(IntPtr ptr, uint size) : base(ptr, size) { }

        protected override void LoadChunk(IntPtr ptr, string chunkType, uint chunkSize) {
            switch (chunkType) {
            case "insh":
                Insh = Marshal.PtrToStructure<CK_INSH>(ptr);
                break;
            default:
                break;
            }
        }

        protected override void LoadList(IntPtr ptr, string listType, uint listSize) {
            switch (listType) {
            case "lrgn":
                Lrgn = new LRGN(ptr, listSize);
                break;
            case "lart":
                Lart = new LART(ptr, listSize);
                EnableArt = true;
                break;
            default:
                break;
            }
        }

        protected override void LoadInfo(IntPtr ptr, string infoType, uint infoSize) {
            switch (infoType) {
            case "INAM":
                Name = Marshal.PtrToStringAnsi(ptr).TrimEnd();
                break;
            default:
                break;
            }
        }
    }

    public class LRGN : RiffChunk {
        public List<RGN_> Regions = new List<RGN_>();

        public LRGN(IntPtr ptr, uint size) : base(ptr, size) { }

        protected override void LoadList(IntPtr ptr, string listType, uint listSize) {
            switch (listType) {
            case "rgn ":
                Regions.Add(new RGN_(ptr, listSize));
                break;
            default:
                break;
            }
        }
    }

    public class RGN_ : RiffChunk {
        public CK_RGH2 Rgnh { get; private set; }
        public CK_WLNK Wlnk { get; private set; }
        public CK_WSMP Wsmp { get; private set; }
        public WAVE_LOOP[] Loops { get; private set; }

        public bool EnableLoop { get; private set; }
        public bool EnableArt { get; private set; }

        public LART Lart;

        public RGN_(IntPtr ptr, uint size) : base(ptr, size) { }

        protected override void LoadChunk(IntPtr ptr, string chunkType, uint chunkSize) {
            switch (chunkType) {
            case "rgnh":
                if (14 == chunkSize) {
                    Rgnh = Marshal.PtrToStructure<CK_RGH2>(ptr);
                } else {
                    var rgnh = Marshal.PtrToStructure<CK_RGNH>(ptr);
                    var temp = new CK_RGH2();
                    temp.key      = rgnh.key;
                    temp.velocity = rgnh.velocity;
                    temp.options  = rgnh.options;
                    temp.keyGroup = rgnh.keyGroup;
                    temp.layer    = 0;
                    Rgnh = temp;
                }
                break;
            case "wlnk":
                Wlnk = Marshal.PtrToStructure<CK_WLNK>(ptr);
                break;
            case "wsmp":
                Wsmp = Marshal.PtrToStructure<CK_WSMP>(ptr);
                ptr += Marshal.SizeOf<CK_WSMP>();
                Loops = new WAVE_LOOP[Marshal.PtrToStructure<uint>(ptr)];
                EnableLoop = 0 < Loops.Length;
                ptr += 4;
                for (var i = 0; i < Loops.Length; i++) {
                    Loops[i] = Marshal.PtrToStructure<WAVE_LOOP>(ptr);
                    ptr += Marshal.SizeOf<WAVE_LOOP>();
                }
                break;
            default:
                break;
            }
        }

        protected override void LoadList(IntPtr ptr, string listType, uint listSize) {
            switch (listType) {
            case "lart":
                Lart = new LART(ptr, listSize);
                EnableArt = true;
                break;
            default:
                break;
            }
        }
    }

    public class LART : RiffChunk {
        public ART1 Art1;

        public LART(IntPtr ptr, uint size) : base(ptr, size) { }

        protected override void LoadChunk(IntPtr ptr, string chunkType, uint chunkSize) {
            switch (chunkType) {
            case "art1":
                Art1 = new ART1(ptr, chunkSize);
                break;
            default:
                break;
            }
        }
    }

    public class ART1 {
        public ENVELOPE Envelope;

        public ART1(IntPtr ptr, uint size) {
            ptr += 4;
            var values = Marshal.PtrToStructure<uint>(ptr);
            ptr += 4;

            Envelope.attack = 6000.0;    // 1msec
            Envelope.decay = 6.0 / 10.0; // 10sec
            Envelope.release = 6000.0;   // 1msec
            Envelope.susteain = 0.0;
            Envelope.holdTime = 0.0;

            for (var i = 0; i < values; i++) {
                var value = GetValue(Marshal.PtrToStructure<CONNECTION>(ptr));
                ptr += Marshal.SizeOf<CONNECTION>();

                if (SRC_TYPE.NONE != value.Item1) {
                    continue;
                }
                switch (value.Item3) {
                case DST_TYPE.EG1_ATTACK_TIME:
                    Envelope.attack = 6000.0 / value.Item4;
                    break;
                case DST_TYPE.EG1_DECAY_TIME:
                    Envelope.decay = 6000.0 / value.Item4;
                    break;
                case DST_TYPE.EG1_HOLD_TIME:
                    Envelope.holdTime = value.Item4;
                    break;
                case DST_TYPE.EG1_RELEASE_TIME:
                    Envelope.release = 6000.0 / value.Item4;
                    break;
                case DST_TYPE.EG1_SUSTAIN_LEVEL:
                    Envelope.susteain = value.Item4 * 0.01;
                    break;
                default:
                    break;
                }
            }
            Envelope.holdTime += 6000.0 / Envelope.attack;
        }

        private Tuple<SRC_TYPE, CC_TYPE, DST_TYPE, double> GetValue(CONNECTION conn) {
            switch (conn.destination) {
            case DST_TYPE.ATTENUATION:
            case DST_TYPE.FILTER_Q:
                return new Tuple<SRC_TYPE, CC_TYPE, DST_TYPE, double>(
                    conn.source, conn.control, conn.destination,
                    Math.Pow(10.0, conn.scale / (200 * 65536.0)));
            case DST_TYPE.PAN:
                return new Tuple<SRC_TYPE, CC_TYPE, DST_TYPE, double>(
                    conn.source, conn.control, conn.destination,
                    (conn.scale / 655360.0) - 0.5);
            case DST_TYPE.LFO_START_DELAY:
            case DST_TYPE.VIB_START_DELAY:
            case DST_TYPE.EG1_ATTACK_TIME:
            case DST_TYPE.EG1_DECAY_TIME:
            case DST_TYPE.EG1_RELEASE_TIME:
            case DST_TYPE.EG1_DELAY_TIME:
            case DST_TYPE.EG1_HOLD_TIME:
            case DST_TYPE.EG1_SHUTDOWN_TIME:
            case DST_TYPE.EG2_ATTACK_TIME:
            case DST_TYPE.EG2_DECAY_TIME:
            case DST_TYPE.EG2_RELEASE_TIME:
            case DST_TYPE.EG2_DELAY_TIME:
            case DST_TYPE.EG2_HOLD_TIME:
                return new Tuple<SRC_TYPE, CC_TYPE, DST_TYPE, double>(
                    conn.source, conn.control, conn.destination,
                    (conn.scale == int.MinValue) ? 1.0 : Math.Pow(2.0, conn.scale / (1200 * 65536.0)));
            case DST_TYPE.EG1_SUSTAIN_LEVEL:
            case DST_TYPE.EG2_SUSTAIN_LEVEL:
                return new Tuple<SRC_TYPE, CC_TYPE, DST_TYPE, double>(
                    conn.source, conn.control, conn.destination, conn.scale / 655360.0);
            case DST_TYPE.PITCH:
            case DST_TYPE.LFO_FREQUENCY:
            case DST_TYPE.VIB_FREQUENCY:
            case DST_TYPE.FILTER_CUTOFF:
                return new Tuple<SRC_TYPE, CC_TYPE, DST_TYPE, double>(
                    conn.source, conn.control, conn.destination,
                    Math.Pow(2.0, (conn.scale / 65536.0 - 6900) / 1200.0) * 440);
            default:
                return new Tuple<SRC_TYPE, CC_TYPE, DST_TYPE, double>(
                    conn.source, conn.control, conn.destination, 0.0);
            }
        }
    }

    public class WVPL : RiffChunk {
        public List<WAVE> Waves = new List<WAVE>();

        public WVPL(IntPtr ptr, uint size) : base(ptr, size) { }

        protected override void LoadList(IntPtr ptr, string listType, uint listSize) {
            switch (listType) {
            case "wave":
                Waves.Add(new WAVE(ptr, listSize));
                break;
            default:
                break;
            }
        }
    }

    public class WAVE : RiffChunk {
        public CK_FMT Fmt { get; private set; }
        public CK_WSMP Wsmp { get; private set; }
        public IntPtr pData { get; private set; }
        public WAVE_LOOP[] Loops { get; private set; }

        public uint DataSize { get; private set; }
        public bool EnableLoop { get; private set; }

        public WAVE(IntPtr ptr, uint size) : base(ptr, size) { }

        protected override void LoadChunk(IntPtr ptr, string chunkType, uint chunkSize) {
            switch (chunkType) {
            case "fmt ":
                Fmt = Marshal.PtrToStructure<CK_FMT>(ptr);
                break;
            case "data":
                pData = ptr;
                DataSize = chunkSize;
                break;
            case "wsmp":
                Wsmp = Marshal.PtrToStructure<CK_WSMP>(ptr);
                ptr += Marshal.SizeOf<CK_WSMP>();
                Loops = new WAVE_LOOP[Marshal.PtrToStructure<uint>(ptr)];
                EnableLoop = 0 < Loops.Length;
                ptr += 4;
                for (var i = 0; i < Loops.Length; i++) {
                    Loops[i] = Marshal.PtrToStructure<WAVE_LOOP>(ptr);
                    ptr += Marshal.SizeOf<WAVE_LOOP>();
                }
                break;
            default:
                break;
            }
        }
    }
}
