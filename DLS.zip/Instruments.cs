﻿using System;
using System.Collections.Generic;

namespace DLS {
    public class LINS : Chunk {
        public List<INS_> mInsList = new List<INS_>();

        public LINS(IntPtr ptr, uint size) : base(ptr, size) { }

        public override void LoadList(IntPtr ptr, string listType, uint listSize) {
            switch (listType) {
            case "ins ":
                mInsList.Add(new INS_(ptr, listSize));
                break;
            default:
                break;
            }
        }
    }

    public class INS_ : Chunk {
        public INS_(IntPtr ptr, uint size) : base(ptr, size) { }

        public override void LoadChunk(IntPtr ptr, string chunkType, uint chunkSize) {
            switch (chunkType) {
            case "insh":
                break;
            default:
                break;
            }
        }

        public override void LoadList(IntPtr ptr, string listType, uint listSize) {
            switch (listType) {
            case "lrgn":
                break;
            case "lart":
                break;
            default:
                break;
            }
        }
    }
}
