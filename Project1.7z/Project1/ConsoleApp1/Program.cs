﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace ConsoleApp1 {
    public class Haffman {
        // ノードクラス
        public class Node {
            public byte IsLeaf;
            public byte Value;
            public int Frequency;
            public Node Left = null;
            public Node Right = null;
        }

        // バイトごとの出現回数を計算
        private int[] GetFrequency(byte[] bytes, ref int[] freq) {
            foreach (var b in bytes) {
                ++freq[b];
            }
            return freq;
        }

        // ハフマンツリー生成
        private Node GenerateHaffmanTree(int[] freq) {
            var nodeList = new List<Node>();
            for (int i = 0; i < 256; ++i) {
                if (freq[i] == 0) {
                    continue;
                }
                var node = new Node();
                node.IsLeaf = 1;
                node.Value = (byte)i;
                node.Frequency = freq[i];
                node.Left = null;
                node.Right = null;
                nodeList.Add(node);
            }

            // 残り1つになるまで処理をする
            while (1 < nodeList.Count) {
                // 先頭に最小値が来るようにソートする
                // ソートではなく2分ヒープを使うほうが効率的
                nodeList = nodeList.OrderBy(e => e.Frequency).ToList();

                // 出現頻度が最小値のノード2つを取り出す
                var left = nodeList[0];
                var right = nodeList[1];
                nodeList.RemoveAt(0);
                nodeList.RemoveAt(0);

                // 左右の出現頻度の和を持つノードを生成しキューに追加
                var node = new Node();
                node.IsLeaf = 0;
                node.Value = 0;
                node.Frequency = left.Frequency + right.Frequency;
                node.Left = left;
                node.Right = right;
                nodeList.Add(node);
            }

            // キューに残っているノードがハフマンツリーのルートノード
            var root = nodeList[0];

            // 1種類のデータしか出現しない場合はダミーノードを用意
            if (1 == root.IsLeaf) {
                var dummy = new Node();
                dummy.IsLeaf = 0;
                dummy.Value = 0;
                dummy.Frequency = root.Frequency + root.Frequency;
                dummy.Left = root;
                dummy.Right = root;
                return dummy;
            }
            return root;
        }

        // 圧縮用ハフマンコード表生成
        private byte[][] GetHaffmanCodeTable(Node node) {
            var dict = new byte[256][];
            for (int i = 0; i < 256; i++) {
                var b = (byte)i;
                dict[b] = GenerateHaffmanCode(node, b);
            }
            return dict;
        }

        // 指定データについてのハフマンコード生成
        private byte[] GenerateHaffmanCode(Node node, byte symbol, List<byte> bits = null) {
            if (null == bits) {
                bits = new List<byte>();
            }
            if (1 == node.IsLeaf && (node.Value == symbol)) {
                // 葉ノードでデータが一致する場合
                return bits.ToArray();
            }
            if (null != node.Left) {
                // 左の子ノードがある場合、false(0) を追加して再帰呼び出し
                bits.Add(0);
                var result = GenerateHaffmanCode(node.Left, symbol, bits);
                if (null != result) {
                    return result;
                }
                // 左の子ノードに見つからなかった場合、追加したデータを取消
                bits.RemoveAt(bits.Count - 1);
            }
            if (null != node.Right) {
                // 右の子ノードがある場合、true(1) を追加して再帰呼び出し
                bits.Add(1);
                var result = GenerateHaffmanCode(node.Right, symbol, bits);
                if (null != result) {
                    return result;
                }
                // 右の子ノードに見つからなかった場合、追加したデータを取消
                bits.RemoveAt(bits.Count - 1);
            }
            return null; // 葉ノードで見つからなかった場合
        }

        // ハフマンツリー自体をビット化
        private byte[] ConvertHaffmanTreeToBits(Node root) {
            var bits = new List<byte>();

            // スタックを使って深さ優先探索
            var stack = new Stack<Node>();
            stack.Push(root);

            while (0 < stack.Count) {
                var node = stack.Pop();
                if (1 == node.IsLeaf) {
                    // 葉ノードは true 出力
                    bits.Add(1);
                    // 実データ 8bit 出力
                    for (int i = 0; i < 8; i++) {
                        bits.Add((byte)(node.Value >> 7 - i & 1));
                    }
                }
                else {
                    // 葉ノードではないので false 出力
                    bits.Add(0);
                    // 左から優先的に走査したいので右から積む
                    if (node.Right != null) {
                        stack.Push(node.Right);
                    }
                    if (node.Left != null) {
                        stack.Push(node.Left);
                    }
                }
            }
            return bits.ToArray();
        }

        // ハフマンツリーを再構成
        private Node RegenerateHaffmanTree(ref IEnumerable<byte> bits) {
            if (1 == bits.First()) {
                var symbol = (byte)
                    ( bits.ElementAt(1) << 7
                    | bits.ElementAt(2) << 6
                    | bits.ElementAt(3) << 5
                    | bits.ElementAt(4) << 4
                    | bits.ElementAt(5) << 3
                    | bits.ElementAt(6) << 2
                    | bits.ElementAt(7) << 1
                    | bits.ElementAt(8));
                bits = bits.Skip(9); // 葉ノードフラグとデータ分読み飛ばし
                var node = new Node() { Value = symbol, IsLeaf = 1 };
                return node;
            }
            else {
                bits = bits.Skip(1); // 葉ノードフラグ読み飛ばし
                var left = RegenerateHaffmanTree(ref bits);
                var right = RegenerateHaffmanTree(ref bits);
                var node = new Node();
                node.IsLeaf = 0;
                node.Value = 0;
                node.Frequency = left.Frequency + right.Frequency;
                node.Left = left;
                node.Right = right;
                return node;
            }
        }

        // すべてのビットデータとして列挙
        private List<byte> GetAllBytes(byte[] treeBits, IEnumerable<byte[]> codes) {
            int i = 0;
            byte result = 0;
            List<byte> temp = new List<byte>();

            foreach (var bit in treeBits) {
                // 指定桁数について1を立てる
                if (1 == bit) {
                    result |= (byte)(1 << 7 - i);
                }
                if (i == 7) {
                    // 1バイト分で出力しビットカウント初期化
                    temp.Add(result);
                    i = 0;
                    result = 0;
                }
                else {
                    i++;
                }
            }

            foreach (var bits in codes) {
                foreach (var bit in bits) {
                    // 指定桁数について1を立てる
                    if (1 == bit) {
                        result |= (byte)(1 << 7 - i);
                    }
                    if (i == 7) {
                        // 1バイト分で出力しビットカウント初期化
                        temp.Add(result);
                        i = 0;
                        result = 0;
                    }
                    else {
                        i++;
                    }
                }
            }

            // 8ビットに足りない部分も出力
            if (i != 0) {
                temp.Add(result);
            }

            return temp;
        }

        // 圧縮
        public void Encode(string inputFile, string outputFile) {
            // ファイル読み込み
            var inputBytes = File.ReadAllBytes(inputFile);
            // 出現回数(頻度)を計算
            var freq = new int[256];
            GetFrequency(inputBytes, ref freq);

            // ハフマンツリー生成
            var root = GenerateHaffmanTree(freq);
            //DebugHaffmanTree(root, 0, "");

            // ハフマンコード表生成
            var haffmanDict = GetHaffmanCodeTable(root);
            DebugHaffmanTable(haffmanDict);

            // 書き込み対象のファイル
            using (var writer = new BinaryWriter(File.OpenWrite(outputFile))) {
                // 圧縮前のファイルサイズ(バイト単位)出力
                var size = BitConverter.GetBytes(inputBytes.Count());
                writer.Write(size);
                // ハフマンツリー自体をビット化(連結のための型にキャスト)
                IEnumerable<byte> treeBits = ConvertHaffmanTreeToBits(root);
                // ハフマン符号化したデータ
                var haffmanCodes = inputBytes.Select(b => {
                    return haffmanDict[b];
                });
                // 書き込む全ビットデータからバイトデータ取得
                var allByte = GetAllBytes(treeBits.ToArray(), haffmanCodes);
                //writer.Write(allByte.ToArray());
                foreach (var bt in allByte) {
                    writer.Write(bt); // 1Byte毎の書き込みの方が速かった
                }
            }
        }

        // 復号
        public void Decode(string inputFile, string outputFile) {
            // ファイル読み込む(4バイト分とばしてビット化)
            var inputBytes = File.ReadAllBytes(inputFile);
            var bits = inputBytes.Skip(4).BytesToBits();

            // 圧縮前ファイルサイズ
            int size = BitConverter.ToInt32(inputBytes.Take(4).ToArray(), 0);

            // ハフマンツリーの再構成
            var root = RegenerateHaffmanTree(ref bits);

            //DebugHaffmanTree(root, 0, "");
            // 圧縮前のファイルサイズ分バイトデータ書き込み
            using (var writer = new BinaryWriter(File.OpenWrite(outputFile))) {
                int counter = 0;
                var node = root;
                foreach (var bit in bits.ToArray()) {
                    if (1 == node.IsLeaf) {
                        // 見つかったらデータを出力し、ルートに戻す
                        writer.Write(node.Value);
                        ++counter;
                        node = root;
                        if (size <= counter) {
                            break;
                        }
                    }
                    if (0 == node.IsLeaf) {
                        // 葉ノードに到達するまで探す
                        if (1 == bit) {
                            node = node.Right;
                        }
                        else {
                            node = node.Left;
                        }
                    }
                }
            }
        }

        // 動作確認用処理
        private void DebugHaffmanTable(byte[][] table) {
            Console.WriteLine();
            Console.WriteLine($"DebugHaffmanTable");
            for (int i = 0; i < 256; i++) {
                if (table[(byte)i] != null) {
                    var code = table[(byte)i].Select(b => (1 == b) ? '1' : '0').ToArray();
                    Console.WriteLine($"{i.ToString("X2")}: {new string(code)}");
                }
            }
        }

        private void DebugHaffmanTree(Node node, int indent, string bitCode) {
            if (indent == 0) {
                Console.WriteLine();
                Console.WriteLine("DebugHaffmanTree");
            }
            var bits = new List<bool>();
            bits.AddRange(bits);

            int indent_ = indent > 0 ? indent - 1 : 0;
            var indentStr = new string(' ', 2 * indent_) + "  --";

            if (1 == node.IsLeaf) {
                Console.WriteLine(indentStr + $"{node.Value.ToString("X2")}({bitCode})");
            }
            else {
                Console.WriteLine(indentStr + $"");
                if (node.Left != null) {
                    DebugHaffmanTree(node.Left, indent + 1, bitCode + "0");
                }
                if (node.Right != null) {
                    DebugHaffmanTree(node.Right, indent + 1, bitCode + "1");
                }
            }
        }

        public void DebugString(string str) {
            var bytes = Encoding.ASCII.GetBytes(str);
            var freq = new int[256];
            GetFrequency(bytes, ref freq);
            var root = GenerateHaffmanTree(freq);
            DebugHaffmanTree(root, 0, "");
            var table = GetHaffmanCodeTable(root);
            DebugHaffmanTable(table);
        }
    }

    public static class Extentions {
        public static IEnumerable<byte> BytesToBits(this IEnumerable<byte> bytes) {
            foreach (var bt in bytes) {
                for (int i = 7; 0 <= i; --i) {
                    yield return (byte)((bt >> i) & 1);
                }
            }
        }
    }

    class Program {
        static void Main(string[] args) {
            if (args.Length < 1 || !File.Exists(args[0])) {
                return;
            }

            var e = new Haffman();
            //e.Encode(args[0], args[0] + "_encS.bin");
            e.Decode(args[0] + "_enc.bin", args[0] + "_dec.txt");
        }
    }
}
