#include <stdio.h>
#include "haffman_enc.h"
#include "haffman_dec.h"

int main(int argv, char* args[]) {
    if (argv < 2) {
        return 0;
    }

    char inPath[256] = { 0 };
    char outPath[256] = { 0 };
    char mode = 0;

    printf("press c or u key\nc:compress\nu:uncompress\n");
    scanf_s("%c", &mode);

    if ('c' == mode) {
        sprintf_s(inPath, "%s", args[1]);
        sprintf_s(outPath, "%s_enc.bin", args[1]);
        HaffmanEnc *enc = new HaffmanEnc();
        enc->Exec(inPath, outPath);
    }
    if ('u' == mode) {
        sprintf_s(inPath, "%s_enc.bin", args[1]);
        sprintf_s(outPath, "%s_dec.bin", args[1]);
        HaffmanDec *dec = new HaffmanDec();
        dec->Exec(inPath, outPath);
    }
    return 0;
}
