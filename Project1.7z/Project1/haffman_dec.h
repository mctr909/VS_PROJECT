#pragma once
typedef unsigned char byte;
typedef unsigned int uint;

class HaffmanDec {
public:
    class Node {
    public:
        byte isLeaf;
        byte value;
        Node *left;
        Node *right;
    };

private:
    //===========================================================================//
    // private�ϐ�
    //===========================================================================//
    byte *mBuff;
    int mBuffSize;
    int mCurBuffPos;
    int mCurBuffBit;

    uint mTempBits;
    int mTempBitSize;

public:
    //===========================================================================//
    // public���\�b�h
    //===========================================================================//
    void Exec(char* inputFile, char* outputFile);

private:
    //===========================================================================//
    // private���\�b�h
    //===========================================================================//
    void GenerateHaffmanTree(Node &node);
    void WriteFile(Node &root, FILE *fp, int uncompressSize);
};
