#pragma once
void searchSW(unsigned int* retIndex, unsigned int* retMatch, char* refStart, char* refEnd, char* encStart, char* encEnd);
unsigned int matchString(char* refStart, char* refEnd, char* encStart, char* encEnd);
unsigned int uncompressLZSS(char* ret, char* src, unsigned int srcSize);
unsigned int compressLZSS(char* ret, char* src, unsigned int srcSize);