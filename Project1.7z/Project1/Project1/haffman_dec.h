#pragma once
#include <queue>

typedef unsigned char byte;

class HaffmanDec {
public:
    class Node {
    public:
        byte IsLeaf;
        byte Value;
        int Frequency;
        Node *Left;
        Node *Right;

        static bool less(Node *v1, Node *v2) {
            if (v1->Frequency < v2->Frequency) {
                return true;
            }
            else {
                return (v1->Frequency < v2->Frequency);
            }
        }
    };

public:
    //===========================================================================//
    // public���\�b�h
    //===========================================================================//
    void Decode(char* inputFile, char* outputFile);

private:
    //===========================================================================//
    // private���\�b�h
    //===========================================================================//
    // �n�t�}���c���[���č\��
    Node RegenerateHaffmanTree(std::queue<byte> &bits);
    //
    void BytesToBits(byte* buff, int size, std::queue<byte> *bits);
};
