#include <stdio.h>
#include "haffman_dec.h"

//void
//HaffmanDec::Decode(char* inputFile, char* outputFile) {
//    //
//    FILE *fp = NULL;
//    fopen_s(&fp, inputFile, "rb");
//
//    // ���k�O�t�@�C���T�C�Y
//    int size;
//    fread_s(&size, sizeof(size), sizeof(size), 1, fp);
//
//    // �o�b�t�@���m��
//    byte *inputBuff = NULL;
//    fseek(fp, 0, SEEK_END);
//    int fileSize = ftell(fp) - 4;
//    inputBuff = (byte*)malloc(fileSize);
//    if (NULL == inputBuff) {
//        if (NULL != fp) {
//            fclose(fp);
//        }
//        return;
//    }
//
//    // �t�@�C���Ǎ�
//    fseek(fp, 4, SEEK_SET);
//    fread_s(inputBuff, fileSize, fileSize, 1, fp);
//
//    //
//    fclose(fp);
//    fp = NULL;
//
//    std::queue<byte> bits;
//    BytesToBits(inputBuff, fileSize, &bits);
//
//    // �n�t�}���c���[�̍č\��
//    Node root = RegenerateHaffmanTree(bits);
//    char debugStr[1024] = { 0 };
//    DebugHaffmanTree(root, 0, debugStr);
//    printf("\n%s", debugStr);
//
//    // ���k�O�̃t�@�C���T�C�Y����������
//    fopen_s(&fp, outputFile, "wb");
//
//    int counter = 0;
//    Node *node = &root;
//    while (0 < bits.size()) {
//        if (1 == node->IsLeaf) {
//            // ����������f�[�^���o�͂��A���[�g�ɖ߂�
//            fwrite(&node->Value, sizeof(node->Value), 1, fp);
//            counter++;
//            node = &root;
//            if (size <= counter) {
//                break;
//            }
//        }
//        else {
//            // �t�m�[�h�ɓ��B����܂ŒT��
//            if (bits.front()) {
//                node = node->Right;
//            }
//            else {
//                node = node->Left;
//            }
//            bits.pop();
//        }
//    }
//
//    //
//    fclose(fp);
//    fp = NULL;
//
//    free(inputBuff);
//}

//HaffmanDec::Node
//HaffmanDec::RegenerateHaffmanTree(std::queue<byte> &bits) {
//    if (1 == bits.front()) {
//        bits.pop(); // �t�m�[�h�t���O�ǔ�
//        Node node;
//        node.Value = 0;
//        node.Value |= bits.front() << 7; bits.pop();
//        node.Value |= bits.front() << 6; bits.pop();
//        node.Value |= bits.front() << 5; bits.pop();
//        node.Value |= bits.front() << 4; bits.pop();
//        node.Value |= bits.front() << 3; bits.pop();
//        node.Value |= bits.front() << 2; bits.pop();
//        node.Value |= bits.front() << 1; bits.pop();
//        node.Value |= bits.front() << 0; bits.pop();
//        node.IsLeaf = 1;
//        node.Frequency = 0;
//        return node;
//    }
//    else {
//        bits.pop(); // �t�m�[�h�t���O�ǔ�
//        Node left = RegenerateHaffmanTree(bits);
//        Node right = RegenerateHaffmanTree(bits);
//        Node node;
//        node.IsLeaf = 0;
//        node.Value = 0;
//        node.Frequency = left.Frequency + right.Frequency;
//        node.Left = &left;
//        node.Right = &right;
//        return node;
//    }
//}

//void
//HaffmanDec::BytesToBits(byte* buff, int size, std::queue<byte> *bits) {
//    for (int i = 0; i < size; ++i) {
//        for (int j = 7; 0 <= j; --j) {
//            bits->push((buff[i] >> j) & 1);
//        }
//    }
//}