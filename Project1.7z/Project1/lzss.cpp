#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "lzss.h"

// 12bit
#define REF_SIZE (4095+3)
// 3bit
#define ENC_SIZE (7+3)

int exec(char* inputPath) {
    FILE *fpIn;
    FILE *fpOut;
    char inPath[256] = { 0 };
    char outPath[256] = { 0 };
    int compresSize = 0;
    int uncompresSize = 0;
    char* src = NULL;
    char* compres = NULL;
    char* uncompres = NULL;

#if 0
    // ���k����t�@�C�����J��
    fopen_s(&fpIn, inputPath, "rb");
    if (NULL == fpIn) {
        printf("file open error!!\n");
        exit(EXIT_FAILURE);
    }
    fseek(fpIn, 0, SEEK_END);
    uncompresSize = ftell(fpIn);
    fseek(fpIn, 0, SEEK_SET);

    // �o�̓t�@�C�����J��
    sprintf_s(outPath, "%s_enc.bin", inputPath);
    fopen_s(&fpOut, outPath, "wb");

    src = (char*)malloc(uncompresSize);
    uncompres = (char*)malloc(uncompresSize);
    compres = (char*)malloc(uncompresSize + (int)ceil((float)uncompresSize*2.0f));
    fread(src, 1, uncompresSize, fpIn);
    fclose(fpIn);
    compresSize = compressLZSS(compres, src, uncompresSize);

    fwrite(&uncompresSize, sizeof(uncompresSize), 1, fpOut);
    fwrite(compres, compresSize, 1, fpOut);
    fclose(fpOut);

    free(uncompres);
    free(src);
    free(compres);
    return EXIT_SUCCESS;
#else
    // �𓀂���t�@�C�����J��
    sprintf_s(inPath, "%s_enc.bin", inputPath);
    fopen_s(&fpIn, inPath, "rb");
    if (NULL == fpIn) {
        printf("file open error!!\n");
        exit(EXIT_FAILURE);
    }
    fread_s(&uncompresSize, sizeof(uncompresSize), sizeof(uncompresSize), 1, fpIn);
    fseek(fpIn, 0, SEEK_END);
    compresSize = ftell(fpIn) - 4;
    fseek(fpIn, 4, SEEK_SET);

    compres = (char*)malloc(compresSize);
    uncompres = (char*)malloc(uncompresSize);
    fread_s(compres, compresSize, compresSize, 1, fpIn);

    // �o�̓t�@�C�����J��
    sprintf_s(outPath, "%s_dec.txt", inputPath);
    fopen_s(&fpOut, outPath, "wb");

    // �𓀌��ʂ�ۑ�
    uncompressLZSS(uncompres, compres, compresSize);
    if (NULL == fpOut) {
        printf("file open error!!\n");
        exit(EXIT_FAILURE);
    }
    fwrite(uncompres, 1, uncompresSize, fpOut);
    fclose(fpOut);

    free(uncompres);
    free(compres);
    return EXIT_SUCCESS;
#endif
}

/**
 * ���������֐�
 * @param {unsigned int*} retIndex �X���C�h�����̌�납�琔����byte��
 * @param {unsigned int*} retMatch ���v����byte��
 * @param {char*} refStart �X���C�h�����J�n�ʒu
 * @param {char*} refEnd �X���C�h�����I���ʒu
 * @param {char*} encStart �G���R�J�n�ʒu
 * @param {char*} encEnd �G���R�I���ʒu
*/
void searchSW(unsigned int* retIndex, unsigned int* retMatch, char* refStart, char* refEnd, char* encStart, char* encEnd) {
    unsigned int match = 0;
    *retIndex = 0;
    *retMatch = 0;
    while (refStart < refEnd) {
        match = matchString(refStart, refEnd, encStart, encEnd);
        if (*retMatch < match) {
            *retMatch = match;
            *retIndex = refEnd - refStart;
        }
        refStart++;
    }
}

/**
 * ���v�������擾
 * @return ���vbyte��
 * @param  {char*} refStart �X���C�h�����J�n�ʒu
 * @param  {char*} refEnd �X���C�h�����I���ʒu
 * @param  {char*} encStart �G���R�J�n�ʒu
 * @param  {char*} encEnd �G���R�I���ʒu
*/
unsigned int matchString(char* refStart, char* refEnd, char* encStart, char* encEnd) {
    int ret = 0;
    while (refStart[ret] == encStart[ret]) {
        if (refEnd <= &refStart[ret]) {
            break;
        }
        if (encEnd <= &encStart[ret]) {
            break;
        }
        ret++;
    }
    return ret;
}

/**
 * ���k
 * @return ���k��T�C�Y
 * @param  {char*} ret ���k��(�������m�ۂ��Ȃ�)
 * @param  {char*} src ���k��
 * @param  {unsigned int} srcSize ���k���T�C�Y
*/
unsigned int compressLZSS(char* ret, char* src, unsigned int srcSize) {
    unsigned int srcIndex = 0;
    unsigned int retIndex = 0;
    unsigned int index = 0;
    unsigned int match = 0;
    unsigned int notMatch = 0;
    char* notMatchStart = NULL;
    char* refStart = NULL;
    char* encEnd = NULL;

    while (srcIndex < srcSize) {
        if (REF_SIZE <= srcIndex) {
            refStart = &src[srcIndex - REF_SIZE];
        }
        else {
            refStart = src;
        }
        if (srcSize - ENC_SIZE <= srcIndex) {
            encEnd = &src[srcSize];
        }
        else {
            encEnd = &src[srcIndex + ENC_SIZE];
        }

        searchSW(&index, &match, refStart, &src[srcIndex], &src[srcIndex], encEnd);

        //���k������Ȃ��ꍇ
        //127byte���Ƃɐ���R�[�h1byte��}��
        //0x80��127byte�܂ł̕�������1byte�ɂ����߂�
        if (match < 3) {
            if (0 == notMatch) {
                notMatchStart = &ret[retIndex];
                retIndex++;
                ret[retIndex] = src[srcIndex];
                retIndex++;
            }
            else if (127 == notMatch) {
                *notMatchStart = 127;
                notMatch = 0;

                notMatchStart = &ret[retIndex];
                retIndex++;
                ret[retIndex] = src[srcIndex];
                retIndex++;
            }
            else {
                ret[retIndex] = src[srcIndex];
                retIndex++;
            }
            notMatch++;
            srcIndex++;
        }
        //���k�ł���ꍇ��2byte��slide window�̈ʒu�ƍ��v���������߂�
        else {
            if (0 < notMatch) {
                *notMatchStart = notMatch;
                notMatch = 0;
            }
            ret[retIndex] = 0x80;
            ret[retIndex] = ret[retIndex] | ((match - 3) << 4);
            ret[retIndex] = ret[retIndex] | (((index - 3) & 0x0F00) >> 8);
            retIndex++;
            ret[retIndex] = (char)((index - 3) & 0x00FF);
            retIndex++;

            srcIndex += match;
        }
    }
    if (0 < notMatch) {
        *notMatchStart = notMatch;
    }
    return retIndex;
}

/**
 * ��
 * @return �𓀌�T�C�Y
 * @param  {char*} ret �𓀐�
 * @param  {char*} src�@���k�t�@�C��
 * @param  {unsigned int} srcSize�@���k�t�@�C���T�C�Y
*/
unsigned int uncompressLZSS(char* ret, char* src, unsigned int srcSize) {
    unsigned int srcIndex = 0;
    unsigned int retIndex = 0;
    unsigned int index = 0;
    unsigned int match = 0;

    while (srcIndex < srcSize) {
        if ((unsigned char)src[srcIndex] <= 127) {
            memcpy(&ret[retIndex], &src[srcIndex + 1], src[srcIndex]);
            retIndex += src[srcIndex];
            srcIndex += (src[srcIndex] + 1);
        }
        else {
            match = ((src[srcIndex] & 0x7F) >> 4) + 3;
            index = (src[srcIndex] & 0x0F) << 8;
            srcIndex++;
            index = (index | (unsigned int)(0x00FF & src[srcIndex])) + 3;
            srcIndex++;
            memcpy(&ret[retIndex], &ret[retIndex - index], match);
            retIndex += match;
        }
    }
    return retIndex;
}