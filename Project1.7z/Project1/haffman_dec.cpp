#include <stdio.h>
#include <stdlib.h>
#include "haffman_dec.h"

void
HaffmanDec::Exec(char* inputFile, char* outputFile) {
    //
    FILE *fp = NULL;
    fopen_s(&fp, inputFile, "rb");

    // ���k�O�t�@�C���T�C�Y
    int uncompressSize;
    fread_s(&uncompressSize, sizeof(uncompressSize), sizeof(uncompressSize), 1, fp);

    // �o�b�t�@���m��
    fseek(fp, 0, SEEK_END);
    mBuffSize = ftell(fp) - 4;
    mBuff = (byte*)malloc(mBuffSize);
    if (NULL == mBuff) {
        if (NULL != fp) {
            fclose(fp);
        }
        return;
    }

    // �t�@�C���Ǎ�
    fseek(fp, 4, SEEK_SET);
    fread_s(mBuff, mBuffSize, mBuffSize, 1, fp);
    fclose(fp);
    fp = NULL;

    // �n�t�}���c���[�̍č\��
    mCurBuffPos = 0;
    mCurBuffBit = 7;
    mTempBitSize = 0;
    Node root;
    GenerateHaffmanTree(root);

    // ��������
    fopen_s(&fp, outputFile, "wb");
    WriteFile(root, fp, uncompressSize);
    fclose(fp);
    fp = NULL;

    free(mBuff);
}

void
HaffmanDec::GenerateHaffmanTree(Node &node) {
    if (mTempBitSize < 9) {
        while (mTempBitSize < 32) {
            if (mBuffSize <= mCurBuffPos) {
                return;
            }
            mTempBits |= ((mBuff[mCurBuffPos] >> mCurBuffBit) & 1) << mTempBitSize;
            mTempBitSize++;
            mCurBuffBit--;
            if (mCurBuffBit < 0) {
                mCurBuffBit += 8;
                mCurBuffPos++;
            }
        }
    }
    if (mTempBits & 1) {
        mTempBits >>= 1;
        mTempBitSize--; // �t�m�[�h�t���O�ǔ�
        node.isLeaf = 1;
        node.value = 0;
        node.value |= (mTempBits & 0b10000000) >> 7;
        node.value |= (mTempBits & 0b01000000) >> 5;
        node.value |= (mTempBits & 0b00100000) >> 3;
        node.value |= (mTempBits & 0b00010000) >> 1;
        node.value |= (mTempBits & 0b00001000) << 1;
        node.value |= (mTempBits & 0b00000100) << 3;
        node.value |= (mTempBits & 0b00000010) << 5;
        node.value |= (mTempBits & 0b00000001) << 7;
        mTempBits >>= 8;
        mTempBitSize -= 8;
        node.left = NULL;
        node.right = NULL;
    }
    else {
        mTempBits >>= 1;
        mTempBitSize--; // �t�m�[�h�t���O�ǔ�
        node.isLeaf = 0;
        node.value = 0;
        node.left = new Node;
        node.right = new Node;
        GenerateHaffmanTree(*node.left);
        GenerateHaffmanTree(*node.right);
    }
}

void
HaffmanDec::WriteFile(Node &root, FILE *fp, int uncompressSize) {
    int outputSize = 0;
    Node *node = &root;
    while (1) {
        if (mTempBitSize < 1) {
            while (mTempBitSize < 32) {
                if (mBuffSize <= mCurBuffPos) {
                    mTempBitSize++;
                }
                else {
                    mTempBits |= ((mBuff[mCurBuffPos] >> mCurBuffBit) & 1) << mTempBitSize;
                    mTempBitSize++;
                    mCurBuffBit--;
                    if (mCurBuffBit < 0) {
                        mCurBuffBit += 8;
                        mCurBuffPos++;
                    }
                }
            }
        }
        if (node->isLeaf) {
            // �t�m�[�h������������l���o�͂��A���[�g�ɖ߂�
            fwrite(&node->value, sizeof(node->value), 1, fp);
            outputSize++;
            node = &root;
            if (uncompressSize <= outputSize) {
                break;
            }
        }
        else {
            // �t�m�[�h�ɓ��B����܂ŒT��
            if (mTempBits & 1) {
                node = node->right;
            }
            else {
                node = node->left;
            }
            mTempBits >>= 1;
            mTempBitSize--;
        }
    }
}
