﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Elements;

namespace CircuitSim {
    public class Scope {
        public static readonly int VAL_CURRENT = 0;
        public static readonly int VAL_POWER = 1;

        public static int UNITS_V = 1;
        public static int UNITS_A = 1;
        public static int UNITS_W = 1;

        public void resetGraph(bool a) {

        }
    }
}
