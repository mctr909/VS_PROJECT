﻿using System;

using CircuitSim;

namespace Elements {
    interface Editable {
        EditInfo getEditInfo(int n);
        void setEditValue(int n, EditInfo ei);
    }

    public class BaseElement : Editable {
        public static readonly double PI = 3.14159265358979323846;

        public static double CURRENT_SPEED;
        public static double POWER;

        // scratch points for convenience
        protected static Point POSA;
        protected static Point POSB;

        protected static MainForm form;
        protected static CircuitManager cir;

        // initial point where user created element. For simple two-terminal elements,
        // this is the first node/post.
        protected int mAx;
        protected int mAy;

        // point to which user dragged out element. For simple two-terminal elements,
        // this is the second node/post
        protected int mBx;
        protected int mBy;

        // lead points (ends of wire stubs for simple two-terminal elements)
        protected Point mLead1;
        protected Point mLead2;

        // length along x and y axes, and sign of difference
        protected int mDX;
        protected int mDY;
        protected int mDSign;

        // length of element
        protected double mLen;

        protected Rectangle mBoundingBox;

        // if subclasses set this to true, element will be horizontal or vertical only
        protected bool mIsNoDiagonal;

        protected int flags;
        protected int voltSource;
        protected int[] nodes;
        protected double[] volts; // voltages at each node

        protected double current;
        protected double curcount;

        protected int lastHandleGrabbed = -1;
        protected int numHandles = 2;

        // (x,y) and (x2,y2) as Point objects
        private Point mPoint1;
        private Point mPoint2;
        private double mPx1;
        private double mPy1;

        public bool mSelected;

        public static void initClass(MainForm s) {
            form = s;
            cir = s.mCirManager;
            POSA = new Point();
            POSB = new Point();
        }

        // create new element with one post at xx,yy, to be dragged out by user
        protected BaseElement(int xx, int yy) {
            mAx = mBx = xx;
            mAy = mBy = yy;
            flags = getDefaultFlags();
            allocNodes();
            initBoundingBox();
        }

        // create element between xa,ya and xb,yb from undump
        protected BaseElement(int xa, int ya, int xb, int yb, int f) {
            mAx = xa;
            mAy = ya;
            mBx = xb;
            mBy = yb;
            flags = f;
            allocNodes();
            initBoundingBox();
        }

        int getDefaultFlags() {
            return 0;
        }

        // allocate nodes/volts arrays we need
        protected void allocNodes() {
            int n = getPostCount() + getInternalNodeCount();
            // preserve voltages if possible
            if (nodes == null || nodes.Length != n) {
                nodes = new int[n];
                volts = new double[n];
            }
        }

        protected void initBoundingBox() {
            mBoundingBox = new Rectangle();
            mBoundingBox.setBounds(
                Math.Min(mAx, mBx), Math.Min(mAy, mBy),
                Math.Abs(mBx - mAx) + 1, Math.Abs(mBy - mAy) + 1);
        }

        public int getPostCount() {
            return 2;
        }

        // number of internal nodes (nodes not visible in UI that are needed for
        // implementation)
        public int getInternalNodeCount() {
            return 0;
        }

        public EditInfo getEditInfo(int n) {
            return null;
        }

        public void setEditValue(int n, EditInfo ei) { }

        // abstract int getDumpType();
        int getDumpType() {
            throw new Exception("IllegalStateException");
            // Seems necessary to work-around what appears to be a compiler
            // bug affecting OTAElm to make sure this method (which should really be abstract) throws
            // an exception
        }

        // leftover from java, doesn't do anything anymore.
        object getDumpClass() {
            return this;
        }

        // dump component state for export/undo
        string dump() {
            int t = getDumpType();
            return (t < 127 ? ((char)t) + " " : t + " ") + mAx + " " + mAy + " " + mBx + " " + mBy + " " + flags;
        }

        // handle reset button
        public void reset() {
            int i;
            for (i = 0; i != getPostCount() + getInternalNodeCount(); i++) {
                volts[i] = 0;
            }
            curcount = 0;
        }

        // set current for voltage source vn to c. vn will be the same value as in a
        // previous call to setVoltageSource(n, vn)
        public void setCurrent(int vn, double c) {
            current = c;
        }

        // get current for one- or two-terminal elements
        public double getCurrent() {
            return current;
        }

        // stamp matrix values for linear elements.
        // for non-linear elements, use this to stamp values that don't change each
        // iteration, and call stampRightSide() or stampNonLinear() as needed
        public void stamp() { }

        // stamp matrix values for non-linear elements
        public void doStep() { }

        void delete() {
            Drawer.delete(this);
        }

        public void startIteration() { }

        // get voltage of x'th node
        double getPostVoltage(int x) {
            return volts[x];
        }

        // set voltage of x'th node, called by simulator logic
        public void setNodeVoltage(int n, double c) {
            volts[n] = c;
            calculateCurrent();
        }

        // calculate current in response to node voltages changing
        void calculateCurrent() { }

        // calculate post locations and other convenience values used for drawing.
        // Called when element is moved
        void setPoints() {
            mDX = mBx - mAx;
            mDY = mBy - mAy;
            mLen = Math.Sqrt(mDX * mDX + mDY * mDY);
            mPx1 = mDY / mLen;
            mPy1 = -mDX / mLen;
            mDSign = (mDY == 0) ? Math.Sign(mDX) : Math.Sign(mDY);
            mPoint1 = new Point(mAx, mAy);
            mPoint2 = new Point(mBx, mBy);
        }

        // calculate lead points for an element of length len. Handy for simple
        // two-terminal elements.
        // Posts are where the user connects wires; leads are ends of wire stubs drawn
        // inside the element.
        void calcLeads(int len) {
            if (mLen < len || len == 0) {
                mLead1 = mPoint1;
                mLead2 = mPoint2;
                return;
            }
            mLead1 = Drawer.interpPoint(mPoint1, mPoint2, (mLen - len) / (2 * mLen));
            mLead2 = Drawer.interpPoint(mPoint1, mPoint2, (mLen + len) / (2 * mLen));
        }

        // draw second point to xx, yy
        void drag(int xx, int yy) {
            xx = form.snapGrid(xx);
            yy = form.snapGrid(yy);
            if (mIsNoDiagonal) {
                if (Math.Abs(mAx - xx) < Math.Abs(mAy - yy)) {
                    xx = mAx;
                } else {
                    yy = mAy;
                }
            }
            mBx = xx;
            mBy = yy;
            setPoints();
        }

        void move(int dx, int dy) {
            mAx += dx;
            mAy += dy;
            mBx += dx;
            mBy += dy;
            mBoundingBox.translate(dx, dy);
            setPoints();
        }

        // called when an element is done being dragged out; returns true if it's zero
        // size and should be deleted
        bool creationFailed() {
            return (mAx == mBx && mAy == mBy);
        }

        // this is used to set the position of an internal element so we can draw it
        // inside the parent
        void setPosition(int x_, int y_, int x2_, int y2_) {
            mAx = x_;
            mAy = y_;
            mBx = x2_;
            mBy = y2_;
            setPoints();
        }

        // determine if moving this element by (dx,dy) will put it on top of another
        // element
        bool allowMove(int dx, int dy) {
            int nx = mAx + dx;
            int ny = mAy + dy;
            int nx2 = mBx + dx;
            int ny2 = mBy + dy;
            int i;
            for (i = 0; i != form.mCirManager.mElmList.Count; i++) {
                BaseElement ce = form.mCirManager.getElm(i);
                if (ce.mAx == nx && ce.mAy == ny && ce.mBx == nx2 && ce.mBy == ny2) {
                    return false;
                }
                if (ce.mAx == nx2 && ce.mAy == ny2 && ce.mBx == nx && ce.mBy == ny) {
                    return false;
                }
            }
            return true;
        }

        void movePoint(int n, int dx, int dy) {
            // modified by IES to prevent the user dragging points to create zero sized
            // nodes
            // that then render improperly
            int oldx = mAx;
            int oldy = mAy;
            int oldx2 = mBx;
            int oldy2 = mBy;
            if (n == 0) {
                mAx += dx;
                mAy += dy;
            } else {
                mBx += dx;
                mBy += dy;
            }
            if (mAx == mBx && mAy == mBy) {
                mAx = oldx;
                mAy = oldy;
                mBx = oldx2;
                mBy = oldy2;
            }
            setPoints();
        }

        // number of voltage sources this element needs
        public int getVoltageSourceCount() {
            return 0;
        }

        // notify this element that its pth node is n. This value n can be passed to
        // stampMatrix()
        public void setNode(int p, int n) {
            nodes[p] = n;
        }

        // notify this element that its nth voltage source is v. This value v can be
        // passed to stampVoltageSource(), etc and will be passed back in calls to
        // setCurrent()
        public void setVoltageSource(int n, int v) {
            // default implementation only makes sense for subclasses with one voltage
            // source. If we have 0 this isn't used, if we have >1 this won't work
            voltSource = v;
        }

        // int getVoltageSource() { return voltSource; } // Never used except for debug
        // code which is commented out

        double getVoltageDiff() {
            return volts[0] - volts[1];
        }

        public bool nonLinear() {
            return false;
        }

        // get (global) node number of nth node
        public int getNode(int n) {
            return nodes[n];
        }

        // get position of nth node
        public Point getPost(int n) {
            return (n == 0) ? mPoint1 : (n == 1) ? mPoint2 : null;
        }

        int getNodeAtPoint(int xp, int yp) {
            if (getPostCount() == 2) {
                return (mAx == xp && mAy == yp) ? 0 : 1;
            }
            int i;
            for (i = 0; i != getPostCount(); i++) {
                Point p = getPost(i);
                if (p.x == xp && p.y == yp) {
                    return i;
                }
            }
            return 0;
        }

        // set/adjust bounding box used for selecting elements. getCircuitBounds() does
        // not use this!
        void setBbox(int x1, int y1, int x2, int y2) {
            if (x1 > x2) {
                int q = x1;
                x1 = x2;
                x2 = q;
            }
            if (y1 > y2) {
                int q = y1;
                y1 = y2;
                y2 = q;
            }
            mBoundingBox.setBounds(x1, y1, x2 - x1 + 1, y2 - y1 + 1);
        }

        // set bounding box for an element from p1 to p2 with width w
        void setBbox(Point p1, Point p2, double w) {
            setBbox(p1.x, p1.y, p2.x, p2.y);
            int dpx = (int)(mPx1 * w);
            int dpy = (int)(mPy1 * w);
            adjustBbox(p1.x + dpx, p1.y + dpy, p1.x - dpx, p1.y - dpy);
        }

        // enlarge bbox to contain an additional rectangle
        void adjustBbox(int x1, int y1, int x2, int y2) {
            if (x1 > x2) {
                int q = x1;
                x1 = x2;
                x2 = q;
            }
            if (y1 > y2) {
                int q = y1;
                y1 = y2;
                y2 = q;
            }
            x1 = Math.Min(mBoundingBox.x, x1);
            y1 = Math.Min(mBoundingBox.y, y1);
            x2 = Math.Max(mBoundingBox.x + mBoundingBox.width, x2);
            y2 = Math.Max(mBoundingBox.y + mBoundingBox.height, y2);
            mBoundingBox.setBounds(x1, y1, x2 - x1, y2 - y1);
        }

        void adjustBbox(Point p1, Point p2) {
            adjustBbox(p1.x, p1.y, p2.x, p2.y);
        }

        // needed for calculating circuit bounds (need to special-case centered text
        // elements)
        bool isCenteredText() {
            return false;
        }

        // update dot positions (curcount) for drawing current (simple case for single
        // current)
        void updateDotCount() {
            curcount = updateDotCount(current, curcount);
        }

        // update dot positions (curcount) for drawing current (general case for
        // multiple currents)
        double updateDotCount(double cur, double cc) {
            if (!cir.simIsRunning()) {
                return cc;
            }
            double cadd = cur * CURRENT_SPEED;
            /*
             * if (cur != 0 && cadd <= .05 && cadd >= -.05) cadd = (cadd < 0) ? -.05 : .05;
             */
            cadd %= 8;
            /*
             * if (cadd > 8) cadd = 8; if (cadd < -8) cadd = -8;
             */
            return cc + cadd;
        }

        void doAdjust() { }

        void setupAdjust() { }

        // get component info for display in lower right
        void getInfo(string[] arr) { }

        int getBasicInfo(string[] arr) {
            arr[1] = "I = " + Drawer.getCurrentDText(getCurrent());
            arr[2] = "Vd = " + Drawer.getVoltageDText(getVoltageDiff());
            return 3;
        }

        string getScopeText(int v) {
            string[] info = new string[10];
            getInfo(info);
            return info[0];
        }

        double getPower() {
            return getVoltageDiff() * current;
        }

        double getScopeValue(int x) {
            return (x == Scope.VAL_CURRENT) ? getCurrent() : (x == Scope.VAL_POWER) ? getPower() : getVoltageDiff();
        }

        int getScopeUnits(int x) {
            return (x == Scope.VAL_CURRENT) ? Scope.UNITS_A : (x == Scope.VAL_POWER) ? Scope.UNITS_W : Scope.UNITS_V;
        }

        // get number of nodes that can be retrieved by getConnectionNode()
        public int getConnectionNodeCount() {
            return getPostCount();
        }

        // get nodes that can be passed to getConnection(), to test if this element
        // connects
        // those two nodes; this is the same as getNode() for all but labeled nodes.
        public int getConnectionNode(int n) {
            return getNode(n);
        }

        // are n1 and n2 connected by this element? this is used to determine
        // unconnected nodes, and look for loops
        public bool getConnection(int n1, int n2) {
            return true;
        }

        // is n1 connected to ground somehow?
        public bool hasGroundConnection(int n1) {
            return false;
        }

        // is this a wire or equivalent to a wire?
        public bool isWire() {
            return false;
        }

        bool canViewInScope() {
            return getPostCount() <= 2;
        }

        bool comparePair(int x1, int x2, int y1, int y2) {
            return ((x1 == y1 && x2 == y2) || (x1 == y2 && x2 == y1));
        }

        bool needsHighlight() {
            return Drawer.needsHighlight(this);
        }

        bool isSelected() {
            return mSelected;
        }

        bool canShowValueInScope(int v) {
            return false;
        }

        void setSelected(bool x) {
            mSelected = x;
        }

        void selectRect(Rectangle r) {
            mSelected = r.intersects(mBoundingBox);
        }

        Rectangle getBoundingBox() {
            return mBoundingBox;
        }

        bool needsShortcut() {
            return getShortcut() > 0;
        }

        int getShortcut() {
            return 0;
        }

        bool isGraphicElmt() {
            return false;
        }

        void setMouseElm(bool v) {
            Drawer.setMouseElm(v, this);
        }

        void draggingDone() { }

        string dumpModel() {
            return null;
        }

        bool isMouseElm() {
            return Drawer.isMouseElm(this);
        }

        void updateModels() { }

        public void stepFinished() { }

        double getCurrentIntoNode(int n) {
            // if we take out the getPostCount() == 2 it gives the wrong value for rails
            if (n == 0 && getPostCount() == 2) {
                return -current;
            } else {
                return current;
            }
        }

        void flipPosts() {
            int oldx = mAx;
            int oldy = mAy;
            mAx = mBx;
            mAy = mBy;
            mBx = oldx;
            mBy = oldy;
            setPoints();
        }

        void draw(Graphics g) { }

        // update and draw current for simple two-terminal element
        protected void doDots(Graphics g) {
            updateDotCount();
            if (form.dragElm != this) {
                Drawer.drawDots(g, mPoint1, mPoint2, curcount);
            }
        }

        protected void draw2Leads(Graphics g) {
            // draw first lead
            setVoltageColor(g, volts[0]);
            Drawer.drawThickLine(g, mPoint1, mLead1);

            // draw second lead
            setVoltageColor(g, volts[1]);
            Drawer.drawThickLine(g, mLead2, mPoint2);
        }

        protected void drawPosts(Graphics g) {
            // we normally do this in updateCircuit() now because the logic is more
            // complicated.
            // we only handle the case where we have to draw all the posts. That happens
            // when
            // this element is selected or is being created
            if (form.dragElm == null && !needsHighlight()) {
                return;
            }
            if (form.mouseMode == MainForm.MODE_DRAG_ROW || form.mouseMode == MainForm.MODE_DRAG_COLUMN) {
                return;
            }
            int i;
            for (i = 0; i != getPostCount(); i++) {
                Point p = getPost(i);
                Drawer.drawPost(g, p);
            }
        }

        protected void drawHandles(Graphics g, Color c) {
            g.setColor(c);
            if (lastHandleGrabbed == -1) {
                g.fillRect(mAx - 3, mAy - 3, 7, 7);
            } else if (lastHandleGrabbed == 0) {
                g.fillRect(mAx - 4, mAy - 4, 9, 9);
            }
            if (numHandles == 2) {
                if (lastHandleGrabbed == -1) {
                    g.fillRect(mBx - 3, mBy - 3, 7, 7);
                } else if (lastHandleGrabbed == 1) {
                    g.fillRect(mBx - 4, mBy - 4, 9, 9);
                }
            }
        }

        // draw component values (number of resistor ohms, etc). hs = offset
        protected void drawValues(Graphics g, string s, double hs) {
            if (s == null) {
                return;
            }
            g.setFont(Drawer.FONT_UNITS);
            //int w = (int)g.context.measureText(s).getWidth();
            int w = 100;
            g.setColor(Drawer.COLOR_WHITE);
            int ya = g.currentFontSize / 2;
            int xc, yc;
            if (GetType() == typeof(RailElm) || GetType() == typeof(SweepElm)) {
                xc = mBx;
                yc = mBy;
            } else {
                xc = (mBx + mAx) / 2;
                yc = (mBy + mAy) / 2;
            }
            int dpx = (int)(mPx1 * hs);
            int dpy = (int)(mPy1 * hs);
            if (dpx == 0) {
                g.drawString(s, xc - w / 2, yc - Math.Abs(dpy) - 2);
            } else {
                int xx = xc + Math.Abs(dpx) + 2;
                if (GetType() == typeof(VoltageElm) || (mAx < mBx && mAy > mBy)) {
                    xx = xc - (w + Math.Abs(dpx) + 2);
                }
                g.drawString(s, xx, yc + dpy + ya);
            }
        }

        protected void drawCenteredText(Graphics g, string s, int x, int y, bool cx) {
            //int w = (int)g.context.measureText(s).getWidth();
            //int h2 = g.currentFontSize / 2;
            //g.context.save();
            //g.context.setTextBaseline("middle");
            //if (cx) {
            //    g.context.setTextAlign("center");
            //    adjustBbox(x - w / 2, y - h2, x + w / 2, y + h2);
            //} else {
            //    adjustBbox(x, y - h2, x + w, y + h2);
            //}

            //if (cx) {
            //    g.context.setTextAlign("center");
            //}
            //g.drawString(s, x, y);
            //g.context.restore();
        }

        protected void drawCoil(Graphics g, int hs, Point p1, Point p2, double v1, double v2) {
            double len = distance(p1, p2);

            g.setLineWidth(3.0);
            g.context.Transform.Multiply(new System.Drawing.Drawing2D.Matrix(
                (p2.x - p1.x) / (float)len, (p2.y - p1.y) / (float)len,
                -(p2.y - p1.y) / (float)len, (p2.x - p1.x) / (float)len,
                p1.x, p1.y
            ));

            if (form.voltsCheckItem.Checked) {
                //CanvasGradient grad = g.context.createLinearGradient(0, 0, len, 0);
                //grad.addColorStop(0, getVoltageColor(g, v1).getHexValue());
                //grad.addColorStop(1.0, getVoltageColor(g, v2).getHexValue());
                //g.context.setStrokeStyle(grad);
            }
            g.context.ScaleTransform(1, hs > 0 ? 1 : -1);

            int loop;
            // draw more loops for a longer coil
            int loopCt = (int)Math.Ceiling(len / 11);
            for (loop = 0; loop != loopCt; loop++) {
                //g.context.beginPath();
                //double start = len * loop / loopCt;
                //g.context.moveTo(start, 0);
                //g.context.arc(len * (loop + .5) / loopCt, 0, len / (2 * loopCt), Math.PI, Math.PI * 2);
                //g.context.lineTo(len * (loop + 1) / loopCt, 0);
                //g.context.stroke();
            }
        }

        protected Polygon getSchmittPolygon(float gsize, float ctr) {
            Point[] pts = Drawer.newPointArray(6);
            float hs = 3 * gsize;
            float h1 = 3 * gsize;
            float h2 = h1 * 2;
            double len = distance(mLead1, mLead2);
            pts[0] = Drawer.interpPoint(mLead1, mLead2, ctr - h2 / len, hs);
            pts[1] = Drawer.interpPoint(mLead1, mLead2, ctr + h1 / len, hs);
            pts[2] = Drawer.interpPoint(mLead1, mLead2, ctr + h1 / len, -hs);
            pts[3] = Drawer.interpPoint(mLead1, mLead2, ctr + h2 / len, -hs);
            pts[4] = Drawer.interpPoint(mLead1, mLead2, ctr - h1 / len, -hs);
            pts[5] = Drawer.interpPoint(mLead1, mLead2, ctr - h1 / len, hs);
            return Drawer.createPolygon(pts);
        }

        protected int getHandleGrabbedClose(int xtest, int ytest, int deltaSq, int minSize) {
            lastHandleGrabbed = -1;
            if (Graphics.distanceSq(mAx, mAy, mBx, mBy) >= minSize) {
                if (Graphics.distanceSq(mAx, mAy, xtest, ytest) <= deltaSq) {
                    lastHandleGrabbed = 0;
                } else if (Graphics.distanceSq(mBx, mBy, xtest, ytest) <= deltaSq) {
                    lastHandleGrabbed = 1;
                }
            }
            return lastHandleGrabbed;
        }

        protected Color getVoltageColor(Graphics g, double volts) {
            if (needsHighlight()) {
                return (Drawer.COLOR_SELECT);
            }
            if (!form.voltsCheckItem.Checked) {
                return (Drawer.COLOR_WHITE);
            }
            int c = (int)((volts + Drawer.VOLTAGE_RANGE) * (Drawer.COLOR_SCALE_COUNT - 1) / (Drawer.VOLTAGE_RANGE * 2));
            if (c < 0) {
                c = 0;
            }
            if (c >= Drawer.COLOR_SCALE_COUNT) {
                c = Drawer.COLOR_SCALE_COUNT - 1;
            }
            return (Drawer.COLOR_SCALE[c]);
        }

        protected void setVoltageColor(Graphics g, double volts) {
            g.setColor(getVoltageColor(g, volts));
        }

        protected void setPowerColor(Graphics g, bool yellow) {
            /*
             * if (conductanceCheckItem.getState()) { setConductanceColor(g,
             * current/getVoltageDiff()); return; }
             */
            if (!form.powerCheckItem.Checked) {
                return;
            }
            setPowerColor(g, getPower());
        }

        protected void setPowerColor(Graphics g, double w0) {
            if (!form.powerCheckItem.Checked) {
                return;
            }
            if (needsHighlight()) {
                g.setColor(Drawer.COLOR_SELECT);
                return;
            }
            w0 *= POWER;
            int i = (int)((Drawer.COLOR_SCALE_COUNT / 2) + (Drawer.COLOR_SCALE_COUNT / 2) * -w0);
            if (i < 0) {
                i = 0;
            }
            if (i >= Drawer.COLOR_SCALE_COUNT) {
                i = Drawer.COLOR_SCALE_COUNT - 1;
            }
            g.setColor(Drawer.COLOR_SCALE[i]);
        }

        protected void setConductanceColor(Graphics g, double w0) {
            w0 *= POWER;
            double w = (w0 < 0) ? -w0 : w0;
            if (w > 1) {
                w = 1;
            }
            int rg = (byte)(w * 255);
            g.setColor(new Color(rg, rg, rg));
        }

        protected static double distance(Point p1, Point p2) {
            double x = p1.x - p2.x;
            double y = p1.y - p2.y;
            return Math.Sqrt(x * x + y * y);
        }
    }
}