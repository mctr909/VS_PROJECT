﻿using System;
using System.Collections.Generic;

using Elements;

namespace CircuitSim {
    public class FindPathInfo {
        public static readonly int INDUCT = 1;
        public static readonly int VOLTAGE = 2;
        public static readonly int SHORT = 3;
        public static readonly int CAP_V = 4;

        public int type;
        public BaseElement firstElm;
        public int dest;
        public bool[] used;
        private List<BaseElement> elmList;

        public FindPathInfo(int type, BaseElement firstElm, int dest, int nodeCount, List<BaseElement> elmList) {
            this.type = type;
            this.firstElm = firstElm;
            this.dest = dest;
            used = new bool[nodeCount];
            this.elmList = elmList;
        }

        public bool findPath(int n1) {
            return findPath(n1, -1);
        }

        public bool findPath(int n1, int depth) {
            if (n1 == dest) {
                return true;
            }
            if (depth-- == 0) {
                return false;
            }
            if (used[n1]) {
                // System.out.println("used " + n1);
                return false;
            }
            used[n1] = true;
            int i;
            for (i = 0; i != elmList.Count; i++) {
                BaseElement ce = getElm(i);
                if (ce == firstElm) {
                    continue;
                }
                if (type == INDUCT) {
                    // inductors need a path free of current sources
                    if (ce.GetType() == typeof(CurrentElm)) {
                        continue;
                    }
                }
                if (type == VOLTAGE) {
                    // when checking for voltage loops, we only care about voltage
                    // sources/wires/ground
                    if (!(ce.isWire() || ce.GetType() == typeof(VoltageElm) || ce.GetType() == typeof(GroundElm))) {
                        continue;
                    }
                }
                // when checking for shorts, just check wires
                if (type == SHORT && !ce.isWire()) {
                    continue;
                }
                if (type == CAP_V) {
                    // checking for capacitor/voltage source loops
                    if (!(ce.isWire() || ce.GetType() == typeof(CapacitorElm) || ce.GetType() == typeof(VoltageElm))) {
                        continue;
                    }
                }
                if (n1 == 0) {
                    // look for posts which have a ground connection;
                    // our path can go through ground
                    int j;
                    for (j = 0; j != ce.getConnectionNodeCount(); j++) {
                        if (ce.hasGroundConnection(j) && findPath(ce.getConnectionNode(j), depth)) {
                            used[n1] = false;
                            return true;
                        }
                    }
                }
                int j;
                for (j = 0; j != ce.getConnectionNodeCount(); j++) {
                    // System.out.println(ce + " " + ce.getNode(j));
                    if (ce.getConnectionNode(j) == n1) {
                        break;
                    }
                }
                if (j == ce.getConnectionNodeCount()) {
                    continue;
                }
                if (ce.hasGroundConnection(j) && findPath(0, depth)) {
                    // System.out.println(ce + " has ground");
                    used[n1] = false;
                    return true;
                }
                if (type == INDUCT && ce.GetType() == typeof(InductorElm)) {
                    // inductors can use paths with other inductors of matching current
                    double c = ce.getCurrent();
                    if (j == 0) {
                        c = -c;
                    }
                    // System.out.println("matching " + c + " to " + firstElm.getCurrent());
                    // System.out.println(ce + " " + firstElm);
                    if (Math.Abs(c - firstElm.getCurrent()) > 1e-10) {
                        continue;
                    }
                }
                int k;
                for (k = 0; k != ce.getConnectionNodeCount(); k++) {
                    if (j == k) {
                        continue;
                    }
                    // console(ce + " " + ce.getNode(j) + "-" + ce.getNode(k));
                    if (ce.getConnection(j, k) && findPath(ce.getConnectionNode(k), depth)) {
                        // System.out.println("got findpath " + n1);
                        used[n1] = false;
                        return true;
                    }
                    // System.out.println("back on findpath " + n1);
                }
            }
            used[n1] = false;
            // System.out.println(n1 + " failed");
            return false;
        }

        private BaseElement getElm(int n) {
            if (n >= elmList.Count) {
                return null;
            }
            return elmList[n];
        }
    }
}
