﻿namespace CircuitSim {
    public class Color {
        public static readonly Color white = new Color(255, 255, 255);
        public static readonly Color lightGray = new Color(192, 192, 192);
        public static readonly Color gray = new Color(128, 128, 128);
        public static readonly Color GRAY = new Color(128, 128, 128);
        public static readonly Color dark_gray = new Color(64, 64, 64);
        public static readonly Color darkGray = new Color(64, 64, 64);
        public static readonly Color black = new Color(0, 0, 0);
        public static readonly Color red = new Color(255, 0, 0);
        public static readonly Color pink = new Color(255, 175, 175);
        public static readonly Color orange = new Color(255, 200, 0);
        public static readonly Color yellow = new Color(255, 255, 0);
        public static readonly Color green = new Color(0, 255, 0);
        public static readonly Color magenta = new Color(255, 0, 255);
        public static readonly Color cyan = new Color(0, 255, 255);
        public static readonly Color blue = new Color(0, 0, 255);
        public static readonly Color NONE = new Color("");

        private byte r, g, b;

        // only for special cases, like no color, or maybe named colors
        private string colorText = null;

        private Color(string colorText) {
            this.colorText = colorText;
        }

        public Color(int r, int g, int b) {
            this.r = (byte)r;
            this.g = (byte)g;
            this.b = (byte)b;
        }

        public int getRed() {
            return r;
        }

        public int getGreen() {
            return g;
        }

        public int getBlue() {
            return b;
        }

        public string getHexValue() {
            if (colorText != null) {
                return colorText;
            }
            return "#" + r.ToString("X2") + g.ToString("X2") + b.ToString("X2");
        }

        public string toString() {
            if (colorText != null) {
                return colorText;
            }
            return "red=" + r + ", green=" + g + ", blue=" + b;
        }
    }
}
