﻿namespace CircuitSim {
    public class Polygon {
        private static readonly int MIN_LENGTH = 4;
        public int npoints;
        public int[] xpoints;
        public int[] ypoints;

        public Polygon() {
            xpoints = new int[MIN_LENGTH];
            ypoints = new int[MIN_LENGTH];
        }

        public void addPoint(int x, int y) {
            if (npoints >= xpoints.Length || npoints >= ypoints.Length) {
                int newLength = npoints * 2;
                // Make sure that newLength will be greater than MIN_LENGTH and
                // aligned to the power of 2
                if (newLength < MIN_LENGTH) {
                    newLength = MIN_LENGTH;
                }

                xpoints = expand(xpoints, newLength);
                ypoints = expand(ypoints, newLength);
            }
            xpoints[npoints] = x;
            ypoints[npoints] = y;
            npoints++;
        }

        private int[] expand(int[] input, int newlen) {
            int[] output = new int[newlen];
            for (int i = 0; i < input.Length; i++) {
                output[i] = input[i];
            }
            return output;
        }
    }
}
