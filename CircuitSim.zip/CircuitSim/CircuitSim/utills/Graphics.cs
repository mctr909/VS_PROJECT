﻿namespace CircuitSim {
    public class Graphics {
        public System.Drawing.Graphics context;
        public System.Drawing.Font currentFont= null;
        public System.Drawing.Pen lastColor;
        public int currentFontSize;

        public Graphics(System.Drawing.Graphics context) {
            this.context = context;
        }

        public void setColor(Color color) {
            if (color != null) {
                lastColor = new System.Drawing.Pen(System.Drawing.Color.FromArgb(
                    color.getRed(), color.getGreen(), color.getBlue()));
            }
        }

        public void clipRect(int x, int y, int width, int height) {
        }

        public void restore() {
            context.Clear(System.Drawing.Color.FromArgb(0, 0, 0));
        }

        public void fillRect(int x, int y, int width, int height) {
            context.FillRectangle(lastColor.Brush, x, y, width, height);
        }

        public void drawRect(int x, int y, int width, int height) {
            context.DrawRectangle(lastColor, x, y, width, height);
        }

        public void fillOval(int x, int y, int width, int height) {
            context.FillPie(
                lastColor.Brush,
                x + width / 2.0f, y + width / 2.0f,
                width / 2.0f, height / 2.0f,
                0.0f, 360.0f);
        }

        public void drawString(string s, int x, int y) {
            context.DrawString(s, currentFont, lastColor.Brush, x, y);
        }

        public void setLineWidth(double width) {
            lastColor.Width = (float)width;
        }

        public void drawLine(int x1, int y1, int x2, int y2) {
            context.DrawLine(lastColor, x1, y1, x2, y2);
        }

        public void drawPolyline(int[] xpoints, int[] ypoints, int n) {
            var points = new System.Drawing.PointF[n];
            for (var i = 0; i < n; i++) {
                points[i] = new System.Drawing.PointF(xpoints[i], ypoints[i]);
            }
            context.DrawPolygon(lastColor, points);
        }

        public void fillPolygon(Polygon p) {
            var points = new System.Drawing.PointF[p.npoints];
            for (var i = 0; i < p.npoints; i++) {
                points[i] = new System.Drawing.PointF(p.xpoints[i], p.ypoints[i]);
            }
            context.FillPolygon(lastColor.Brush, points);
        }

        public void setFont(System.Drawing.Font f) {
            if (f != null) {
                currentFont = f;
            }
        }

        public System.Drawing.Font getFont() {
            return currentFont;
        }

        public static int distanceSq(int x1, int y1, int x2, int y2) {
            x2 -= x1;
            y2 -= y1;
            return x2 * x2 + y2 * y2;
        }

        void setLineDash(int a, int b) {
        }
    }
}
