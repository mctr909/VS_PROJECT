﻿using Elements;

namespace CircuitSim {
    public class CircuitNodeLink {
        public BaseElement elm;
        public int num;
    }
}
