﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CircuitSim {
    public class Rectangle {
        public int x;
        public int y;
        public int width;
        public int height;

        public Rectangle() {
            x = 0;
            y = 0;
            width = 0;
            height = 0;
        }

        public Rectangle(int x, int y, int width, int height) {
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;
        }

        public Rectangle(Point pt) {
            x = pt.x;
            y = pt.y;
            width = 0;
            height = 0;
        }

        public Rectangle(Rectangle rect) {
            x = rect.x;
            y = rect.y;
            width = rect.width;
            height = rect.height;
        }

        public void setBounds(int x, int y, int width, int height) {
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;
        }

        public void translate(int dx, int dy) {
            x += dx;
            y += dy;
        }

        public bool contains(int px, int py) {
            int w = width;
            int h = height;
            if ((w | h) < 0) {
                // At least one of the dimensions is negative...
                return false;
            }
            // Note: if either dimension is zero, tests below must return false...
            int tx = x;
            int ty = y;
            if (px < tx || py < ty) {
                return false;
            }
            w += tx;
            h += ty;
            //    overflow || intersect
            return (w < tx || w > px) && (h < ty || h > py);
        }

        public bool intersects(Rectangle r) {
            int tw = width;
            int th = height;
            int rw = r.width;
            int rh = r.height;
            if (rw <= 0 || rh <= 0 || tw <= 0 || th <= 0) {
                return false;
            }
            int tx = x;
            int ty = y;
            int rx = r.x;
            int ry = r.y;
            rw += rx;
            rh += ry;
            tw += tx;
            th += ty;
            //      overflow || intersect
            return ((rw < rx || rw > tx) &&
                    (rh < ry || rh > ty) &&
                    (tw < tx || tw > rx) &&
                    (th < ty || th > ry));
        }

        public Rectangle union(Rectangle r) {
            long tx2 = width;
            long ty2 = height;
            if ((tx2 | ty2) < 0) {
                // This rectangle has negative dimensions...
                // If r has non-negative dimensions then it is the answer.
                // If r is non-existant (has a negative dimension), then both
                // are non-existant and we can return any non-existant rectangle
                // as an answer.  Thus, returning r meets that criterion.
                // Either way, r is our answer.
                return new Rectangle(r);
            }
            long rx2 = r.width;
            long ry2 = r.height;
            if ((rx2 | ry2) < 0) {
                return new Rectangle(this);
            }
            int tx1 = x;
            int ty1 = y;
            tx2 += tx1;
            ty2 += ty1;
            int rx1 = r.x;
            int ry1 = r.y;
            rx2 += rx1;
            ry2 += ry1;
            if (tx1 > rx1)
                tx1 = rx1;
            if (ty1 > ry1)
                ty1 = ry1;
            if (tx2 < rx2)
                tx2 = rx2;
            if (ty2 < ry2)
                ty2 = ry2;
            tx2 -= tx1;
            ty2 -= ty1;
            // tx2,ty2 will never underflow since both original rectangles
            // were already proven to be non-empty
            // they might overflow, though...
            if (tx2 > int.MaxValue)
                tx2 = int.MaxValue;
            if (ty2 > int.MaxValue)
                ty2 = int.MaxValue;
            return new Rectangle(tx1, ty1, (int)tx2, (int)ty2);
        }

        public string toString() {
            return "Rect(" + x + "," + y + "," + width + "," + height + ")";
        }

        public bool equals(object obj) {
            if (obj.GetType() == typeof(Rectangle)) {
                Rectangle r = (Rectangle)obj;
                return ((x == r.x) &&
                        (y == r.y) &&
                        (width == r.width) &&
                        (height == r.height));
            }
            return false;
        }
    }
}
