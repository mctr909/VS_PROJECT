﻿using System.Collections.Generic;

namespace CircuitSim {
    public class CircuitNode {
        public List<CircuitNodeLink> links;
        public bool isInternal;
    }
}
