﻿namespace CircuitSim {
    public class RowInfo {
        public static readonly int ROW_NORMAL = 0;  // ordinary value
        public static readonly int ROW_CONST  = 1;  // value is constant

        public int type, mapCol, mapRow;
        public double value;
        bool rsChanges; // row's right side changes
        bool lsChanges; // row's left side changes
        bool dropRow;   // row is not needed in matrix

        public RowInfo() {
            type = ROW_NORMAL;
        }
    }
}
