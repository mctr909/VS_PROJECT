﻿using System.Windows.Forms;

namespace CircuitSim {
    public class EditInfo {
        string name;
        string text;
        double value;
        TextBox textf;
        ListBox choice;
        CheckBox checkbox;
        Button button;
        TextBox textArea;
        Panel widget;
        bool newDialog;
        bool dimensionless;

        // for slider dialog
        TextBox minBox;
        TextBox maxBox;
        Label labelBox;

        // mn/mx were used in the java version to create sliders in the edit dialog but
        // we don't do that in the javascript version, so this
        // constructor is deprecated
        public EditInfo(string n, double val, double mn, double mx) {
            name = n;
            value = val;
            dimensionless = false;
        }

        public EditInfo(string n, double val) {
            name = n;
            value = val;
            dimensionless = false;
        }

        public EditInfo setDimensionless() {
            dimensionless = true;
            return this;
        }

        public int changeFlag(int flags, int bit) {
            if (checkbox.Checked) {
                return flags | bit;
            }
            return flags & ~bit;
        }

        public bool canCreateAdjustable() {
            return choice == null && checkbox == null && button == null && textArea == null && widget == null;
        }
    }
}
