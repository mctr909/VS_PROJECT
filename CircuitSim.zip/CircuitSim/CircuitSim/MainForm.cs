﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Elements;

namespace CircuitSim {
    public partial class MainForm : Form {
        public static readonly int MODE_DRAG_ROW = 0;
        public static readonly int MODE_DRAG_COLUMN = 1;

        public CircuitManager mCirManager;

        public CheckBox dotsCheckItem;
        public CheckBox voltsCheckItem;
        public CheckBox powerCheckItem;
        public CheckBox conventionCheckItem;

        public BaseElement plotYElm;
        public BaseElement dragElm;

        public int mouseMode;

        public MainForm() {
            InitializeComponent();
        }

        public void deleteSliders(BaseElement elm) {

        }

        public int snapGrid(int x) {
            return x;
        }
    }
}
