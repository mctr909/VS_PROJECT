﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Elements;

namespace CircuitSim {
    public class CircuitManager {
        //MainForm//private MainForm mForm;

        private double[,] mCircuitMatrix;
        private double[] mCircuitRightSide;
        private double[] mOrigRightSide;
        private double[,] mOrigMatrix;
        private RowInfo[] mCircuitRowInfo;
        private int[] mCircuitPermute;

        private BaseElement[] mVoltageSources;

        private bool mSimRunning;
        private bool mCircuitNonLinear;
        private bool mCircuitNeedsMap;
        private bool mDumpMatrix;

        private int mVoltageSourceCount;
        private int mCircuitMatrixSize;
        private int mCircuitMatrixFullSize;

        private int[] mScopeColCount;

        // map points to node numbers
        private class NodeMapEntry {
            public int node;
            public NodeMapEntry() {
                node = -1;
            }
            public NodeMapEntry(int n) {
                node = n;
            }
        }
        private Dictionary<Point, NodeMapEntry> mNodeMap;
        private Dictionary<Point, int> mPostCountMap;

        // info about each wire and its neighbors, used to calculate wire currents
        private class WireInfo {
            WireElm wire;
            List<BaseElement> neighbors;
            int post;
            WireInfo(WireElm w) {
                wire = w;
            }
        }
        private List<WireInfo> mWireInfoList;

        public List<BaseElement> mElmList;
        public Scope[] mScopes;
        public int mScopeCount;

        public bool mAnalyzeFlag;
        public bool mConverged;
        public bool mShowResistanceInVoltageSources;
        public int mSubIterations;

        public double mTime;
        public double mDeltaTime;
        public long mSecTime = 0;
        public int mSteps = 0;
        public int mFrames = 0;
        public int mFramerate = 0;
        public long mLastTime = 0;
        public long mLastFrameTime;
        public long mLastIterTime;
        public int mSteprate = 0;

        public List<CircuitNode> mNodeList;
        public List<Point> mPostDrawList = new List<Point>();
        public List<Point> mBadConnectionList = new List<Point>();
        public BaseElement mErrorElm;
        public string mStopMessage;

        public CircuitManager(MainForm cirSim) {
            //MainForm//mForm = cirSim;
            mScopes = new Scope[20];
            mScopeCount = 0;
            mScopeColCount = new int[20];
        }

        public bool simIsRunning() {
            return mSimRunning;
        }

        public void simStop() {
            mSimRunning = false;
        }

        public void simStart() {
            mSimRunning = false;
        }

        public BaseElement getElm(int n) {
            if (n >= mElmList.Count) {
                return null;
            }
            return mElmList[n];
        }

        public void resetAction() {
            int i;
            for (i = 0; i != mElmList.Count; i++) {
                getElm(i).reset();
            }
            for (i = 0; i != mScopeCount; i++) {
                mScopes[i].resetGraph(true);
            }
            // TODO: Will need to do IE bug fix here?
            mAnalyzeFlag = true;
            if (mTime == 0) {
                //MainForm//mForm.setSimRunning(true);
            } else {
                mTime = 0;
            }
        }

        public void stop(string s, BaseElement ce) {
            //MainForm//mStopMessage = MainForm.LS(s);
            mCircuitMatrix = null; // causes an exception
            mErrorElm = ce;
            //MainForm//mForm.setSimRunning(false);
            mAnalyzeFlag = false;
            // cv.repaint();
        }

        public void runCircuit(bool didAnalyze) {
            if (null == mCircuitMatrix || 0 == mElmList.Count) {
                mCircuitMatrix = null;
                return;
            }
            int iter;
            // int maxIter = getIterCount();
            bool debugprint = mDumpMatrix;
            mDumpMatrix = false;
            //MainForm//long steprate = (long) (160 * mForm.getIterCount());
            long steprate = 500; //MainForm//
            long tm = System.currentTimeMillis();
            long lit = mLastIterTime;
            if (0 == lit) {
                mLastIterTime = tm;
                return;
            }

            // Check if we don't need to run simulation (for very slow simulation speeds).
            // If the circuit changed, do at least one iteration to make sure everything is
            // consistent.
            if (1000 >= steprate * (tm - mLastIterTime) && !didAnalyze) {
                return;
            }

            bool delayWireProcessing = canDelayWireProcessing();

            for (iter = 1; ; iter++) {
                int i, j, k, subiter;
                for (i = 0; i != mElmList.Count; i++) {
                    BaseElement ce = getElm(i);
                    ce.startIteration();
                }
                mSteps++;
                int subiterCount = 5000;
                for (subiter = 0; subiter != subiterCount; subiter++) {
                    mConverged = true;
                    mSubIterations = subiter;
                    for (i = 0; i != mCircuitMatrixSize; i++) {
                        mCircuitRightSide[i] = mOrigRightSide[i];
                    }
                    if (mCircuitNonLinear) {
                        for (i = 0; i != mCircuitMatrixSize; i++) {
                            for (j = 0; j != mCircuitMatrixSize; j++) {
                                mCircuitMatrix[i, j] = mOrigMatrix[i, j];
                            }
                        }
                    }
                    for (i = 0; i != mElmList.Count; i++) {
                        BaseElement ce = getElm(i);
                        ce.doStep();
                    }
                    if (null != mStopMessage) {
                        return;
                    }
                    var printit = debugprint;
                    debugprint = false;
                    for (j = 0; j != mCircuitMatrixSize; j++) {
                        for (i = 0; i != mCircuitMatrixSize; i++) {
                            var x = mCircuitMatrix[i, j];
                            if (double.IsNaN(x) || double.IsInfinity(x)) {
                                stop("nan/infinite matrix!", null);
                                return;
                            }
                        }
                    }
                    if (printit) {
                        for (j = 0; j != mCircuitMatrixSize; j++) {
                            string x = "";
                            for (i = 0; i != mCircuitMatrixSize; i++) {
                                x += mCircuitMatrix[j, i] + ",";
                            }
                            x += "\n";
                            //MainForm//MainForm.console(x);
                        }
                        //MainForm//MainForm.console("");
                    }
                    if (mCircuitNonLinear) {
                        if (mConverged && subiter > 0)
                            break;
                        if (!Matrix.luFactor(mCircuitMatrix, mCircuitMatrixSize, mCircuitPermute)) {
                            stop("Singular matrix!", null);
                            return;
                        }
                    }
                    Matrix.luSolve(mCircuitMatrix, mCircuitMatrixSize, mCircuitPermute, mCircuitRightSide);

                    for (j = 0; j != mCircuitMatrixFullSize; j++) {
                        RowInfo ri = mCircuitRowInfo[j];
                        double res = 0;
                        if (ri.type == RowInfo.ROW_CONST) {
                            res = ri.value;
                        } else {
                            res = mCircuitRightSide[ri.mapCol];
                        }
                        /*
                         * System.out.println(j + " " + res + " " + ri.type + " " + ri.mapCol);
                         */
                        if (double.IsNaN(res)) {
                            mConverged = false;
                            // debugprint = true;
                            break;
                        }
                        if (j < mNodeList.Count - 1) {
                            var cn = getCircuitNode(j + 1);
                            for (k = 0; k != cn.links.Count; k++) {
                                var cnl = cn.links[k];
                                cnl.elm.setNodeVoltage(cnl.num, res);
                            }
                        } else {
                            int ji = j - (mNodeList.Count - 1);
                            // System.out.println("setting vsrc " + ji + " to " + res);
                            mVoltageSources[ji].setCurrent(ji, res);
                        }
                    }
                    if (!mCircuitNonLinear) {
                        break;
                    }
                }
                if (subiter > 5) {
                    //MainForm//MainForm.console("converged after " + subiter + " iterations\n");
                }
                if (subiter == subiterCount) {
                    stop("Convergence failed!", null);
                    break;
                }
                mTime += mDeltaTime;
                for (i = 0; i != mElmList.Count; i++) {
                    getElm(i).stepFinished();
                }
                if (!delayWireProcessing) {
                    calcWireCurrents();
                }
                for (i = 0; i != mScopeCount; i++) {
                    mScopes[i].timeStep();
                }
                for (i = 0; i != mElmList.Count; i++) {
                    if (getElm(i).GetType() == typeof(ScopeElm)) {
                        ((ScopeElm)getElm(i)).stepScope();
                    }
                }

                tm = System.currentTimeMillis();
                lit = tm;
                // Check whether enough time has elapsed to perform an *additional* iteration
                // after
                // those we have already completed.
                if ((iter + 1) * 1000 >= steprate * (tm - mLastIterTime) || (tm - mLastFrameTime > 500)) {
                    break;
                }
                if (!mSimRunning) {
                    break;
                }
            } // for (iter = 1; ; iter++)
            mLastIterTime = lit;
            if (delayWireProcessing) {
                calcWireCurrents();
            }
            // System.out.println((System.currentTimeMillis()-mLastFrameTime)/(double) iter);
        }

        public void analyzeCircuit() {
            if (0 == mElmList.Count) {
                mPostDrawList = new List<Point>();
                mBadConnectionList = new List<Point>();
                return;
            }
            mStopMessage = null;
            mErrorElm = null;
            int i, j;
            int vscount = 0;
            mNodeList = new List<CircuitNode>();
            mPostCountMap = new Dictionary<Point, int>();
            var gotGround = false;
            var gotRail = false;
            BaseElement volt = null;

            calculateWireClosure();

            // System.out.println("ac1");
            // look for voltage or ground element
            for (i = 0; i != mElmList.Count; i++) {
                var ce = getElm(i);
                if (ce.GetType() == typeof(GroundElm)) {
                    gotGround = true;
                    break;
                }
                if (ce.GetType() == typeof(RailElm)) {
                    gotRail = true;
                }
                if (volt == null && ce.GetType() == typeof(VoltageElm)) {
                    volt = ce;
                }
            }

            // if no ground, and no rails, then the voltage elm's first terminal
            // is ground
            if (!gotGround && volt != null && !gotRail) {
                var cn = new CircuitNode();
                var pt = volt.getPost(0);
                mNodeList.Add(cn);

                // update node map
                NodeMapEntry cln = mNodeMap[pt];
                if (cln != null) {
                    cln.node = 0;
                } else {
                    mNodeMap.Add(pt, new NodeMapEntry(0));
                }
            } else {
                // otherwise allocate extra node for ground
                CircuitNode cn = new CircuitNode();
                mNodeList.Add(cn);
            }
            // System.out.println("ac2");

            // allocate nodes and voltage sources
            LabeledNodeElm.resetNodeList();
            for (i = 0; i != mElmList.Count; i++) {
                var ce = getElm(i);
                int inodes = ce.getInternalNodeCount();
                int ivs = ce.getVoltageSourceCount();
                int posts = ce.getPostCount();

                // allocate a node for each post and match posts to nodes
                for (j = 0; j != posts; j++) {
                    var pt = ce.getPost(j);
                    var g = mPostCountMap[pt];
                    mPostCountMap.Add(pt, g == null ? 1 : g + 1);
                    var cln = mNodeMap[pt];

                    // is this node not in map yet? or is the node number unallocated?
                    // (we don't allocate nodes before this because changing the allocation order
                    // of nodes changes circuit behavior and breaks backward compatibility;
                    // the code below to connect unconnected nodes may connect a different node to
                    // ground)
                    if (cln == null || cln.node == -1) {
                        var cn = new CircuitNode();
                        var cnl = new CircuitNodeLink();
                        cnl.num = j;
                        cnl.elm = ce;
                        cn.links.Add(cnl);
                        ce.setNode(j, mNodeList.Count);
                        if (cln != null) {
                            cln.node = mNodeList.Count;
                        } else {
                            mNodeMap.Add(pt, new NodeMapEntry(mNodeList.Count));
                        }
                        mNodeList.Add(cn);
                    } else {
                        int n = cln.node;
                        var cnl = new CircuitNodeLink();
                        cnl.num = j;
                        cnl.elm = ce;
                        getCircuitNode(n).links.Add(cnl);
                        ce.setNode(j, n);
                        // if it's the ground node, make sure the node voltage is 0,
                        // cause it may not get set later
                        if (n == 0) {
                            ce.setNodeVoltage(j, 0);
                        }
                    }
                }
                for (j = 0; j != inodes; j++) {
                    var cn = new CircuitNode();
                    cn.isInternal = true;
                    var cnl = new CircuitNodeLink();
                    cnl.num = j + posts;
                    cnl.elm = ce;
                    cn.links.Add(cnl);
                    ce.setNode(cnl.num, mNodeList.Count);
                    mNodeList.Add(cn);
                }
                vscount += ivs;
            }

            makePostDrawList();
            if (!calcWireInfo()) {
                return;
            }
            mNodeMap = null; // done with this

            mVoltageSources = new BaseElement[vscount];
            vscount = 0;
            mCircuitNonLinear = false;
            // System.out.println("ac3");

            // determine if circuit is nonlinear
            for (i = 0; i != mElmList.Count; i++) {
                var ce = getElm(i);
                if (ce.nonLinear()) {
                    mCircuitNonLinear = true;
                }
                var ivs = ce.getVoltageSourceCount();
                for (j = 0; j != ivs; j++) {
                    mVoltageSources[vscount] = ce;
                    ce.setVoltageSource(j, vscount++);
                }
            }
            mVoltageSourceCount = vscount;

            var matrixSize = mNodeList.Count - 1 + vscount;
            mCircuitMatrix = new double[matrixSize, matrixSize];
            mCircuitRightSide = new double[matrixSize];
            mOrigMatrix = new double[matrixSize, matrixSize];
            mOrigRightSide = new double[matrixSize];
            mCircuitMatrixSize = mCircuitMatrixFullSize = matrixSize;
            mCircuitRowInfo = new RowInfo[matrixSize];
            mCircuitPermute = new int[matrixSize];
            for (i = 0; i != matrixSize; i++) {
                mCircuitRowInfo[i] = new RowInfo();
            }
            mCircuitNeedsMap = false;

            // stamp linear circuit elements
            for (i = 0; i != mElmList.Count; i++) {
                var ce = getElm(i);
                ce.stamp();
            }
            // System.out.println("ac4");

            // determine nodes that are not connected indirectly to ground
            var closure = new bool[mNodeList.Count];
            var changed = true;
            closure[0] = true;
            while (changed) {
                changed = false;
                for (i = 0; i != mElmList.Count; i++) {
                    var ce = getElm(i);
                    if (ce.GetType() == typeof(WireElm)) {
                        continue;
                    }
                    // loop through all ce's nodes to see if they are connected
                    // to other nodes not in closure
                    for (j = 0; j < ce.getConnectionNodeCount(); j++) {
                        if (!closure[ce.getConnectionNode(j)]) {
                            if (ce.hasGroundConnection(j)) {
                                closure[ce.getConnectionNode(j)] = changed = true;
                            }
                            continue;
                        }
                        int k;
                        for (k = 0; k != ce.getConnectionNodeCount(); k++) {
                            if (j == k) {
                                continue;
                            }
                            var kn = ce.getConnectionNode(k);
                            if (ce.getConnection(j, k) && !closure[kn]) {
                                closure[kn] = true;
                                changed = true;
                            }
                        }
                    }
                }
                if (changed) {
                    continue;
                }

                // connect one of the unconnected nodes to ground with a big resistor, then try
                // again
                for (i = 0; i != mNodeList.Count; i++) {
                    if (!closure[i] && !getCircuitNode(i).isInternal) {
                        //MainForm//MainForm.console("node " + i + " unconnected");
                        stampResistor(0, i, 1e8);
                        closure[i] = true;
                        changed = true;
                        break;
                    }
                }
            }
            // System.out.println("ac5");

            for (i = 0; i != mElmList.Count; i++) {
                var ce = getElm(i);
                // look for inductors with no current path
                if (ce.GetType() == typeof(InductorElm)) {
                    var fpi = new FindPathInfo(FindPathInfo.INDUCT, ce, ce.getNode(1), mNodeList.Count, mElmList);
                    // first try findPath with maximum depth of 5, to avoid slowdowns
                    if (!fpi.findPath(ce.getNode(0), 5) && !fpi.findPath(ce.getNode(0))) {
                        // console(ce + " no path");
                        ce.reset();
                    }
                }
                // look for current sources with no current path
                if (ce.GetType() == typeof(CurrentElm)) {
                    var cur = (CurrentElm)ce;
                    var fpi = new FindPathInfo(FindPathInfo.INDUCT, ce, ce.getNode(1), mNodeList.Count, mElmList);
                    // first try findPath with maximum depth of 5, to avoid slowdowns
                    if (!fpi.findPath(ce.getNode(0), 5) && !fpi.findPath(ce.getNode(0))) {
                        cur.stampCurrentSource(true);
                    } else {
                        cur.stampCurrentSource(false);
                    }
                }
                if (ce.GetType() == typeof(VCCSElm)) {
                    var cur = (VCCSElm)ce;
                    var fpi = new FindPathInfo(FindPathInfo.INDUCT, ce, cur.getOutputNode(0), mNodeList.Count, mElmList);
                    if (cur.hasCurrentOutput() && !fpi.findPath(cur.getOutputNode(1))) {
                        cur.broken = true;
                    } else {
                        cur.broken = false;
                    }
                }
                // look for voltage source or wire loops. we do this for voltage sources or
                // wire-like elements (not actual wires
                // because those are optimized out, so the findPath won't work)
                if (ce.getPostCount() == 2) {
                    if (ce.GetType() == typeof(VoltageElm) || (ce.isWire() && !(ce.GetType() == typeof(WireElm)))) {
                        var fpi = new FindPathInfo(FindPathInfo.VOLTAGE, ce, ce.getNode(1), mNodeList.Count, mElmList);
                        if (fpi.findPath(ce.getNode(0))) {
                            stop("Voltage source/wire loop with no resistance!", ce);
                            return;
                        }
                    }
                }

                // look for path from rail to ground
                if (ce.GetType() == typeof(RailElm)) {
                    var fpi = new FindPathInfo(FindPathInfo.VOLTAGE, ce, ce.getNode(0), mNodeList.Count, mElmList);
                    if (fpi.findPath(0)) {
                        stop("Path to ground with no resistance!", ce);
                        return;
                    }
                }

                // look for shorted caps, or caps w/ voltage but no R
                if (ce.GetType() == typeof(CapacitorElm)) {
                    var fpi = new FindPathInfo(FindPathInfo.SHORT, ce, ce.getNode(1), mNodeList.Count, mElmList);
                    if (fpi.findPath(ce.getNode(0))) {
                        //MainForm//MainForm.console(ce + " shorted");
                        ce.reset();
                    } else {
                        // a capacitor loop used to cause a matrix error. but we changed the capacitor
                        // model
                        // so it works fine now. The only issue is if a capacitor is added in parallel
                        // with
                        // another capacitor with a nonzero voltage; in that case we will get
                        // oscillation unless
                        // we reset both capacitors to have the same voltage. Rather than check for
                        // that, we just
                        // give an error.
                        fpi = new FindPathInfo(FindPathInfo.CAP_V, ce, ce.getNode(1), mNodeList.Count, mElmList);
                        if (fpi.findPath(ce.getNode(0))) {
                            stop("Capacitor loop with no resistance!", ce);
                            return;
                        }
                    }
                }
            }
            // System.out.println("ac6");

            if (!simplifyMatrix(matrixSize)) {
                return;
            }

            /*
             * System.out.println("matrixSize = " + matrixSize + " " + circuitNonLinear);
             * for (j = 0; j != circuitMatrixSize; j++) { for (i = 0; i !=
             * circuitMatrixSize; i++) System.out.print(circuitMatrix[j][i] + " ");
             * System.out.print("  " + circuitRightSide[j] + "\n"); }
             * System.out.print("\n");
             */

            // check if we called stop()
            if (mCircuitMatrix == null) {
                return;
            }

            // if a matrix is linear, we can do the lu_factor here instead of
            // needing to do it every frame
            if (!mCircuitNonLinear) {
                if (!Matrix.luFactor(mCircuitMatrix, mCircuitMatrixSize, mCircuitPermute)) {
                    stop("Singular matrix!", null);
                    return;
                }
            }

            // show resistance in voltage sources if there's only one
            bool gotVoltageSource = false;
            mShowResistanceInVoltageSources = true;
            for (i = 0; i != mElmList.Count; i++) {
                var ce = getElm(i);
                if (ce.GetType() == typeof(VoltageElm)) {
                    if (gotVoltageSource) {
                        mShowResistanceInVoltageSources = false;
                    } else {
                        gotVoltageSource = true;
                    }
                }
            }
        }
    }
}
