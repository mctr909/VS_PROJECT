﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace Test {
    unsafe public partial class Form1 : Form {
        [DllImport("Diffuse.dll", SetLastError = true, CharSet = CharSet.Auto)]
        private static extern uint diffuse_exec(IntPtr filePath, Int32 width, Int32 height, Int32 divs);
        [DllImport("Diffuse.dll", SetLastError = true, CharSet = CharSet.Auto)]
        private static extern IntPtr diffuse_alloc();

        Task mTask;
        IntPtr mProg;

        public Form1() {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e) {
            mProg = diffuse_alloc();
            timer1.Interval = 33;
            timer1.Enabled = true;
            timer1.Start();

            mTask = new Task(MainProc);
            mTask.Start();
        }

        private void MainProc() {
            var path = Marshal.StringToHGlobalAuto("C:\\Users\\9004054911\\source\\repos\\Diffuse\\data\\AAA.bin");
            diffuse_exec(path, 20000, 20000, 128);
        }

        private void timer1_Tick(object sender, EventArgs e) {
            label1.Text = Marshal.PtrToStringAuto(mProg);
            if (mTask.IsCompleted) {
                Close();
            }
        }
    }
}
