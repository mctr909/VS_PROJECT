#include "main.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define GRID_UNIT 1000
#define BUFF_UNIT 1002

const int BUFF_STRIDE = BUFF_UNIT * sizeof(GRID);
const int BUFF_SIZE = BUFF_UNIT * BUFF_UNIT * sizeof(GRID);
const int BUFF_IDX_RIGHT = BUFF_UNIT - 1;
const int BUFF_IDX_TOP = BUFF_UNIT * (BUFF_UNIT - 1);

const int GRID_STRIDE = GRID_UNIT * sizeof(GRID);
const int GRID_SIZE = GRID_UNIT * GRID_UNIT * sizeof(GRID);
const int GRID_IDX_RIGHT = GRID_UNIT - 1;
const int GRID_IDX_TOP = GRID_UNIT * (GRID_UNIT - 1);
const int GRID_OFS_TOP = GRID_UNIT * (GRID_UNIT - 1) * sizeof(GRID);

BOOL mIsExec = FALSE;
int mGridsX;
int mGridsY;

GRID *mCenterGrid;
GRID *mTempGrid;
GRID *mWriteBuff;
GRID *mReadBuff;

WCHAR mProgress[256];
WCHAR mFilePath[256];
FILE *mFpR;
FILE *mFpW;

#define FILE_SEEK(gridX, gridY) (GRID_SIZE * (mGridsX*(gridY) + gridX))

BOOL WINAPI diffuse_exec(LPWSTR path, int width, int height, int divs) {
    if (mIsExec) {
        return FALSE;
    }

    mIsExec = TRUE;

    wsprintf(mFilePath, L"%s_A", path);
    mGridsX = (int)((width + GRID_UNIT - 1) / GRID_UNIT);
    mGridsY = (int)((height + GRID_UNIT - 1) / GRID_UNIT);

    diffuse_load();

    _wfopen_s(&mFpR, mFilePath, L"wb");
    wsprintf(mFilePath, L"%s_B", path);
    _wfopen_s(&mFpW, mFilePath, L"wb");

    GRID speed = (GRID)(1.0 - 2.0 / divs);
    for (int time = 0; time < divs; time++) {
        fseek(mFpW, 0, SEEK_SET);
        for (int gridY = 0; gridY < mGridsY; gridY++) {
            for (int gridX = 0; gridX < mGridsX; gridX++) {
                fseek(mFpR, FILE_SEEK(gridX, gridY), SEEK_SET);
                fread_s(mCenterGrid, GRID_SIZE, GRID_SIZE, 1, mFpR);

                // load bottom
                {
                    if (gridY <= 0) {
                        memcpy_s(mReadBuff + 1, BUFF_SIZE, mCenterGrid, GRID_STRIDE);
                    } else {
                        fseek(mFpR, FILE_SEEK(gridX, gridY - 1) + GRID_OFS_TOP, SEEK_SET);
                        fread_s(mReadBuff + 1, BUFF_SIZE, GRID_STRIDE, 1, mFpR);
                    }
                }

                // load left
                {
                    if (gridX <= 0) {
                        int idxB = BUFF_UNIT;
                        int idxG = 0;
                        for (int y = 0; y < GRID_UNIT; y++) {
                            mReadBuff[idxB] = mCenterGrid[idxG];
                            idxB += BUFF_UNIT;
                            idxG += GRID_UNIT;
                        }
                    } else {
                        fseek(mFpR, FILE_SEEK(gridX - 1, gridY), SEEK_SET);
                        fread_s(mTempGrid, GRID_SIZE, GRID_SIZE, 1, mFpR);
                        int idxB = BUFF_UNIT;
                        int idxG = GRID_IDX_RIGHT;
                        for (int y = 0; y < GRID_UNIT; y++) {
                            mReadBuff[idxB] = mTempGrid[idxG];
                            idxB += BUFF_UNIT;
                            idxG += GRID_UNIT;
                        }
                    }
                }

                // load center grid
                {
                    int idxB = BUFF_UNIT + 1;
                    int idxG = 0;
                    for (int y = 0; y < GRID_UNIT; y++) {
                        memcpy_s(mReadBuff + idxB, BUFF_SIZE, mCenterGrid + idxG, GRID_STRIDE);
                        idxB += BUFF_UNIT;
                        idxG += GRID_UNIT;
                    }
                }

                // load right
                {
                    if ((mGridsX - 1) <= gridX) {
                        int idxB = BUFF_UNIT + BUFF_IDX_RIGHT;
                        int idxG = GRID_IDX_RIGHT;
                        for (int y = 0; y < GRID_UNIT; y++) {
                            mReadBuff[idxB] = mCenterGrid[idxG];
                            idxB += BUFF_UNIT;
                            idxG += GRID_UNIT;
                        }
                    } else {
                        fseek(mFpR, FILE_SEEK(gridX + 1, gridY), SEEK_SET);
                        fread_s(mTempGrid, GRID_SIZE, GRID_SIZE, 1, mFpR);
                        int idxB = BUFF_UNIT + BUFF_IDX_RIGHT;
                        int idxG = 0;
                        for (int y = 0; y < GRID_UNIT; y++) {
                            mReadBuff[idxB] = mTempGrid[idxG];
                            idxB += BUFF_UNIT;
                            idxG += GRID_UNIT;
                        }
                    }
                }

                // load top
                {
                    if ((mGridsY - 1) <= gridY) {
                        memcpy_s(mReadBuff + BUFF_IDX_TOP + 1, BUFF_SIZE, mCenterGrid + GRID_IDX_TOP, GRID_STRIDE);
                    } else {
                        fseek(mFpR, FILE_SEEK(gridX, gridY + 1), SEEK_SET);
                        fread_s(mReadBuff + BUFF_IDX_TOP + 1, BUFF_SIZE, GRID_STRIDE, 1, mFpR);
                    }
                }

                // calculate grid
                diffuse_calc(speed);

                // write grid
                for (int y = 0, idx = 1; y < GRID_UNIT; y++, idx += BUFF_UNIT) {
                    fwrite(mWriteBuff + idx, GRID_STRIDE, 1, mFpW);
                }

                wsprintf(mProgress, L"calculate\ntimes:%03d/%03d row:%02d/%02d(km) col:%02d/%02d(km)",
                    (time + 1), divs,
                    (gridY + 1), mGridsY,
                    (gridX + 1), mGridsX
                );
            }
        }
        FILE *fp = mFpR;
        mFpR = mFpW;
        mFpW = fp;
    }

    diffuse_free();
    mIsExec = FALSE;

    return TRUE;
}

LPWSTR WINAPI diffuse_alloc() {
    if (mIsExec) {
        return NULL;
    }

    diffuse_free();

    mCenterGrid = (GRID*)malloc(GRID_SIZE);
    if (NULL == mCenterGrid) {
        diffuse_free();
        return NULL;
    }
    mTempGrid = (GRID*)malloc(GRID_SIZE);
    if (NULL == mTempGrid) {
        diffuse_free();
        return NULL;
    }
    mWriteBuff = (GRID*)malloc(BUFF_SIZE);
    if (NULL == mWriteBuff) {
        diffuse_free();
        return NULL;
    }
    mReadBuff = (GRID*)malloc(BUFF_SIZE);
    if (NULL == mReadBuff) {
        diffuse_free();
        return NULL;
    }

    return mProgress;
}

void diffuse_free() {
    if (NULL != mCenterGrid) {
        free(mCenterGrid);
        mCenterGrid = NULL;
    }
    if (NULL != mTempGrid) {
        free(mTempGrid);
        mTempGrid = NULL;
    }
    if (NULL != mWriteBuff) {
        free(mWriteBuff);
        mWriteBuff = NULL;
    }
    if (NULL != mReadBuff) {
        free(mReadBuff);
        mReadBuff = NULL;
    }

    if (NULL != mFpR) {
        fclose(mFpR);
        mFpR = NULL;
    }
    if (NULL != mFpW) {
        fclose(mFpW);
        mFpW = NULL;
    }
}

void diffuse_load() {
    FILE *fp;
    _wfopen_s(&fp, mFilePath, L"wb");
    memset(mWriteBuff, 0, BUFF_SIZE);
    for (int y = 0; y < mGridsY; y++) {
        for (int x = 0; x < mGridsX; x++) {
            fwrite(mWriteBuff, GRID_SIZE, 1, fp);
            wsprintf(mProgress, L"data load\nrow:%02d/%02d(km) col:%02d/%02d(km)",
                (y + 1), mGridsY,
                (x + 1), mGridsX
            );
        }
    }
    fclose(fp);
    printf("\n");
}

inline void diffuse_calc(GRID speed) {
    memcpy_s(mWriteBuff, BUFF_SIZE, mReadBuff, BUFF_SIZE);
    GRID *fBottom = mReadBuff + 1;
    GRID *fMiddle = fBottom + BUFF_UNIT;
    GRID *fTop = fMiddle + BUFF_UNIT;
    GRID *fOut = mWriteBuff + BUFF_UNIT + 1;
    for (int y = 0; y < GRID_UNIT; y++) {
        for (int x = 0; x < GRID_UNIT; x++) {
            GRID d2F = fBottom[x];
            d2F += fMiddle[x - 1];
            d2F -= fMiddle[x] * 4;
            d2F += fMiddle[x + 1];
            d2F += fTop[x];
            fOut[x] += speed * d2F * (GRID)0.25;
        }
        fBottom += BUFF_UNIT;
        fMiddle += BUFF_UNIT;
        fTop += BUFF_UNIT;
        fOut += BUFF_UNIT;
    }
}
