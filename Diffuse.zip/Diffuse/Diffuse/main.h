#pragma once
#include <windows.h>

typedef float GRID;

__declspec(dllexport) BOOL WINAPI diffuse_exec(LPWSTR path, int width, int height, int divs);
__declspec(dllexport) LPWSTR WINAPI diffuse_alloc();
void diffuse_free();
void diffuse_load();
inline void diffuse_calc(GRID speed);
