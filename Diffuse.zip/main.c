#include "main.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef float GRID;

BOOL diffuse_alloc();
void diffuse_free();
void diffuse_load();
void diffuse_calc(GRID speed);

#define GRID_UNIT 1000
#define BUFF_UNIT 1002

static const int BUFF_STRIDE = BUFF_UNIT * sizeof(GRID);
static const int BUFF_SIZE = BUFF_UNIT * BUFF_UNIT * sizeof(GRID);
static const int BUFF_INDEX_RIGHT = BUFF_UNIT - 1;
static const int BUFF_INDEX_TOP = BUFF_UNIT * (BUFF_UNIT - 1);

static const int GRID_STRIDE = GRID_UNIT * sizeof(GRID);
static const int GRID_SIZE = GRID_UNIT * GRID_UNIT * sizeof(GRID);
static const int GRID_INDEX_RIGHT = GRID_UNIT - 1;
static const int GRID_INDEX_TOP = GRID_UNIT * (GRID_UNIT - 1);
static const int GRID_OFS_TOP = GRID_UNIT * (GRID_UNIT - 1) * sizeof(GRID);

int mGridsX;
int mGridsY;

GRID *mCenter = NULL;
GRID *mSide = NULL;
GRID *mBuffW = NULL;
GRID *mBuffR = NULL;

char mFilePath[256];
FILE *mFpR = NULL;
FILE *mFpW = NULL;

#define FILE_SEEK(gridX, gridY) (GRID_SIZE * (mGridsX*(gridY) + gridX))

int main() {
    diffuse("C:\\Users\\9004054911\\source\\repos\\Diffuse\\data\\AAA.bin", 5000, 5000, 128);
    return;
}

void diffuse(LPSTR path, int width, int height, int divs) {
    if (!diffuse_alloc()) {
        return;
    }

    wsprintf(mFilePath, "%s_A", path);
    mGridsX = (int)((width + GRID_UNIT - 1) / GRID_UNIT);
    mGridsY = (int)((height + GRID_UNIT - 1) / GRID_UNIT);

    diffuse_load();

    fopen_s(&mFpR, mFilePath, "wb");
    wsprintf(mFilePath, "%s_B", path);
    fopen_s(&mFpW, mFilePath, "wb");

    GRID speed = (GRID)(1.0 - 2.0 / divs);
    for (int dt = 0; dt < divs; dt++) {
        fseek(mFpR, 0, SEEK_SET);
        fseek(mFpW, 0, SEEK_SET);
        for (int gridY = 0; gridY < mGridsY; gridY++) {
            for (int gridX = 0; gridX < mGridsX; gridX++) {
                fseek(mFpR, FILE_SEEK(gridX, gridY), SEEK_SET);
                fread_s(mCenter, GRID_SIZE, GRID_SIZE, 1, mFpR);

                // load bottom
                {
                    if (gridY <= 0) {
                        memcpy_s(mBuffR + 1, BUFF_SIZE, mCenter, GRID_STRIDE);
                    } else {
                        fseek(mFpR, FILE_SEEK(gridX, gridY - 1) + GRID_OFS_TOP, SEEK_SET);
                        fread_s(mBuffR + 1, BUFF_SIZE, GRID_STRIDE, 1, mFpR);
                    }
                }

                // load left
                {
                    if (gridX <= 0) {
                        int idxB = BUFF_UNIT;
                        int idxG = 0;
                        for (int y = 0; y < GRID_UNIT; y++) {
                            mBuffR[idxB] = mCenter[idxG];
                            idxB += BUFF_UNIT;
                            idxG += GRID_UNIT;
                        }
                    } else {
                        fseek(mFpR, FILE_SEEK(gridX - 1, gridY), SEEK_SET);
                        fread_s(mSide, GRID_SIZE, GRID_SIZE, 1, mFpR);
                        int idxB = BUFF_UNIT;
                        int idxG = GRID_INDEX_RIGHT;
                        for (int y = 0; y < GRID_UNIT; y++) {
                            mBuffR[idxB] = mSide[idxG];
                            idxB += BUFF_UNIT;
                            idxG += GRID_UNIT;
                        }
                    }
                }

                // load center grid
                {
                    int idxB = BUFF_UNIT + 1;
                    int idxG = 0;
                    for (int y = 0; y < GRID_UNIT; y++) {
                        memcpy_s(mBuffR + idxB, BUFF_SIZE, mCenter + idxG, GRID_STRIDE);
                        idxB += BUFF_UNIT;
                        idxG += GRID_UNIT;
                    }
                }

                // load right
                {
                    if ((mGridsX - 1) <= gridX) {
                        int idxB = BUFF_UNIT + BUFF_INDEX_RIGHT;
                        int idxG = GRID_INDEX_RIGHT;
                        for (int y = 0; y < GRID_UNIT; y++) {
                            mBuffR[idxB] = mCenter[idxG];
                            idxB += BUFF_UNIT;
                            idxG += GRID_UNIT;
                        }
                    } else {
                        fseek(mFpR, FILE_SEEK(gridX + 1, gridY), SEEK_SET);
                        fread_s(mSide, GRID_SIZE, GRID_SIZE, 1, mFpR);
                        int idxB = BUFF_UNIT + BUFF_INDEX_RIGHT;
                        int idxG = 0;
                        for (int y = 0; y < GRID_UNIT; y++) {
                            mBuffR[idxB] = mSide[idxG];
                            idxB += BUFF_UNIT;
                            idxG += GRID_UNIT;
                        }
                    }
                }

                // load top
                {
                    if ((mGridsY - 1) <= gridY) {
                        memcpy_s(mBuffR + BUFF_INDEX_TOP + 1, BUFF_SIZE, mCenter + GRID_INDEX_TOP, GRID_STRIDE);
                    } else {
                        fseek(mFpR, FILE_SEEK(gridX, gridY + 1), SEEK_SET);
                        fread_s(mBuffR + BUFF_INDEX_TOP + 1, BUFF_SIZE, GRID_STRIDE, 1, mFpR);
                    }
                }

                // execute
                diffuse_calc(speed);

                // write
                for (int y = 0, idxC = 1; y < GRID_UNIT; y++, idxC += BUFF_UNIT) {
                    fwrite(mBuffW + idxC, GRID_STRIDE, 1, mFpW);
                }

                printf("\rcalculate:%06.2f%% (X:%02d/%02d Y:%02d/%02d times:%03d/%03d)",
                    100.0 * (mGridsX*mGridsY*dt + mGridsX * gridY + gridX) / (mGridsX*mGridsY*divs),
                    (gridX + 1), mGridsX,
                    (gridY + 1), mGridsY,
                    (dt + 1), divs
                );
            }
        }
        FILE *fp = mFpR;
        mFpR = mFpW;
        mFpW = fp;
    }

    free(mBuffW);
    free(mBuffR);
    fclose(mFpR);
    fclose(mFpW);
}

BOOL diffuse_alloc() {
    mCenter = (GRID*)malloc(GRID_SIZE);
    if (NULL == mCenter) {
        diffuse_free();
        return FALSE;
    }
    mSide = (GRID*)malloc(GRID_SIZE);
    if (NULL == mSide) {
        diffuse_free();
        return FALSE;
    }
    mBuffW = (GRID*)malloc(BUFF_SIZE);
    if (NULL == mBuffW) {
        diffuse_free();
        return FALSE;
    }
    mBuffR = (GRID*)malloc(BUFF_SIZE);
    if (NULL == mBuffR) {
        diffuse_free();
        return FALSE;
    }
    printf("allocate:%dMB\n", (2 * BUFF_SIZE + 2*GRID_SIZE) / 1000 / 1000);
    return TRUE;
}

void diffuse_free() {
    if (NULL != mCenter) {
        free(mCenter);
        mCenter = NULL;
    }
    if (NULL != mSide) {
        free(mSide);
        mSide = NULL;
    }
    if (NULL != mBuffW) {
        free(mBuffW);
        mBuffW = NULL;
    }
    if (NULL != mBuffR) {
        free(mBuffR);
        mBuffR = NULL;
    }
    if (NULL != mFpR) {
        fclose(mFpR);
        mFpR = NULL;
    }
    if (NULL != mFpW) {
        fclose(mFpW);
        mFpW = NULL;
    }
}

void diffuse_load() {
    FILE *fp;
    fopen_s(&fp, mFilePath, "wb");
    memset(mBuffW, 0, BUFF_SIZE);
    for (int y = 0; y < mGridsY; y++) {
        for (int x = 0; x < mGridsX; x++) {
            fwrite(mBuffW, GRID_SIZE, 1, fp);
            printf("\rdata load:%06.2f%% (X:%02d/%02d Y:%02d/%02d)",
                100.0 * (mGridsX*y + x + 1) / (mGridsX*mGridsY),
                (x + 1), mGridsX,
                (y + 1), mGridsY
            );
        }
    }
    fclose(fp);
    printf("\n");
}

void diffuse_calc(GRID speed) {
    for (int y = 1; y <= GRID_UNIT; y++) {
        int ofsM = BUFF_UNIT * y;
        GRID *fB = &mBuffR[ofsM - BUFF_UNIT];
        GRID *fM = &mBuffR[ofsM];
        GRID *fT = &mBuffR[ofsM + BUFF_UNIT];
        for (int x = 1; x <= GRID_UNIT; x++) {
            GRID d2F = fB[x];
            d2F += fM[x - 1];
            d2F -= fM[x] * 4;
            d2F += fM[x + 1];
            d2F += fT[x];
            d2F *= 0.25;
            mBuffW[ofsM + x] = fM[x] + d2F * speed;
        }
    }
}
