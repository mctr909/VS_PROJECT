#pragma once
#include <Windows.h>

void diffuse(LPSTR path, int width, int height, int divs);
