﻿namespace Midi {
    public class Meta {
        public readonly uint Length;
        public readonly META_TYPE Type;
        public readonly byte[] Data;

        public double BPM {
            get { return 60000000.0 / ((Data[0] << 16) | (Data[1] << 8) | Data[2]); }
        }

        public string Text {
            get { return System.Text.Encoding.GetEncoding("shift-jis").GetString(Data); }
        }

        public KEY Key {
            get { return (KEY)((Data[0] << 8) | Data[1]); }
        }

        public new string ToString {
            get {
                switch (Type) {
                    case META_TYPE.SEQ_NO:
                        return string.Format("[{0}]\t{1}", Type, (Data[0] << 8) | Data[1]);

                    case META_TYPE.TEXT:
                    case META_TYPE.COMPOSER:
                    case META_TYPE.SEQ_NAME:
                    case META_TYPE.INST_NAME:
                    case META_TYPE.LYRIC:
                    case META_TYPE.MARKER:
                    case META_TYPE.PRG_NAME:
                        return string.Format("[{0}]\t\"{1}\"", Type, Text);

                    case META_TYPE.CH_PREFIX:
                    case META_TYPE.PORT:
                        return string.Format("[{0}]\t{1}", Type, Data[0]);

                    case META_TYPE.TEMPO:
                        return string.Format("[{0}]\t{1}", Type, BPM.ToString("0.00"));

                    case META_TYPE.MEASURE:
                        return string.Format("[{0}]\t{1}/{2} ({3}, {4})", Type, Data[0], (int)System.Math.Pow(2.0, Data[1]), Data[2], Data[3]);

                    case META_TYPE.KEY:
                        return string.Format("[{0}]\t{1}", Type, Key);

                    case META_TYPE.META:
                        return string.Format("[{0}]\t{1}", Type, System.BitConverter.ToString(Data));

                    default:
                        return string.Format("[{0}]", Type);
                }
            }
        }
    }

    public class SystemEx {
        public readonly uint Length;
        public readonly byte[] Data;

        public SystemEx(byte[] data) {
            Length = (uint)data.Length;
            Data = data;
        }
    }

    public struct Message {
        public byte Status;
        public byte[] Data;

        public EVENT_TYPE Type {
            get { return (EVENT_TYPE)((0xF0 <= Status) ? Status : (Status & 0xF0)); }
        }

        public int Channel {
            get { return (Status & 0x0F); }
        }

        public Message(params int[] data) {
            Status = (byte)data[0];
            Data = new byte[data.Length - 1];
            for (var i = 0; i < Data.Length; ++i) {
                Data[i] = (byte)data[i + 1];
            }
        }

        public Message(EVENT_TYPE type, byte channel = 0, params byte[] data) {
            Status = (byte)((int)type | channel);
            Data = data;
        }

        public Message(CTRL_TYPE type, byte channel, byte value = 0) {
            Status = (byte)((int)EVENT_TYPE.CTRL_CHG | channel);
            Data = new byte[2];
            Data[0] = (byte)type;
            Data[1] = value;
        }
    }
}
