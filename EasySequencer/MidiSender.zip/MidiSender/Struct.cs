﻿using System;
using System.Runtime.InteropServices;

namespace Midi {
    [StructLayout(LayoutKind.Sequential, Pack = 4)]
    public struct INST_ID {
        public byte isDrum;
        public byte programNo;
        public byte bankMSB;
        public byte bankLSB;
    };

    [StructLayout(LayoutKind.Sequential, Pack = 4)]
    public struct CONTROL {
        public byte vol;
        public byte exp;
        public byte pan;
        public byte reserve1;

        public byte rev;
        public byte cho;
        public byte del;
        public byte reserve2;

        public byte res;
        public byte cut;
        public byte atk;
        public byte rel;

        public byte vibRate;
        public byte vibDepth;
        public byte vibDelay;
        public byte reserve3;

        public byte bendRange;
        public byte hold;
        public byte reserve4;
        public byte reserve5;

        public byte nrpnMSB;
        public byte nrpnLSB;
        public byte rpnMSB;
        public byte rpnLSB;
    };

    [StructLayout(LayoutKind.Sequential, Pack = 4)]
    public struct WAVE_LOOP {
        public uint start;
        public uint length;
        public bool enable;
        private byte reserved1;
        private byte reserved2;
        private byte reserved3;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 4)]
    public struct FILTER {
        public double cutoff;
        public double resonance;
        public double pole00;
        public double pole01;
        public double pole02;
        public double pole03;
        public double pole10;
        public double pole11;
        public double pole12;
        public double pole13;
    };

    [StructLayout(LayoutKind.Sequential, Pack = 4)]
    public struct DELAY {
        public double depth;
        public double rate;
        private IntPtr pTapL;
        private IntPtr pTapR;
        private Int32 writeIndex;
        private Int32 readIndex;
    };

    [StructLayout(LayoutKind.Sequential, Pack = 4)]
    public struct CHORUS {
        public double depth;
        public double rate;
        private double lfoK;
        private IntPtr pPanL;
        private IntPtr pPanR;
        private IntPtr pLfoRe;
        private IntPtr pLfoIm;
    };

    [StructLayout(LayoutKind.Sequential, Pack = 4)]
    public struct ENVELOPE {
        public double levelA;
        public double levelD;
        public double levelS;
        public double levelR;
        public double deltaA;
        public double deltaD;
        public double deltaR;
        public double hold;
    };

    [StructLayout(LayoutKind.Sequential, Pack = 4)]
    unsafe public struct CHANNEL {
        public double wave;
        public double waveL;
        public double waveR;

        public double pitch;
        public double holdDelta;

        public double panLeft;
        public double panRight;

        public double tarCutoff;
        public double tarAmp;
        public double curAmp;

        public FILTER eq;
        public DELAY delay;
        public CHORUS chorus;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 4)]
    unsafe public struct SAMPLER {
        public ushort channelNo;
        public ushort noteNo;

        public bool onKey;
        public bool isActive;

        public uint pcmAddr;
        public uint pcmLength;

        public bool loopEnable;
        public uint loopBegin;
        public uint loopLength;

        public double gain;
        public double delta;

        public double index;
        public double time;

        public double tarAmp;
        public double curAmp;

        public ENVELOPE envAmp;
        public ENVELOPE envEq;

        public FILTER eq;
    };

    public struct WAVE_INFO {
        public uint pcmAddr;
        public uint pcmLength;
        public double gain;
        public double delta;
        public byte unityNote;
        public WAVE_LOOP loop;
        public ENVELOPE envAmp;
    }
}
