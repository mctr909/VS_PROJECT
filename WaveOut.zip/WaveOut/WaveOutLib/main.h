#pragma once
#include <windows.h>

/******************************************************************************/
#ifdef __cplusplus
extern "C" {
#endif
    __declspec(dllexport) BOOL WINAPI open(
        int sampleRate,
        int bits,
        int bufferLength,
        int bufferCount,
        int channelCount
    );
    __declspec(dllexport) void WINAPI close();
#ifdef __cplusplus
}
#endif
