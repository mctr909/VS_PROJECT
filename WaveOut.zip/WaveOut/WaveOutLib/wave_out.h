#pragma once
#include <windows.h>

/******************************************************************************/
BOOL waveout_open(
    int sampleRate,
    int bits,
    int bufferLength,
    int bufferCount,
    int channelCount,
    void (*fpWriteBufferProc)(LPBYTE)
);
void waveout_close();
