#include "main.h"
#include "wave_out.h"

#include <math.h>

/******************************************************************************/
int gSampleRate;
int gBufferLength;

/******************************************************************************/
void stereo16(LPBYTE lpData);

/******************************************************************************/
BOOL WINAPI open(
    int sampleRate,
    int bits,
    int bufferLength,
    int bufferCount,
    int channelCount
) {
    gSampleRate = sampleRate;
    gBufferLength = bufferLength;

    void(*fpWriteBuffer)(LPBYTE) = NULL;

    switch (channelCount) {
    case 2:
        switch (bits) {
        case 16:
            fpWriteBuffer = stereo16;
            break;
        default:
            break;
        }
        break;
    default:
        break;
    }

    if (NULL == fpWriteBuffer) {
        return FALSE;
    } else {
        return waveout_open(sampleRate, bits, bufferLength, bufferCount, channelCount, fpWriteBuffer);
    }
}

void WINAPI close() {
    waveout_close();
}

/******************************************************************************/
double th;

void stereo16(LPBYTE lpData) {
    int i, j;
    short *bf = (short*)lpData;
    double omega = 220 * 8 * atan(1) / gSampleRate;

    for (i = 0, j = 0; i < gBufferLength; i++, j += 2) {
        bf[j] = (short)(8192 * sin(th));
        bf[j + 1] = (short)(8192 * sin(3*th));
        th += omega;
    }
}
