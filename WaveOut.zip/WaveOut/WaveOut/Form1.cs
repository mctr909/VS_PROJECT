﻿using System;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace WaveOut {
    public partial class Form1 : Form {
        [DllImport("WaveOutLib.dll")]
        private static extern bool open(
            int sampleRate,
            int bits,
            int bufferLength,
            int bufferCount,
            int channelCount
        );
        [DllImport("WaveOutLib.dll")]
        private static extern void close();

        public Form1() {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e) {
            open(44100, 16, 512, 16, 2);
        }

        private void button2_Click(object sender, EventArgs e) {
            close();
        }
    }
}
