package com.lushprojects.circuitjs1.client;




public class ComparatorElm extends CompositeElm {
    
    private static String modelString = "OpAmpElm 1 2 3\rAnalogSwitchElm 4 5 3\rGroundElm 5";
    private static int[] modelExternalNodes = {2, 1, 4};
    final int FLAG_SMALL = 2;
    int opsize, opheight, opwidth;
	Point in1p[], in2p[], textp[];
	Polygon triangle;
	Font plusFont;
    
    public ComparatorElm(int xx, int yy) {
	super(xx, yy, modelString, modelExternalNodes);
	mIsNoDiagonal = true;
	setSize(form.smallGridCheckItem.getState() ? 1 : 2);
    }
    

    public ComparatorElm(int xa, int ya, int xb, int yb, int f, StringTokenizer st) {
	super(xa, ya, xb, yb, f, st, modelString, modelExternalNodes);
	mIsNoDiagonal = true;
	setSize((f & FLAG_SMALL) != 0 ? 1 : 2);
    }
    
    public int getDumpType() {
	return 401;
    }
    
	void setSize(int s) {
	    opsize = s;
	    opheight = 8*s;
	    opwidth = 13*s;
	    flags = (flags & ~FLAG_SMALL) | ((s == 1) ? FLAG_SMALL : 0);
	}
	
	public boolean getConnection(int n1, int n2) { return false; }
	
	void draw(Graphics g) {
	    setBbox(POSA, POSB, opheight*2);
	    setVoltageColor(g, volts[0]);
	    Drawer.drawThickLine(g, in1p[0], in1p[1]);
	    setVoltageColor(g, volts[1]);
	    Drawer.drawThickLine(g, in2p[0], in2p[1]);
	    g.setColor(needsHighlight() ? Drawer.COLOR_SELECT : Drawer.COLOR_LIGHT_GRAY);
	    setPowerColor(g, true);
	    Drawer.drawThickPolygon(g, triangle);
	    g.setFont(plusFont);
	    drawCenteredText(g, "-", textp[0].x, textp[0].y-2, true);
	    drawCenteredText(g, "+", textp[1].x, textp[1].y  , true);
	    drawCenteredText(g, "\u2265?", textp[2].x, textp[2].y  , true);
	    setVoltageColor(g, volts[2]);
	    Drawer.drawThickLine(g, mLead2, POSB);
	    curcount = updateDotCount(-getCurrentIntoNode(2), curcount);
	    Drawer.drawDots(g, POSB, mLead2, curcount);
	    drawPosts(g);
	}

	void setPoints() {
	    super.setPoints();
	    if (mLen > 150 && this == form.dragElm)
		setSize(2);
	    int ww = opwidth;
	    if (ww > mLen/2)
		ww = (int) (mLen/2);
	    calcLeads(ww*2);
	    int hs = opheight*mDSign;
//	    if ((flags & FLAG_SWAP) != 0)
//		hs = -hs;
	    in1p = Drawer.newPointArray(2);
	    in2p = Drawer.newPointArray(2);
	    textp = Drawer.newPointArray(3);
	    Drawer.interpPoint2(POSA, POSB, in1p[0],  in2p[0], 0, hs);
	    Drawer.interpPoint2(mLead1 , mLead2,  in1p[1],  in2p[1], 0, hs);
	    Drawer.interpPoint2(mLead1 , mLead2,  textp[0], textp[1], .2, hs);
	    Drawer.interpPoint(mLead1, mLead2, textp[2], 0.5, 0);
	    Point tris[] = Drawer.newPointArray(2);
	    Drawer.interpPoint2(mLead1,  mLead2,  tris[0], tris[1],  0, hs*2);
	    triangle = Drawer.createPolygon(tris[0], tris[1], mLead2);
	    plusFont = new Font("SansSerif", 0, opsize == 2 ? 14 : 10);
		setPost(0, in1p[0]);
		setPost(1,in2p[0]);
		setPost(2,POSB);
	}
	
	
    
    void getInfo(String arr[]) {
	 arr[0] = "Comparator";
	    arr[1] = "V+ = " + Drawer.getVoltageText(volts[1]);
	    arr[2] = "V- = " + Drawer.getVoltageText(volts[0]);
    }
}
