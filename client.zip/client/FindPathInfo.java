package com.lushprojects.circuitjs1.client;

import java.util.Vector;

public final class FindPathInfo {
	static final int INDUCT = 1;
	static final int VOLTAGE = 2;
	static final int SHORT = 3;
	static final int CAP_V = 4;

	public int type;
	public BaseElement firstElm;
	public int dest;
	public boolean used[];
	private Vector<BaseElement> elmList;

	public FindPathInfo(int type, BaseElement firstElm, int dest, int nodeCount, Vector<BaseElement> elmList) {
		this.type = type;
		this.firstElm = firstElm;
		this.dest = dest;
		used = new boolean[nodeCount];
		this.elmList = elmList;
	}

	public boolean findPath(int n1) {
		return findPath(n1, -1);
	}

	public boolean findPath(int n1, int depth) {
		if (n1 == dest)
			return true;
		if (depth-- == 0)
			return false;
		if (used[n1]) {
			// System.out.println("used " + n1);
			return false;
		}
		used[n1] = true;
		int i;
		for (i = 0; i != elmList.size(); i++) {
			BaseElement ce = getElm(i);
			if (ce == firstElm)
				continue;
			if (type == INDUCT) {
				// inductors need a path free of current sources
				if (ce instanceof CurrentElm)
					continue;
			}
			if (type == VOLTAGE) {
				// when checking for voltage loops, we only care about voltage
				// sources/wires/ground
				if (!(ce.isWire() || ce instanceof VoltageElm || ce instanceof GroundElm))
					continue;
			}
			// when checking for shorts, just check wires
			if (type == SHORT && !ce.isWire())
				continue;
			if (type == CAP_V) {
				// checking for capacitor/voltage source loops
				if (!(ce.isWire() || ce instanceof CapacitorElm || ce instanceof VoltageElm))
					continue;
			}
			if (n1 == 0) {
				// look for posts which have a ground connection;
				// our path can go through ground
				int j;
				for (j = 0; j != ce.getConnectionNodeCount(); j++) {
					if (ce.hasGroundConnection(j) && findPath(ce.getConnectionNode(j), depth)) {
						used[n1] = false;
						return true;
					}
				}
			}
			int j;
			for (j = 0; j != ce.getConnectionNodeCount(); j++) {
				// System.out.println(ce + " " + ce.getNode(j));
				if (ce.getConnectionNode(j) == n1)
					break;
			}
			if (j == ce.getConnectionNodeCount())
				continue;
			if (ce.hasGroundConnection(j) && findPath(0, depth)) {
				// System.out.println(ce + " has ground");
				used[n1] = false;
				return true;
			}
			if (type == INDUCT && ce instanceof InductorElm) {
				// inductors can use paths with other inductors of matching current
				double c = ce.getCurrent();
				if (j == 0) {
					c = -c;
				}
				// System.out.println("matching " + c + " to " + firstElm.getCurrent());
				// System.out.println(ce + " " + firstElm);
				if (Math.abs(c - firstElm.getCurrent()) > 1e-10)
					continue;
			}
			int k;
			for (k = 0; k != ce.getConnectionNodeCount(); k++) {
				if (j == k)
					continue;
				// console(ce + " " + ce.getNode(j) + "-" + ce.getNode(k));
				if (ce.getConnection(j, k) && findPath(ce.getConnectionNode(k), depth)) {
					// System.out.println("got findpath " + n1);
					used[n1] = false;
					return true;
				}
				// System.out.println("back on findpath " + n1);
			}
		}
		used[n1] = false;
		// System.out.println(n1 + " failed");
		return false;
	}

	private BaseElement getElm(int n) {
		if (n >= elmList.size()) {
			return null;
		}
		return elmList.elementAt(n);
	}
}
