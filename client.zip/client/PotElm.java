/*    
    Copyright (C) Paul Falstad and Iain Sharp
    
    This file is part of CircuitJS1.

    CircuitJS1 is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 2 of the License, or
    (at your option) any later version.

    CircuitJS1 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
*/

package com.lushprojects.circuitjs1.client;

import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.Command;
import com.google.gwt.event.dom.client.MouseWheelEvent;
import com.google.gwt.event.dom.client.MouseWheelHandler;

class PotElm extends BaseElement implements Command, MouseWheelHandler {
    final int FLAG_SHOW_VALUES = 1;
	double position, maxResistance, resistance1, resistance2;
	double current1, current2, current3;
	double curcount1, curcount2, curcount3;
	Scrollbar slider;
	Label label;
	String sliderText;
	public PotElm(int xx, int yy) {
		super(xx, yy);
		setup();
		maxResistance = 1000;
		position = .5;
		sliderText = "Resistance";
		flags = FLAG_SHOW_VALUES;
		createSlider();
	}
    
    public PotElm(int xa, int ya, int xb, int yb, int f,
    		StringTokenizer st) {
    	super(xa, ya, xb, yb, f);
    	maxResistance = new Double(st.nextToken()).doubleValue();
    	position = new Double(st.nextToken()).doubleValue();
    	sliderText = st.nextToken();
    	while (st.hasMoreTokens())
    		sliderText += ' ' + st.nextToken();
    	createSlider();
    }
    
    void setup() {
    }
    
    int getPostCount() { return 3; }
    int getDumpType() { return 174; }
    
    Point getPost(int n) {
	return (n == 0) ? POSA : (n == 1) ? POSB : post3;
    }
    
    String dump() { return super.dump() + " " + maxResistance + " " +
    		position + " " + sliderText; }
    
    void createSlider() {
    	form.addWidgetToVerticalPanel(label = new Label(sliderText));
    	label.addStyleName("topSpace");
    	int value = (int) (position*100);
    	form.addWidgetToVerticalPanel(slider = new Scrollbar(Scrollbar.HORIZONTAL, value, 1, 0, 101, this, this));
   // 	sim.verticalPanel.validate();
   // 	slider.addAdjustmentListener(this);
    }
    
    public void execute() {
	cir.mAnalyzeFlag = true;
	setPoints();
    }
    
    void delete() {
	form.removeWidgetFromVerticalPanel(label);
	form.removeWidgetFromVerticalPanel(slider);
        super.delete();
    }
    
    Point post3, corner2, arrowPoint, midpoint, arrow1, arrow2;
    Point ps3, ps4;
    int bodyLen;
    
    void setPoints() {
	super.setPoints();
	int offset = 0;
	int myLen =0;
	if (abs(mDX) > abs(mDY)) {
	    myLen =  2 * form.gridSize * Integer.signum(mDX) * ((((Integer)Math.abs(mDX))+ 2 * form.gridSize -1) / (2 * form.gridSize));
	    POSB.x =  POSA.x + myLen;
	    offset = (mDX < 0) ? mDY : -mDY;
	    POSB.y = POSA.y;
	} else {
	    myLen =  2 * form.gridSize * Integer.signum(mDY) * ((((Integer)Math.abs(mDY))+ 2 * form.gridSize -1) / (2 * form.gridSize));
	    if (mDY != 0) {
		POSB.y = POSA.y + myLen;
		offset = (mDY > 0) ? mDX : -mDX;
		POSB.x = POSA.x;
	    }
	}
//	if (abs(dx) > abs(dy)) {
//	    dx = Integer.signum(dx) * sim.snapGrid(Math.abs(dx) / 2) * 2;
//	    point2.x = x2 = point1.x + dx;
//	    offset = (dx < 0) ? dy : -dy;
//	    point2.y = point1.y;
//	} else {
//	    dy = Integer.signum(dy) * sim.snapGrid(Math.abs(dy) / 2) * 2;
//	    if (dy != 0) {
//		point2.y = y2 = point1.y + dy;
//		offset = (dy > 0) ? dx : -dx;
//		point2.x = point1.x;
//	    }
//	}
	if (offset == 0)
	    offset = form.gridSize;
	mLen = distance(POSA, POSB);
	int bodyLen = 32;
	calcLeads(bodyLen);
	position = slider.getValue() * .0099 + .005;
	int soff = (int) ((position - .5) * bodyLen);
	// int offset2 = offset - sign(offset)*4;
	post3 = Drawer.interpPoint(POSA, POSB, .5, offset);
	corner2 = Drawer.interpPoint(POSA, POSB, soff / mLen + .5, offset);
	arrowPoint = Drawer.interpPoint(POSA, POSB, soff / mLen + .5, 8 * sign(offset));
	midpoint = Drawer.interpPoint(POSA, POSB, soff / mLen + .5);
	arrow1 = new Point();
	arrow2 = new Point();
	double clen = abs(offset) - 8;
	Drawer.interpPoint2(corner2, arrowPoint, arrow1, arrow2, (clen - 8) / clen, 8);
	ps3 = new Point();
	ps4 = new Point();
    }
    
	
    void draw(Graphics g) {
	int segments = 16;
	int i;
	int ox = 0;
	int hs = form.euroResistorCheckItem.getState() ? 6 : 8;
	double v1 = volts[0];
	double v2 = volts[1];
	double v3 = volts[2];
	setBbox(POSA, POSB, hs);
	draw2Leads(g);
	setPowerColor(g, true);
	double segf = 1./segments;
	int divide = (int) (segments*position);
	if (!form.euroResistorCheckItem.getState()) {
	    // draw zigzag
	    for (i = 0; i != segments; i++) {
		int nx = 0;
		switch (i & 3) {
		case 0: nx = 1; break;
		case 2: nx = -1; break;
		default: nx = 0; break;
		}
		double v = v1+(v3-v1)*i/divide;
		if (i >= divide)
		    v = v3+(v2-v3)*(i-divide)/(segments-divide);
		setVoltageColor(g, v);
		Drawer.interpPoint(mLead1, mLead2, POSA, i*segf, hs*ox);
		Drawer.interpPoint(mLead1, mLead2, POSB, (i+1)*segf, hs*nx);
		Drawer.drawThickLine(g, POSA, POSB);
		ox = nx;
	    }
	} else {
	    // draw rectangle
	    setVoltageColor(g, v1);
	    Drawer.interpPoint2(mLead1, mLead2, POSA, POSB, 0, hs);
	    Drawer.drawThickLine(g, POSA, POSB);
	    for (i = 0; i != segments; i++) {
		double v = v1+(v3-v1)*i/divide;
		if (i >= divide)
		    v = v3+(v2-v3)*(i-divide)/(segments-divide);
		setVoltageColor(g, v);
		Drawer.interpPoint2(mLead1, mLead2, POSA, POSB, i*segf, hs);
		Drawer.interpPoint2(mLead1, mLead2, ps3, ps4, (i+1)*segf, hs);
		Drawer.drawThickLine(g, POSA, ps3);
		Drawer.drawThickLine(g, POSB, ps4);
	    }
	    Drawer.interpPoint2(mLead1, mLead2, POSA, POSB, 1, hs);
	    Drawer.drawThickLine(g, POSA, POSB);
	}
	setVoltageColor(g, v3);
	Drawer.drawThickLine(g, post3, corner2);
	Drawer.drawThickLine(g, corner2, arrowPoint);
	Drawer.drawThickLine(g, arrow1, arrowPoint);
	Drawer.drawThickLine(g, arrow2, arrowPoint);
	curcount1 = updateDotCount(current1, curcount1);
	curcount2 = updateDotCount(current2, curcount2);
	curcount3 = updateDotCount(current3, curcount3);
	if (form.dragElm != this) {
	    Drawer.drawDots(g, POSA, midpoint, curcount1);
	    Drawer.drawDots(g, POSB, midpoint, curcount2);
	    Drawer.drawDots(g, post3, corner2, curcount3);
	    Drawer.drawDots(g, corner2, midpoint,
		     curcount3+distance(post3, corner2));
	}
	drawPosts(g);

	if (form.showValuesCheckItem.getState() && resistance1 > 0 && (flags & FLAG_SHOW_VALUES) != 0) {
	    // check for vertical pot with 3rd terminal on left
	    boolean reverseY = (post3.x < mLead1.x && mLead1.x == mLead2.x);
	    // check for horizontal pot with 3rd terminal on top
	    boolean reverseX = (post3.y < mLead1.y && mLead1.x != mLead2.x);
	    // check if we need to swap texts (if leads are reversed, e.g. drawn right to left)
	    boolean rev = (mLead1.x == mLead2.x && mLead1.y < mLead2.y) || (mLead1.y == mLead2.y && mLead1.x > mLead2.x);
	    
	    // draw units
	    String s1 = Drawer.getShortUnitText(rev ? resistance2 : resistance1, "");
	    String s2 = Drawer.getShortUnitText(rev ? resistance1 : resistance2, "");
	    g.setFont(Drawer.FONT_UNITS);
	    g.setColor(Drawer.COLOR_WHITE);
	    int ya = (int)g.currentFontSize/2;
	    int w;
	    w = (int)g.context.measureText(s1).getWidth();
	    
	    // vertical?
	    if (mLead1.x == mLead2.x)
		g.drawString(s1, !reverseY ? arrowPoint.x+2 : arrowPoint.x-2-w, Math.max(arrow1.y, arrow2.y)+5+ya);
	    else
		g.drawString(s1, Math.min(arrow1.x, arrow2.x)-2-w, !reverseX ? arrowPoint.y+4+ya : arrowPoint.y-4);
	    
	    w = (int)g.context.measureText(s2).getWidth();
	    if (mLead1.x == mLead2.x)
		g.drawString(s2, !reverseY ? arrowPoint.x+2 : arrowPoint.x-2-w, Math.min(arrow1.y, arrow2.y)-3);
	    else
		g.drawString(s2, Math.max(arrow1.x, arrow2.x)+2, !reverseX ? arrowPoint.y+4+ya : arrowPoint.y-4); 
	}
    }
    
    // draw component values (number of resistor ohms, etc).  hs = offset
    void drawValues(Graphics g, String s, Point pt, int hs) {
	if (s == null)
	    return;
	g.setFont(Drawer.FONT_UNITS);
	//FontMetrics fm = g.getFontMetrics();
	int w = (int)g.context.measureText(s).getWidth();
	g.setColor(Drawer.COLOR_WHITE);
	int ya = (int)g.currentFontSize/2;
	int xc = pt.x;
	int yc = pt.y;
	int dpx = hs;
	int dpy = 0;
	if (mLead1.x != mLead2.x) {
	    dpx = 0;
	    dpy = -hs;
	}
	MainForm.console("dv " + dpx + " " + w);
	if (dpx == 0)
	    g.drawString(s, xc-w/2, yc-abs(dpy)-2);
	else {
	    int xx = xc+abs(dpx)+2;
	    g.drawString(s, xx, yc+dpy+ya);
	}
    }
    
    void reset() {
	curcount1 = curcount2 = curcount3 = 0;
	super.reset();
    }
    void calculateCurrent() {
	if (resistance1 == 0)
	    return; // avoid NaN
	current1 = (volts[0]-volts[2])/resistance1;
	current2 = (volts[1]-volts[2])/resistance2;
	current3 = -current1-current2;
    }
    
    @Override double getCurrentIntoNode(int n) {
	if (n == 0)
	    return -current1;
	if (n == 1)
	    return -current2;
	return -current3;
    }
    
    void stamp() {
	resistance1 = maxResistance*position;
	resistance2 = maxResistance*(1-position);
	cir.stampResistor(nodes[0], nodes[2], resistance1);
	cir.stampResistor(nodes[2], nodes[1], resistance2);
    }
    void getInfo(String arr[]) {
	arr[0] = "potentiometer";
	arr[1] = "Vd = " + Drawer.getVoltageDText(getVoltageDiff());
	arr[2] = "R1 = " + Drawer.getUnitText(resistance1, MainForm.ohmString);
	arr[3] = "R2 = " + Drawer.getUnitText(resistance2, MainForm.ohmString);
	arr[4] = "I1 = " + Drawer.getCurrentDText(current1);
	arr[5] = "I2 = " + Drawer.getCurrentDText(current2);
    }
    public EditInfo getEditInfo(int n) {
	// ohmString doesn't work here on linux
	if (n == 0)
	    return new EditInfo("Resistance (ohms)", maxResistance, 0, 0);
	if (n == 1) {
	    EditInfo ei = new EditInfo("Slider Text", 0, -1, -1);
	    ei.text = sliderText;
	    return ei;
	}
	if (n == 2) {
            EditInfo ei = new EditInfo("", 0, -1, -1);
            ei.checkbox = new Checkbox("Show Values", (flags & FLAG_SHOW_VALUES) != 0);
            return ei;
	}
	return null;
    }
    public void setEditValue(int n, EditInfo ei) {
	if (n == 0)
	    maxResistance = ei.value;
	if (n == 1) {
	    sliderText = ei.textf.getText();
	    label.setText(sliderText);
	    form.setiFrameHeight();
	}
	if (n == 2)
	    flags = ei.changeFlag(flags, FLAG_SHOW_VALUES);
    }
    void setMouseElm(boolean v) {
    	super.setMouseElm(v);
    	if (slider!=null)
    		slider.draw();
    }
    
    public void onMouseWheel(MouseWheelEvent e) {
    	if (slider!=null)
    		slider.onMouseWheel(e);
    }
}

