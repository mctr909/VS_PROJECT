/*    
    Copyright (C) Paul Falstad and Iain Sharp
    
    This file is part of CircuitJS1.

    CircuitJS1 is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 2 of the License, or
    (at your option) any later version.

    CircuitJS1 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
*/

package com.lushprojects.circuitjs1.client;

class CapacitorElm extends BaseElement {
	public static final int FLAG_BACK_EULER = 2;

	double capacitance;
	double compResistance;
	double voltdiff;
	Point plate1[];
	Point plate2[];

	public CapacitorElm(int xx, int yy) {
		super(xx, yy);
		capacitance = 1e-5;
	}

	public CapacitorElm(int xa, int ya, int xb, int yb, int f, StringTokenizer st) {
		super(xa, ya, xb, yb, f);
		capacitance = new Double(st.nextToken()).doubleValue();
		voltdiff = new Double(st.nextToken()).doubleValue();
	}

	boolean isTrapezoidal() {
		return (flags & FLAG_BACK_EULER) == 0;
	}

	void setNodeVoltage(int n, double c) {
		super.setNodeVoltage(n, c);
		voltdiff = volts[0] - volts[1];
	}

	void reset() {
		super.reset();
		current = curcount = curSourceValue = 0;
		// put small charge on caps when reset to start oscillators
		voltdiff = 1e-3;
	}

	int getDumpType() {
		return 'c';
	}

	String dump() {
		return super.dump() + " " + capacitance + " " + voltdiff;
	}

	Point platePoints[];

	void setPoints() {
		super.setPoints();
		double f = (mLen / 2 - 4) / mLen;
		// calc leads
		mLead1 = Drawer.interpPoint(POSA, POSB, f);
		mLead2 = Drawer.interpPoint(POSA, POSB, 1 - f);
		// calc plates
		plate1 = Drawer.newPointArray(2);
		plate2 = Drawer.newPointArray(2);
		Drawer.interpPoint2(POSA, POSB, plate1[0], plate1[1], f, 12);
		Drawer.interpPoint2(POSA, POSB, plate2[0], plate2[1], 1 - f, 12);
	}

	void draw(Graphics g) {
		int hs = 12;
		setBbox(POSA, POSB, hs);

		// draw first lead and plate
		setVoltageColor(g, volts[0]);
		Drawer.drawThickLine(g, POSA, mLead1);
		setPowerColor(g, false);
		Drawer.drawThickLine(g, plate1[0], plate1[1]);
		if (form.powerCheckItem.getState())
			g.setColor(Color.gray);

		// draw second lead and plate
		setVoltageColor(g, volts[1]);
		Drawer.drawThickLine(g, POSB, mLead2);
		setPowerColor(g, false);
		if (platePoints == null)
			Drawer.drawThickLine(g, plate2[0], plate2[1]);
		else {
			int i;
			for (i = 0; i != 7; i++)
				Drawer.drawThickLine(g, platePoints[i], platePoints[i + 1]);
		}

		updateDotCount();
		if (form.dragElm != this) {
			Drawer.drawDots(g, POSA, mLead1, curcount);
			Drawer.drawDots(g, POSB, mLead2, -curcount);
		}
		drawPosts(g);
		if (form.showValuesCheckItem.getState()) {
			String s = Drawer.getShortUnitText(capacitance, "F");
			drawValues(g, s, hs);
		}
	}

	void stamp() {
		if (form.mDcAnalysisFlag) {
			// when finding DC operating point, replace cap with a 100M resistor
			cir.stampResistor(nodes[0], nodes[1], 1e8);
			curSourceValue = 0;
			return;
		}

		// capacitor companion model using trapezoidal approximation
		// (Norton equivalent) consists of a current source in
		// parallel with a resistor. Trapezoidal is more accurate
		// than backward euler but can cause oscillatory behavior
		// if RC is small relative to the timestep.
		if (isTrapezoidal())
			compResistance = cir.mDeltaTime / (2 * capacitance);
		else
			compResistance = cir.mDeltaTime / capacitance;
		cir.stampResistor(nodes[0], nodes[1], compResistance);
		cir.stampRightSide(nodes[0]);
		cir.stampRightSide(nodes[1]);
	}

	void startIteration() {
		if (isTrapezoidal())
			curSourceValue = -voltdiff / compResistance - current;
		else
			curSourceValue = -voltdiff / compResistance;
	}

	void calculateCurrent() {
		double voltdiff = volts[0] - volts[1];
		if (form.mDcAnalysisFlag) {
			current = voltdiff / 1e8;
			return;
		}
		// we check compResistance because this might get called
		// before stamp(), which sets compResistance, causing
		// infinite current
		if (compResistance > 0)
			current = voltdiff / compResistance + curSourceValue;
	}

	double curSourceValue;

	void doStep() {
		if (form.mDcAnalysisFlag)
			return;
		cir.stampCurrentSource(nodes[0], nodes[1], curSourceValue);
	}

	void getInfo(String arr[]) {
		arr[0] = "capacitor";
		getBasicInfo(arr);
		arr[3] = "C = " + Drawer.getUnitText(capacitance, "F");
		arr[4] = "P = " + Drawer.getUnitText(getPower(), "W");
		// double v = getVoltageDiff();
		// arr[4] = "U = " + Drawer.getUnitText(.5*capacitance*v*v, "J");
	}

	@Override
	String getScopeText(int v) {
		return MainForm.LS("capacitor") + ", " + Drawer.getUnitText(capacitance, "F");
	}

	public EditInfo getEditInfo(int n) {
		if (n == 0)
			return new EditInfo("Capacitance (F)", capacitance, 0, 0);
		if (n == 1) {
			EditInfo ei = new EditInfo("", 0, -1, -1);
			ei.checkbox = new Checkbox("Trapezoidal Approximation", isTrapezoidal());
			return ei;
		}
		return null;
	}

	public void setEditValue(int n, EditInfo ei) {
		if (n == 0 && ei.value > 0)
			capacitance = ei.value;
		if (n == 1) {
			if (ei.checkbox.getState())
				flags &= ~FLAG_BACK_EULER;
			else
				flags |= FLAG_BACK_EULER;
		}
	}

	int getShortcut() {
		return 'c';
	}
}
