/*    
    Copyright (C) Paul Falstad and Iain Sharp
    
    This file is part of CircuitJS1.

    CircuitJS1 is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 2 of the License, or
    (at your option) any later version.

    CircuitJS1 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
*/



package com.lushprojects.circuitjs1.client;

// contributed by Edward Calver

class TriStateElm extends BaseElement {
    double resistance, r_on, r_off;

    public TriStateElm(int xx, int yy) {
	super(xx, yy);
	r_on = 0.1;
	r_off = 1e10;
    }

    public TriStateElm(int xa, int ya, int xb, int yb, int f, StringTokenizer st) {
	super(xa, ya, xb, yb, f);
	r_on = 0.1;
	r_off = 1e10;
	try {
	    r_on = new Double(st.nextToken()).doubleValue();
	    r_off = new Double(st.nextToken()).doubleValue();
	} catch (Exception e) {
	}

    }

    String dump() {
	return super.dump() + " " + r_on + " " + r_off;
    }

    int getDumpType() {
	return 180;
    }

    boolean open;

    Point ps, point3, lead3;

    Polygon gatePoly;

    void setPoints() {
	super.setPoints();
	calcLeads(32);
	ps = new Point();
	int hs = 16;

	int ww = 16;
	if (ww > mLen / 2)
	    ww = (int) (mLen / 2);
	Point triPoints[] = Drawer.newPointArray(3);
	Drawer.interpPoint2(mLead1, mLead2, triPoints[0], triPoints[1], 0, hs + 2);
	triPoints[2] = Drawer.interpPoint(POSA, POSB, .5 + (ww - 2) / mLen);
	gatePoly = Drawer.createPolygon(triPoints);

	point3 = Drawer.interpPoint(POSA, POSB, .5, -hs);
	lead3 = Drawer.interpPoint(POSA, POSB, .5, -hs / 2);
    }

    void draw(Graphics g) {
	int hs = 16;
	setBbox(POSA, POSB, hs);

	draw2Leads(g);

	g.setColor(Drawer.COLOR_LIGHT_GRAY);
	Drawer.drawThickPolygon(g, gatePoly);
	setVoltageColor(g, volts[2]);
	Drawer.drawThickLine(g, point3, lead3);
	curcount = updateDotCount(current, curcount);
	Drawer.drawDots(g, mLead2, POSB, curcount);
	drawPosts(g);
    }

    void calculateCurrent() {
	current = (volts[0] - volts[1]) / resistance;
    }

    double getCurrentIntoNode(int n) {
	if (n == 1)
	    return current;
	return 0;
    }

    // we need this to be able to change the matrix for each step
    boolean nonLinear() {
	return true;
    }

    void stamp() {
	cir.stampVoltageSource(0, nodes[3], voltSource);
	cir.stampNonLinear(nodes[3]);
	cir.stampNonLinear(nodes[1]);
    }

    void doStep() {
	open = (volts[2] < 2.5);
	resistance = (open) ? r_off : r_on;
	cir.stampResistor(nodes[3], nodes[1], resistance);
	cir.updateVoltageSource(0, nodes[3], voltSource, volts[0] > 2.5 ? 5 : 0);
    }

    void drag(int xx, int yy) {
	xx = form.snapGrid(xx);
	yy = form.snapGrid(yy);
	if (abs(mAx - xx) < abs(mAy - yy))
	    xx = mAx;
	else
	    yy = mAy;
	int q1 = abs(mAx - xx) + abs(mAy - yy);
	int q2 = (q1 / 2) % form.gridSize;
	if (q2 != 0)
	    return;
	mBx = xx;
	mBy = yy;
	setPoints();
    }

    int getPostCount() {
	return 3;
    }
    
    int getInternalNodeCount() {
	return 1;
    }

    int getVoltageSourceCount() {
	return 1;
    }

    Point getPost(int n) {
	return (n == 0) ? POSA : (n == 1) ? POSB : point3;
    }

    void getInfo(String arr[]) {
	arr[0] = "tri-state buffer";
	arr[1] = open ? "open" : "closed";
	arr[2] = "Vd = " + Drawer.getVoltageDText(getVoltageDiff());
	arr[3] = "I = " + Drawer.getCurrentDText(getCurrent());
	arr[4] = "Vc = " + Drawer.getVoltageText(volts[2]);
    }

    // there is no current path through the input, but there
    // is an indirect path through the output to ground.
    boolean getConnection(int n1, int n2) {
	return false;
    }

    boolean hasGroundConnection(int n1) {
	return (n1 == 1);
    }

    public EditInfo getEditInfo(int n) {

	if (n == 0)
	    return new EditInfo("On Resistance (ohms)", r_on, 0, 0);
	if (n == 1)
	    return new EditInfo("Off Resistance (ohms)", r_off, 0, 0);
	return null;
    }

    public void setEditValue(int n, EditInfo ei) {

	if (n == 0 && ei.value > 0)
	    r_on = ei.value;
	if (n == 1 && ei.value > 0)
	    r_off = ei.value;
    }
}
