package com.lushprojects.circuitjs1.client;

import com.google.gwt.i18n.client.NumberFormat;

public final class Drawer {
    static final int COLOR_SCALE_COUNT = 32;

    static Color COLOR_SCALE[];
    static double VOLTAGE_RANGE = 5;

    static NumberFormat SHOW_FORMAT;
    static NumberFormat SHORT_FORMAT;

    static Color COLOR_WHITE;
    static Color COLOR_SELECT;
    static Color COLOR_LIGHT_GRAY;
    static Font FONT_UNITS;

    private static MainForm form;
    private static CircuitManager cir;
    private static BaseElement mMouseElmRef = null;

    static void initClass(MainForm s) {
        FONT_UNITS = new Font("SansSerif", 0, 12);
        SHOW_FORMAT = NumberFormat.getFormat("####.###");
        SHORT_FORMAT = NumberFormat.getFormat("####.#");
        form = s;
        cir = s.mCirManager;
    }

    static void delete(BaseElement elm) {
        if (mMouseElmRef == elm) {
            mMouseElmRef = null;
        }
        form.deleteSliders(elm);
    }

    static boolean needsHighlight(BaseElement elm) {
        // Test if the current mouseElm is a ScopeElm and, if so, does it belong to this
        // elm
        return mMouseElmRef == elm || elm.mSelected || form.plotYElm == elm
                || (mMouseElmRef instanceof ScopeElm && ((ScopeElm) mMouseElmRef).elmScope.getElm() == elm);
    }

    static void setMouseElm(boolean v, BaseElement elm) {
        if (v) {
            mMouseElmRef = elm;
        } else if (mMouseElmRef == elm) {
            mMouseElmRef = null;
        }
    }

    static boolean isMouseElm(BaseElement elm) {
        return mMouseElmRef == elm;
    }

    // draw current dots from point a to b
    static void drawDots(Graphics g, Point pa, Point pb, double pos) {
        if ((!cir.simIsRunning()) || pos == 0 || !form.dotsCheckItem.getState()) {
            return;
        }
        int dx = pb.x - pa.x;
        int dy = pb.y - pa.y;
        double dn = Math.sqrt(dx * dx + dy * dy);
        g.setColor(form.conventionCheckItem.getState() ? Color.yellow : Color.cyan);
        int ds = 16;
        pos %= ds;
        if (pos < 0) {
            pos += ds;
        }
        double di = 0;
        for (di = pos; di < dn; di += ds) {
            int x0 = (int) (pa.x + di * dx / dn);
            int y0 = (int) (pa.y + di * dy / dn);
            g.fillRect(x0 - 2, y0 - 2, 4, 4);
        }
    }

    static void setColorScale(boolean alternativeColor) {
        COLOR_SCALE = new Color[Drawer.COLOR_SCALE_COUNT];
        for (int i = 0; i != COLOR_SCALE_COUNT; i++) {
            double v = i * 2.0 / COLOR_SCALE_COUNT - 1;
            if (v < 0) {
                int n1 = (int) (128 * -v) + 127;
                int n2 = (int) (127 * (1 + v));
                COLOR_SCALE[i] = new Color(n1, n2, n2);
            } else {
                int n1 = (int) (128 * v) + 127;
                int n2 = (int) (127 * (1 - v));
                if (alternativeColor) {
                    COLOR_SCALE[i] = new Color(n2, n2, n1);
                } else {
                    COLOR_SCALE[i] = new Color(n2, n1, n2);
                }
            }
        }
    }

    static void drawThickLine(Graphics g, int x, int y, int x2, int y2) {
        g.setLineWidth(3.0);
        g.drawLine(x, y, x2, y2);
        g.setLineWidth(1.0);
    }

    static void drawThickLine(Graphics g, Point pa, Point pb) {
        g.setLineWidth(3.0);
        g.drawLine(pa.x, pa.y, pb.x, pb.y);
        g.setLineWidth(1.0);
    }

    static void drawThickPolygon(Graphics g, int xs[], int ys[], int c) {
        // int i;
        // for (i = 0; i != c-1; i++)
        // Drawer.drawThickLine(g, xs[i], ys[i], xs[i+1], ys[i+1]);
        // Drawer.drawThickLine(g, xs[i], ys[i], xs[0], ys[0]);
        g.setLineWidth(3.0);
        g.drawPolyline(xs, ys, c);
        g.setLineWidth(1.0);
    }

    static void drawThickPolygon(Graphics g, Polygon p) {
        drawThickPolygon(g, p.xpoints, p.ypoints, p.npoints);
    }

    static void drawPolygon(Graphics g, Polygon p) {
        g.drawPolyline(p.xpoints, p.ypoints, p.npoints);
        /*
         * int i; int xs[] = p.xpoints; int ys[] = p.ypoints; int np = p.npoints; np -=
         * 3; for (i = 0; i != np-1; i++) g.drawLine(xs[i], ys[i], xs[i+1], ys[i+1]);
         * g.drawLine(xs[i], ys[i], xs[0], ys[0]);
         */
    }

    static void drawThickCircle(Graphics g, int cx, int cy, int ri) {
        g.setLineWidth(3.0);
        g.context.beginPath();
        g.context.arc(cx, cy, ri * .98, 0, 2 * Math.PI);
        g.context.stroke();
        g.setLineWidth(1.0);
    }

    static String getVoltageDText(double v) {
        return getUnitText(Math.abs(v), "V");
    }

    static String getVoltageText(double v) {
        return getUnitText(v, "V");
    }

    // calculate point fraction f between a and b, linearly interpolated
    static Point interpPoint(Point a, Point b, double f) {
        Point p = new Point();
        interpPoint(a, b, p, f);
        return p;
    }

    // calculate point fraction f between a and b, linearly interpolated, return it
    // in c
    static void interpPoint(Point a, Point b, Point c, double f) {
        c.x = (int) Math.floor(a.x * (1 - f) + b.x * f + .48);
        c.y = (int) Math.floor(a.y * (1 - f) + b.y * f + .48);
    }

    /**
     * Returns a point fraction f along the line between a and b and offset
     * perpendicular by g
     * 
     * @param a
     *              1st Point
     * @param b
     *              2nd Point
     * @param f
     *              Fraction along line
     * @param g
     *              Fraction perpendicular to line Returns interpolated point in c
     */
    static void interpPoint(Point a, Point b, Point c, double f, double g) {
        int gx = b.y - a.y;
        int gy = a.x - b.x;
        g /= Math.sqrt(gx * gx + gy * gy);
        c.x = (int) Math.floor(a.x * (1 - f) + b.x * f + g * gx + .48);
        c.y = (int) Math.floor(a.y * (1 - f) + b.y * f + g * gy + .48);
    }

    /**
     * Returns a point fraction f along the line between a and b and offset
     * perpendicular by g
     * 
     * @param a
     *              1st Point
     * @param b
     *              2nd Point
     * @param f
     *              Fraction along line
     * @param g
     *              Fraction perpendicular to line
     * @return Interpolated point
     */
    static Point interpPoint(Point a, Point b, double f, double g) {
        Point p = new Point();
        interpPoint(a, b, p, f, g);
        return p;
    }

    /**
     * Calculates two points fraction f along the line between a and b and offest
     * perpendicular by +/-g
     * 
     * @param a
     *              1st point (In)
     * @param b
     *              2nd point (In)
     * @param c
     *              1st point (Out)
     * @param d
     *              2nd point (Out)
     * @param f
     *              Fraction along line
     * @param g
     *              Fraction perpendicular to line
     */
    static void interpPoint2(Point a, Point b, Point c, Point d, double f, double g) {
        // int xpd = b.x-a.x;
        // int ypd = b.y-a.y;
        int gx = b.y - a.y;
        int gy = a.x - b.x;
        g /= Math.sqrt(gx * gx + gy * gy);
        c.x = (int) Math.floor(a.x * (1 - f) + b.x * f + g * gx + .48);
        c.y = (int) Math.floor(a.y * (1 - f) + b.y * f + g * gy + .48);
        d.x = (int) Math.floor(a.x * (1 - f) + b.x * f - g * gx + .48);
        d.y = (int) Math.floor(a.y * (1 - f) + b.y * f - g * gy + .48);
    }

    static Point[] newPointArray(int n) {
        Point[] a = new Point[n];
        while (n > 0) {
            a[--n] = new Point();
        }
        return a;
    }

    static Polygon calcArrow(Point a, Point b, double al, double aw) {
        Polygon poly = new Polygon();
        Point p1 = new Point();
        Point p2 = new Point();
        int adx = b.x - a.x;
        int ady = b.y - a.y;
        double l = Math.sqrt(adx * adx + ady * ady);
        poly.addPoint(b.x, b.y);
        interpPoint2(a, b, p1, p2, 1 - al / l, aw);
        poly.addPoint(p1.x, p1.y);
        poly.addPoint(p2.x, p2.y);
        return poly;
    }

    static Polygon createPolygon(Point a, Point b, Point c) {
        Polygon p = new Polygon();
        p.addPoint(a.x, a.y);
        p.addPoint(b.x, b.y);
        p.addPoint(c.x, c.y);
        return p;
    }

    static Polygon createPolygon(Point a, Point b, Point c, Point d) {
        Polygon p = new Polygon();
        p.addPoint(a.x, a.y);
        p.addPoint(b.x, b.y);
        p.addPoint(c.x, c.y);
        p.addPoint(d.x, d.y);
        return p;
    }

    static Polygon createPolygon(Point[] a) {
        Polygon p = new Polygon();
        int i;
        for (i = 0; i != a.length; i++) {
            p.addPoint(a[i].x, a[i].y);
        }
        return p;
    }

    static String format(double v, boolean sf) {
        if (sf && Math.abs(v) > 10) {
            return SHORT_FORMAT.format(Math.round(v));
        }
        return (sf ? SHORT_FORMAT : SHOW_FORMAT).format(v);
    }

    /*
     * void drawPost(Graphics g, int x0, int y0, int n) { if (sim.dragElm == null &&
     * !needsHighlight() && sim.getCircuitNode(n).links.size() == 2) return; if
     * (sim.mouseMode == CirSim.MODE_DRAG_ROW || sim.mouseMode ==
     * CirSim.MODE_DRAG_COLUMN) return; drawPost(g, x0, y0); }
     */
    static void drawPost(Graphics g, Point pt) {
        g.setColor(COLOR_WHITE);
        g.fillOval(pt.x - 3, pt.y - 3, 7, 7);
    }

    static String getUnitText(double v, String u, boolean flag) {
        return myGetUnitText(v, u, flag);
    }

    static String getUnitText(double v, String u) {
        return myGetUnitText(v, u, false);
    }

    static String getShortUnitText(double v, String u) {
        return myGetUnitText(v, u, true);
    }

    static String myGetUnitText(double v, String u, boolean sf) {
        String sp = sf ? "" : " ";
        double va = Math.abs(v);
        if (va < 1e-14)
            // this used to return null, but then wires would display "null" with 0V
            return "0" + sp + u;
        if (va < 1e-9)
            return format(v * 1e12, sf) + sp + "p" + u;
        if (va < 1e-6)
            return format(v * 1e9, sf) + sp + "n" + u;
        if (va < 1e-3)
            return format(v * 1e6, sf) + sp + MainForm.muString + u;
        if (va < 1)
            return format(v * 1e3, sf) + sp + "m" + u;
        if (va < 1e3)
            return format(v, sf) + sp + u;
        if (va < 1e6)
            return format(v * 1e-3, sf) + sp + "k" + u;
        if (va < 1e9)
            return format(v * 1e-6, sf) + sp + "M" + u;
        return format(v * 1e-9, sf) + sp + "G" + u;
    }

    static String getCurrentText(double i) {
        return getUnitText(i, "A");
    }

    static String getCurrentDText(double i) {
        return getUnitText(Math.abs(i), "A");
    }
}