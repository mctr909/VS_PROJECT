package com.lushprojects.circuitjs1.client;

public final class DefinedElements {
	public static BaseElement createCe(int id, int x1, int y1, int x2, int y2, int f, StringTokenizer st) {
		if (id == 'g')
			return (BaseElement) new GroundElm(x1, y1, x2, y2, f, st);
		if (id == 'r')
			return (BaseElement) new ResistorElm(x1, y1, x2, y2, f, st);
		if (id == 'R')
			return (BaseElement) new RailElm(x1, y1, x2, y2, f, st);
		if (id == 's')
			return (BaseElement) new SwitchElm(x1, y1, x2, y2, f, st);
		if (id == 'S')
			return (BaseElement) new Switch2Elm(x1, y1, x2, y2, f, st);
		if (id == 't')
			return (BaseElement) new TransistorElm(x1, y1, x2, y2, f, st);
		if (id == 'w')
			return (BaseElement) new WireElm(x1, y1, x2, y2, f, st);
		if (id == 'c')
			return (BaseElement) new CapacitorElm(x1, y1, x2, y2, f, st);
		if (id == 209)
			return (BaseElement) new PolarCapacitorElm(x1, y1, x2, y2, f, st);
		if (id == 'l')
			return (BaseElement) new InductorElm(x1, y1, x2, y2, f, st);
		if (id == 'v')
			return (BaseElement) new VoltageElm(x1, y1, x2, y2, f, st);
		if (id == 172)
			return (BaseElement) new VarRailElm(x1, y1, x2, y2, f, st);
		if (id == 174)
			return (BaseElement) new PotElm(x1, y1, x2, y2, f, st);
		if (id == 'O')
			return (BaseElement) new OutputElm(x1, y1, x2, y2, f, st);
		if (id == 'i')
			return (BaseElement) new CurrentElm(x1, y1, x2, y2, f, st);
		if (id == 'p')
			return (BaseElement) new ProbeElm(x1, y1, x2, y2, f, st);
		if (id == 'd')
			return (BaseElement) new DiodeElm(x1, y1, x2, y2, f, st);
		if (id == 'z')
			return (BaseElement) new ZenerElm(x1, y1, x2, y2, f, st);
		if (id == 170)
			return (BaseElement) new SweepElm(x1, y1, x2, y2, f, st);
		if (id == 162)
			return (BaseElement) new LEDElm(x1, y1, x2, y2, f, st);
		if (id == 'A')
			return (BaseElement) new AntennaElm(x1, y1, x2, y2, f, st);
		if (id == 'L')
			return (BaseElement) new LogicInputElm(x1, y1, x2, y2, f, st);
		if (id == 'M')
			return (BaseElement) new LogicOutputElm(x1, y1, x2, y2, f, st);
		if (id == 'T')
			return (BaseElement) new TransformerElm(x1, y1, x2, y2, f, st);
		if (id == 169)
			return (BaseElement) new TappedTransformerElm(x1, y1, x2, y2, f, st);
		if (id == 171)
			return (BaseElement) new TransLineElm(x1, y1, x2, y2, f, st);
		if (id == 178)
			return (BaseElement) new RelayElm(x1, y1, x2, y2, f, st);
		if (id == 'm')
			return (BaseElement) new MemristorElm(x1, y1, x2, y2, f, st);
		if (id == 187)
			return (BaseElement) new SparkGapElm(x1, y1, x2, y2, f, st);
		if (id == 200)
			return (BaseElement) new AMElm(x1, y1, x2, y2, f, st);
		if (id == 201)
			return (BaseElement) new FMElm(x1, y1, x2, y2, f, st);
		if (id == 'n')
			return (BaseElement) new NoiseElm(x1, y1, x2, y2, f, st);
		if (id == 181)
			return (BaseElement) new LampElm(x1, y1, x2, y2, f, st);
		if (id == 'a')
			return (BaseElement) new OpAmpElm(x1, y1, x2, y2, f, st);
		if (id == 'f')
			return (BaseElement) new MosfetElm(x1, y1, x2, y2, f, st);
		if (id == 'j')
			return (BaseElement) new JfetElm(x1, y1, x2, y2, f, st);
		if (id == 159)
			return (BaseElement) new AnalogSwitchElm(x1, y1, x2, y2, f, st);
		if (id == 160)
			return (BaseElement) new AnalogSwitch2Elm(x1, y1, x2, y2, f, st);
		if (id == 180)
			return (BaseElement) new TriStateElm(x1, y1, x2, y2, f, st);
		if (id == 182)
			return (BaseElement) new SchmittElm(x1, y1, x2, y2, f, st);
		if (id == 183)
			return (BaseElement) new InvertingSchmittElm(x1, y1, x2, y2, f, st);
		if (id == 177)
			return (BaseElement) new SCRElm(x1, y1, x2, y2, f, st);
		if (id == 203)
			return (BaseElement) new DiacElm(x1, y1, x2, y2, f, st);
		if (id == 206)
			return (BaseElement) new TriacElm(x1, y1, x2, y2, f, st);
		if (id == 173)
			return (BaseElement) new TriodeElm(x1, y1, x2, y2, f, st);
		if (id == 175)
			return (BaseElement) new TunnelDiodeElm(x1, y1, x2, y2, f, st);
		if (id == 176)
			return (BaseElement) new VaractorElm(x1, y1, x2, y2, f, st);
		if (id == 179)
			return (BaseElement) new CC2Elm(x1, y1, x2, y2, f, st);
		if (id == 'I')
			return (BaseElement) new InverterElm(x1, y1, x2, y2, f, st);
		if (id == 151)
			return (BaseElement) new NandGateElm(x1, y1, x2, y2, f, st);
		if (id == 153)
			return (BaseElement) new NorGateElm(x1, y1, x2, y2, f, st);
		if (id == 150)
			return (BaseElement) new AndGateElm(x1, y1, x2, y2, f, st);
		if (id == 152)
			return (BaseElement) new OrGateElm(x1, y1, x2, y2, f, st);
		if (id == 154)
			return (BaseElement) new XorGateElm(x1, y1, x2, y2, f, st);
		if (id == 155)
			return (BaseElement) new DFlipFlopElm(x1, y1, x2, y2, f, st);
		if (id == 156)
			return (BaseElement) new JKFlipFlopElm(x1, y1, x2, y2, f, st);
		if (id == 157)
			return (BaseElement) new SevenSegElm(x1, y1, x2, y2, f, st);
		if (id == 184)
			return (BaseElement) new MultiplexerElm(x1, y1, x2, y2, f, st);
		if (id == 185)
			return (BaseElement) new DeMultiplexerElm(x1, y1, x2, y2, f, st);
		if (id == 189)
			return (BaseElement) new SipoShiftElm(x1, y1, x2, y2, f, st);
		if (id == 186)
			return (BaseElement) new PisoShiftElm(x1, y1, x2, y2, f, st);
		if (id == 161)
			return (BaseElement) new PhaseCompElm(x1, y1, x2, y2, f, st);
		if (id == 164)
			return (BaseElement) new CounterElm(x1, y1, x2, y2, f, st);
		if (id == 163)
			return (BaseElement) new RingCounterElm(x1, y1, x2, y2, f, st);
		if (id == 165)
			return (BaseElement) new TimerElm(x1, y1, x2, y2, f, st);
		if (id == 166)
			return (BaseElement) new DACElm(x1, y1, x2, y2, f, st);
		if (id == 167)
			return (BaseElement) new ADCElm(x1, y1, x2, y2, f, st);
		if (id == 168)
			return (BaseElement) new LatchElm(x1, y1, x2, y2, f, st);
		if (id == 188)
			return (BaseElement) new SeqGenElm(x1, y1, x2, y2, f, st);
		if (id == 158)
			return (BaseElement) new VCOElm(x1, y1, x2, y2, f, st);
		if (id == 'b')
			return (BaseElement) new BoxElm(x1, y1, x2, y2, f, st);
		if (id == 'x')
			return (BaseElement) new TextElm(x1, y1, x2, y2, f, st);
		if (id == 193)
			return (BaseElement) new TFlipFlopElm(x1, y1, x2, y2, f, st);
		if (id == 197)
			return (BaseElement) new SevenSegDecoderElm(x1, y1, x2, y2, f, st);
		if (id == 196)
			return (BaseElement) new FullAdderElm(x1, y1, x2, y2, f, st);
		if (id == 195)
			return (BaseElement) new HalfAdderElm(x1, y1, x2, y2, f, st);
		if (id == 194)
			return (BaseElement) new MonostableElm(x1, y1, x2, y2, f, st);
		if (id == 207)
			return (BaseElement) new LabeledNodeElm(x1, y1, x2, y2, f, st);
		if (id == 208)
			return (BaseElement) new CustomLogicElm(x1, y1, x2, y2, f, st);
		if (id == 210)
			return (BaseElement) new DataRecorderElm(x1, y1, x2, y2, f, st);
		if (id == 211)
			return (BaseElement) new AudioOutputElm(x1, y1, x2, y2, f, st);
		if (id == 212)
			return (BaseElement) new VCVSElm(x1, y1, x2, y2, f, st);
		if (id == 213)
			return (BaseElement) new VCCSElm(x1, y1, x2, y2, f, st);
		if (id == 214)
			return (BaseElement) new CCVSElm(x1, y1, x2, y2, f, st);
		if (id == 215)
			return (BaseElement) new CCCSElm(x1, y1, x2, y2, f, st);
		if (id == 216)
			return (BaseElement) new OhmMeterElm(x1, y1, x2, y2, f, st);
		if (id == 368)
			return new TestPointElm(x1, y1, x2, y2, f, st);
		if (id == 370)
			return new AmmeterElm(x1, y1, x2, y2, f, st);
		if (id == 400)
			return new DarlingtonElm(x1, y1, x2, y2, f, st);
		if (id == 401)
			return new ComparatorElm(x1, y1, x2, y2, f, st);
		if (id == 402)
			return new OTAElm(x1, y1, x2, y2, f, st);
		if (id == 403)
			return new ScopeElm(x1, y1, x2, y2, f, st);
		if (id == 404)
			return new FuseElm(x1, y1, x2, y2, f, st);
		if (id == 405)
			return new LEDArrayElm(x1, y1, x2, y2, f, st);
		if (id == 406)
			return new CustomTransformerElm(x1, y1, x2, y2, f, st);
		if (id == 407)
			return new OptocouplerElm(x1, y1, x2, y2, f, st);
		if (id == 408)
			return new StopTriggerElm(x1, y1, x2, y2, f, st);
		if (id == 409)
			return new OpAmpRealElm(x1, y1, x2, y2, f, st);
		if (id == 410)
			return new CustomCompositeElm(x1, y1, x2, y2, f, st);
		if (id == 411)
			return new AudioInputElm(x1, y1, x2, y2, f, st);
		return null;
	}

	public static BaseElement construct(String name, int x1, int y1) {
		if (name == "GroundElm")
			return (BaseElement) new GroundElm(x1, y1);
		if (name == "ResistorElm")
			return (BaseElement) new ResistorElm(x1, y1);
		if (name == "RailElm")
			return (BaseElement) new RailElm(x1, y1);
		if (name == "SwitchElm")
			return (BaseElement) new SwitchElm(x1, y1);
		if (name == "Switch2Elm")
			return (BaseElement) new Switch2Elm(x1, y1);
		if (name == "NTransistorElm" || name == "TransistorElm")
			return (BaseElement) new NTransistorElm(x1, y1);
		if (name == "PTransistorElm")
			return (BaseElement) new PTransistorElm(x1, y1);
		if (name == "WireElm")
			return (BaseElement) new WireElm(x1, y1);
		if (name == "CapacitorElm")
			return (BaseElement) new CapacitorElm(x1, y1);
		if (name == "PolarCapacitorElm")
			return (BaseElement) new PolarCapacitorElm(x1, y1);
		if (name == "InductorElm")
			return (BaseElement) new InductorElm(x1, y1);
		if (name == "DCVoltageElm" || name == "VoltageElm")
			return (BaseElement) new DCVoltageElm(x1, y1);
		if (name == "VarRailElm")
			return (BaseElement) new VarRailElm(x1, y1);
		if (name == "PotElm")
			return (BaseElement) new PotElm(x1, y1);
		if (name == "OutputElm")
			return (BaseElement) new OutputElm(x1, y1);
		if (name == "CurrentElm")
			return (BaseElement) new CurrentElm(x1, y1);
		if (name == "ProbeElm")
			return (BaseElement) new ProbeElm(x1, y1);
		if (name == "DiodeElm")
			return (BaseElement) new DiodeElm(x1, y1);
		if (name == "ZenerElm")
			return (BaseElement) new ZenerElm(x1, y1);
		if (name == "ACVoltageElm")
			return (BaseElement) new ACVoltageElm(x1, y1);
		if (name == "ACRailElm")
			return (BaseElement) new ACRailElm(x1, y1);
		if (name == "SquareRailElm")
			return (BaseElement) new SquareRailElm(x1, y1);
		if (name == "SweepElm")
			return (BaseElement) new SweepElm(x1, y1);
		if (name == "LEDElm")
			return (BaseElement) new LEDElm(x1, y1);
		if (name == "AntennaElm")
			return (BaseElement) new AntennaElm(x1, y1);
		if (name == "LogicInputElm")
			return (BaseElement) new LogicInputElm(x1, y1);
		if (name == "LogicOutputElm")
			return (BaseElement) new LogicOutputElm(x1, y1);
		if (name == "TransformerElm")
			return (BaseElement) new TransformerElm(x1, y1);
		if (name == "TappedTransformerElm")
			return (BaseElement) new TappedTransformerElm(x1, y1);
		if (name == "TransLineElm")
			return (BaseElement) new TransLineElm(x1, y1);
		if (name == "RelayElm")
			return (BaseElement) new RelayElm(x1, y1);
		if (name == "MemristorElm")
			return (BaseElement) new MemristorElm(x1, y1);
		if (name == "SparkGapElm")
			return (BaseElement) new SparkGapElm(x1, y1);
		if (name == "ClockElm")
			return (BaseElement) new ClockElm(x1, y1);
		if (name == "AMElm")
			return (BaseElement) new AMElm(x1, y1);
		if (name == "FMElm")
			return (BaseElement) new FMElm(x1, y1);
		if (name == "LampElm")
			return (BaseElement) new LampElm(x1, y1);
		if (name == "PushSwitchElm")
			return (BaseElement) new PushSwitchElm(x1, y1);
		if (name == "OpAmpElm")
			return (BaseElement) new OpAmpElm(x1, y1);
		if (name == "OpAmpSwapElm")
			return (BaseElement) new OpAmpSwapElm(x1, y1);
		if (name == "NMosfetElm" || name == "MosfetElm")
			return (BaseElement) new NMosfetElm(x1, y1);
		if (name == "PMosfetElm")
			return (BaseElement) new PMosfetElm(x1, y1);
		if (name == "NJfetElm" || name == "JfetElm")
			return (BaseElement) new NJfetElm(x1, y1);
		if (name == "PJfetElm")
			return (BaseElement) new PJfetElm(x1, y1);
		if (name == "AnalogSwitchElm")
			return (BaseElement) new AnalogSwitchElm(x1, y1);
		if (name == "AnalogSwitch2Elm")
			return (BaseElement) new AnalogSwitch2Elm(x1, y1);
		if (name == "SchmittElm")
			return (BaseElement) new SchmittElm(x1, y1);
		if (name == "InvertingSchmittElm")
			return (BaseElement) new InvertingSchmittElm(x1, y1);
		if (name == "TriStateElm")
			return (BaseElement) new TriStateElm(x1, y1);
		if (name == "SCRElm")
			return (BaseElement) new SCRElm(x1, y1);
		if (name == "DiacElm")
			return (BaseElement) new DiacElm(x1, y1);
		if (name == "TriacElm")
			return (BaseElement) new TriacElm(x1, y1);
		if (name == "TriodeElm")
			return (BaseElement) new TriodeElm(x1, y1);
		if (name == "VaractorElm")
			return (BaseElement) new VaractorElm(x1, y1);
		if (name == "TunnelDiodeElm")
			return (BaseElement) new TunnelDiodeElm(x1, y1);
		if (name == "CC2Elm")
			return (BaseElement) new CC2Elm(x1, y1);
		if (name == "CC2NegElm")
			return (BaseElement) new CC2NegElm(x1, y1);
		if (name == "InverterElm")
			return (BaseElement) new InverterElm(x1, y1);
		if (name == "NandGateElm")
			return (BaseElement) new NandGateElm(x1, y1);
		if (name == "NorGateElm")
			return (BaseElement) new NorGateElm(x1, y1);
		if (name == "AndGateElm")
			return (BaseElement) new AndGateElm(x1, y1);
		if (name == "OrGateElm")
			return (BaseElement) new OrGateElm(x1, y1);
		if (name == "XorGateElm")
			return (BaseElement) new XorGateElm(x1, y1);
		if (name == "DFlipFlopElm")
			return (BaseElement) new DFlipFlopElm(x1, y1);
		if (name == "JKFlipFlopElm")
			return (BaseElement) new JKFlipFlopElm(x1, y1);
		if (name == "SevenSegElm")
			return (BaseElement) new SevenSegElm(x1, y1);
		if (name == "MultiplexerElm")
			return (BaseElement) new MultiplexerElm(x1, y1);
		if (name == "DeMultiplexerElm")
			return (BaseElement) new DeMultiplexerElm(x1, y1);
		if (name == "SipoShiftElm")
			return (BaseElement) new SipoShiftElm(x1, y1);
		if (name == "PisoShiftElm")
			return (BaseElement) new PisoShiftElm(x1, y1);
		if (name == "PhaseCompElm")
			return (BaseElement) new PhaseCompElm(x1, y1);
		if (name == "CounterElm")
			return (BaseElement) new CounterElm(x1, y1);
		if (name == "DecadeElm")
			return (BaseElement) new RingCounterElm(x1, y1);
		if (name == "TimerElm")
			return (BaseElement) new TimerElm(x1, y1);
		if (name == "DACElm")
			return (BaseElement) new DACElm(x1, y1);
		if (name == "ADCElm")
			return (BaseElement) new ADCElm(x1, y1);
		if (name == "LatchElm")
			return (BaseElement) new LatchElm(x1, y1);
		if (name == "SeqGenElm")
			return (BaseElement) new SeqGenElm(x1, y1);
		if (name == "VCOElm")
			return (BaseElement) new VCOElm(x1, y1);
		if (name == "BoxElm")
			return (BaseElement) new BoxElm(x1, y1);
		if (name == "TextElm")
			return (BaseElement) new TextElm(x1, y1);
		if (name == "TFlipFlopElm")
			return (BaseElement) new TFlipFlopElm(x1, y1);
		if (name == "SevenSegDecoderElm")
			return (BaseElement) new SevenSegDecoderElm(x1, y1);
		if (name == "FullAdderElm")
			return (BaseElement) new FullAdderElm(x1, y1);
		if (name == "HalfAdderElm")
			return (BaseElement) new HalfAdderElm(x1, y1);
		if (name == "MonostableElm")
			return (BaseElement) new MonostableElm(x1, y1);
		if (name == "LabeledNodeElm")
			return (BaseElement) new LabeledNodeElm(x1, y1);

		// if you take out UserDefinedLogicElm, it will break people's saved shortcuts
		if (name == "UserDefinedLogicElm" || name == "CustomLogicElm")
			return (BaseElement) new CustomLogicElm(x1, y1);

		if (name == "TestPointElm")
			return new TestPointElm(x1, y1);
		if (name == "AmmeterElm")
			return new AmmeterElm(x1, y1);
		if (name == "DataRecorderElm")
			return (BaseElement) new DataRecorderElm(x1, y1);
		if (name == "AudioOutputElm")
			return (BaseElement) new AudioOutputElm(x1, y1);
		if (name == "NDarlingtonElm" || name == "DarlingtonElm")
			return (BaseElement) new NDarlingtonElm(x1, y1);
		if (name == "PDarlingtonElm")
			return (BaseElement) new PDarlingtonElm(x1, y1);
		if (name == "ComparatorElm")
			return (BaseElement) new ComparatorElm(x1, y1);
		if (name == "OTAElm")
			return (BaseElement) new OTAElm(x1, y1);
		if (name == "NoiseElm")
			return (BaseElement) new NoiseElm(x1, y1);
		if (name == "VCVSElm")
			return (BaseElement) new VCVSElm(x1, y1);
		if (name == "VCCSElm")
			return (BaseElement) new VCCSElm(x1, y1);
		if (name == "CCVSElm")
			return (BaseElement) new CCVSElm(x1, y1);
		if (name == "CCCSElm")
			return (BaseElement) new CCCSElm(x1, y1);
		if (name == "OhmMeterElm")
			return (BaseElement) new OhmMeterElm(x1, y1);
		if (name == "ScopeElm")
			return (BaseElement) new ScopeElm(x1, y1);
		if (name == "FuseElm")
			return (BaseElement) new FuseElm(x1, y1);
		if (name == "LEDArrayElm")
			return (BaseElement) new LEDArrayElm(x1, y1);
		if (name == "CustomTransformerElm")
			return (BaseElement) new CustomTransformerElm(x1, y1);
		if (name == "OptocouplerElm")
			return (BaseElement) new OptocouplerElm(x1, y1);
		if (name == "StopTriggerElm")
			return (BaseElement) new StopTriggerElm(x1, y1);
		if (name == "OpAmpRealElm")
			return (BaseElement) new OpAmpRealElm(x1, y1);
		if (name == "CustomCompositeElm")
			return (BaseElement) new CustomCompositeElm(x1, y1);
		if (name == "AudioInputElm")
			return (BaseElement) new AudioInputElm(x1, y1);
		return null;
	}
}
