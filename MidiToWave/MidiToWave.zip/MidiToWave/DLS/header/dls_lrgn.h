#pragma once
#include <windows.h>
#include <vector>
#include "dls_chunk.h"
#include "dls_rgn.h"

namespace DLS {
	class LRGN : Chunk {
	public:
		std::vector<RGN*> List;

	public:
		LRGN() {}
		void Load(LPBYTE ptr, UINT size) { Chunk::Load(ptr, size); }
		RGN* GetRegion(BYTE note, BYTE velocity);

	protected:
		void LoadList(LPBYTE ptr, UINT size) override;
	};
}