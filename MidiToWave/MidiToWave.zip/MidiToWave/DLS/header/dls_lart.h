#pragma once
#include <windows.h>
#include <vector>
#include "dls_chunk.h"
#include "dls_art.h"

namespace DLS {
	class LART : Chunk {
	public:
		ART *mp_art = NULL;

	public:
		LART() {}
		void Load(LPBYTE ptr, UINT size) { Chunk::Load(ptr, size); }

	protected:
		void LoadChunk(LPBYTE ptr) override;
	};
}