#pragma once
#include <windows.h>
#include <vector>
#include "dls_chunk.h"
#include "dls_lart.h"

namespace DLS {
	class RGN : Chunk {
	public:
		CK_RGNH *mp_header = NULL;
		CK_WSMP *mp_sampler = NULL;
		CK_WLNK *mp_waveLink = NULL;
		LART *mp_articulations = NULL;
		std::vector<WaveLoop*> Loops;

	public:
		RGN() {}
		void Load(LPBYTE ptr, UINT size) { Chunk::Load(ptr, size); }

	protected:
		void LoadChunk(LPBYTE ptr) override;
		void LoadList(LPBYTE ptr, UINT size) override;
	};
}
