#pragma once
#include <windows.h>
#include "dls_chunk.h"
#include "dls_lins.h"
#include "dls_wvpl.h"

namespace DLS {
	class DLS : public Chunk {
	private:
		UINT m_MSYN = 1;
		CK_VERS *mp_version = NULL;
		LINS *mp_instruments = NULL;
		WVPL *mp_wavePool = NULL;
		LPBYTE mp_dlsBuffer = NULL;

	public:
		DLS(LPWSTR filePath);
		~DLS();

		void Load(LPBYTE ptr, UINT size) { Chunk::Load(ptr, size); };
		INS* GetInst(MidiLocale &locale);
		WAVE* GetWave(RGN &region);

	protected:
		void LoadChunk(LPBYTE ptr);
		void LoadList(LPBYTE ptr, UINT size);
	};
}