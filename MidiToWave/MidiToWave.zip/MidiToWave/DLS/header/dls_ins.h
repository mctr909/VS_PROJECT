#pragma once
#include <windows.h>
#include "dls_chunk.h"
#include "dls_lrgn.h"
#include "dls_lart.h"

namespace DLS {
	class INS : Chunk {
	public:
		CK_INSH *mp_header = NULL;
		LRGN *mp_regions = NULL;
		LART *mp_articulations = NULL;

	public:
		INS() {}
		void Load(LPBYTE ptr, UINT size) { Chunk::Load(ptr, size); }

	protected:
		void LoadChunk(LPBYTE ptr) override;
		void LoadList(LPBYTE ptr, UINT size) override;
	};
}
