#pragma once
#include <windows.h>
#include <vector>
#include "dls_chunk.h"
#include "dls_ins.h"

namespace DLS {
	class LINS : Chunk {
	public:
		std::vector<INS*> List;

	public:
		LINS() {}
		void Load(LPBYTE ptr, UINT size) { Chunk::Load(ptr, size); }

	protected:
		void LoadList(LPBYTE ptr, UINT size) override;
	};
}