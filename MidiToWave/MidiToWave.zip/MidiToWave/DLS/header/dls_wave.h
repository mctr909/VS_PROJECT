#pragma once
#include <windows.h>
#include <vector>
#include "dls_chunk.h"

namespace DLS {
	class WAVE : Chunk {
	public:
		CK_FMT *mp_format = NULL;
		CK_WSMP *mp_sampler = NULL;
		LPBYTE mp_data = NULL;
		UINT m_dataSize = 0;
		std::vector<WaveLoop*> Loops;

	public:
		WAVE() {}
		void Load(LPBYTE ptr, UINT size) { Chunk::Load(ptr, size); }

	protected:
		void LoadChunk(LPBYTE ptr) override;
		void LoadList(LPBYTE ptr, UINT size) override;
	};
}