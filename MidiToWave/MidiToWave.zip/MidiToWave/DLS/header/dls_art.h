#pragma once
#include <windows.h>
#include <vector>
#include "dls_chunk.h"

namespace DLS {
	class ART {
	public:
		std::vector<Connection*> List;

	public:
		ART(LPBYTE ptr);
	};
}