#pragma once
#include <windows.h>
#include <vector>
#include "dls_chunk.h"
#include "dls_wave.h"

namespace DLS {
	class WVPL : Chunk {
	public:
		std::vector<WAVE*> List;

	public:
		WVPL() {}
		void Load(LPBYTE ptr, UINT size) { Chunk::Load(ptr, size); }

	protected:
		void LoadList(LPBYTE ptr, UINT size) override;
	};
}