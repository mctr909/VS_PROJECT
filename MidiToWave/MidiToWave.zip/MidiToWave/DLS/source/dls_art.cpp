#include "dls_lart.h"
#include "dls_art.h"

DLS::ART::ART(LPBYTE ptr) {
	CK_ART1 info;
	memcpy(&info, ptr, sizeof(CK_ART1));
	ptr += sizeof(CK_ART1);

	for (UINT i = 0; i < info.Count; ++i) {
		List.push_back((Connection*)ptr);
		ptr += sizeof(Connection);
	}
}