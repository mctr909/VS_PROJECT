#include "dls_art.h"
#include "dls_lart.h"

void
DLS::LART::LoadChunk(LPBYTE ptr) {
	switch (mp_chunk->Type) {
	case CHUNK_TYPE_ART1:
	case CHUNK_TYPE_ART2:
		mp_art = new ART(ptr);
		break;
	default:
		// "Unknown ChunkType"
		break;
	}
}