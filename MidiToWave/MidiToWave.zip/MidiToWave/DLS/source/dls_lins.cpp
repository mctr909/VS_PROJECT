#include "dls_ins.h"
#include "dls_lins.h"

void
DLS::LINS::LoadList(LPBYTE ptr, UINT size) {
	switch (mp_list->Type) {
	case LIST_TYPE_INS_:
		List.push_back(new INS);
		(*List.rbegin())->Load(ptr, size);
		break;
	default:
		// "Unknown ListId"
		break;
	}
}