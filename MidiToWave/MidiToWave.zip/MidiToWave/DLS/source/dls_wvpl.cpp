#include "dls_wave.h"
#include "dls_wvpl.h"

void
DLS::WVPL::LoadList(LPBYTE ptr, UINT size) {
	switch (mp_list->Type) {
	case LIST_TYPE_WAVE:
		List.push_back(new WAVE);
		(*List.rbegin())->Load(ptr, size);
		break;
	default:
		break;
	}
}