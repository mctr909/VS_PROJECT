#include "dls.h"

DLS::DLS::DLS(LPWSTR filePath) {
	UINT size = 0;
	FILE *fp = NULL;
	_wfopen_s(&fp, filePath, TEXT("r"));

	if (NULL != fp) {
		fseek(fp, 4, SEEK_CUR);
		fread(&size, 4, 1, fp);
		fseek(fp, 4, SEEK_CUR);

		if (NULL != mp_dlsBuffer) {
			free(mp_dlsBuffer);
			mp_dlsBuffer = NULL;
		}

		mp_dlsBuffer = (LPBYTE)malloc(size);
		fread(mp_dlsBuffer, size, 1, fp);

		Load(mp_dlsBuffer, size);

		fclose(fp);
	}
}

DLS::DLS::~DLS() {
	if (NULL != mp_dlsBuffer) {
		free(mp_dlsBuffer);
		mp_dlsBuffer = NULL;
	}
}

DLS::INS*
DLS::DLS::GetInst(MidiLocale &locale) {
	for (auto ins : mp_instruments->List) {
		auto hdLocale = ins->mp_header->Locale;

		if (hdLocale.BankFlags == locale.BankFlags &&
			hdLocale.ProgramNo == locale.ProgramNo &&
			hdLocale.BankMSB == locale.BankMSB &&
			hdLocale.BankLSB == locale.BankLSB
		) {
			return ins;
		}
	}

	return NULL;
}

DLS::WAVE*
DLS::DLS::GetWave(RGN &region) {
	return mp_wavePool->List[region.mp_waveLink->TableIndex];
}

void
DLS::DLS::LoadChunk(LPBYTE ptr) {
	switch (mp_chunk->Type) {
	case CHUNK_TYPE_COLH:
		break;
	case CHUNK_TYPE_VERS:
		mp_version = (CK_VERS*)ptr;
		break;
	case CHUNK_TYPE_MSYN:
		break;
	case CHUNK_TYPE_PTBL:
		break;
	case CHUNK_TYPE_DLID:
		break;
	default:
		//"Unknown ChunkType"
		break;
	}
}

void
DLS::DLS::LoadList(LPBYTE ptr, UINT size) {
	switch (mp_list->Type) {
	case LIST_TYPE_LINS:
		mp_instruments = new LINS;
		mp_instruments->Load(ptr, size);
		break;
	case LIST_TYPE_WVPL:
		mp_wavePool = new WVPL;
		mp_wavePool->Load(ptr, size);
		break;
	case LIST_TYPE_INFO:
		break;
	default:
		// "Unknown ListType"
		break;
	}
}