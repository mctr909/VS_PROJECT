#include "dls_rgn.h"
#include "dls_lrgn.h"

DLS::RGN*
DLS::LRGN::GetRegion(BYTE note, BYTE velocity) {
	for (auto rgn : List) {
		auto k = rgn->mp_header->Key;
		auto v = rgn->mp_header->Velocity;
		if (k.Low <= note && note <= k.High &&
			v.Low <= velocity && velocity <= v.High
		) {
			return rgn;
		}
	}

	return NULL;
}

void
DLS::LRGN::LoadList(LPBYTE ptr, UINT size) {
	switch (mp_list->Type) {
	case LIST_TYPE_RGN_:
		List.push_back(new RGN);
		(*List.rbegin())->Load(ptr, size);
		break;
	default:
		// "Unknown ListType"
		break;
	}
}