﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PianoRoll {
    public partial class Form1 : Form {
        private enum E_EDIT_MODE  {
            NOTE,
            INST,
            VOL,
            EXP,
            PAN,
            PITCH,
            VIB,
            REV,
            DEL,
            CHO,
            FC,
            Q,
            ATTACK,
            RELEASE
        }

        private Dictionary<E_EDIT_MODE, string> editModes = new Dictionary<E_EDIT_MODE, string> {
            { E_EDIT_MODE.NOTE, "音符" },
            { E_EDIT_MODE.INST, "音色" },
            { E_EDIT_MODE.VOL, "音量" },
            { E_EDIT_MODE.EXP, "強弱" },
            { E_EDIT_MODE.PAN, "定位" },
            { E_EDIT_MODE.PITCH, "ピッチ" },
            { E_EDIT_MODE.VIB, "ビブラート" },
            { E_EDIT_MODE.REV, "リバーブ" },
            { E_EDIT_MODE.DEL, "ディレイ" },
            { E_EDIT_MODE.CHO, "コーラス" },
            { E_EDIT_MODE.FC, "カットオフ" },
            { E_EDIT_MODE.Q, "レゾナンス" },
            { E_EDIT_MODE.ATTACK, "立ち上がり時間" },
            { E_EDIT_MODE.RELEASE, "持続時間" }
        };

        public Form1() {
            InitializeComponent();
            setSize();
            setEditModeList();
            setInputMode(tsbRoll);
            setSelectWrite(tsbWrite);
        }

        private void Form1_SizeChanged(object sender, EventArgs e) {
            setSize();
        }

        private void tsbRoll_Click(object sender, EventArgs e) {
            setInputMode(sender);
        }

        private void tsbEventList_Click(object sender, EventArgs e) {
            setInputMode(sender);
        }

        private void tsbSelect_Click(object sender, EventArgs e) {
            setSelectWrite(tsbSelect);
        }

        private void tsbWrite_Click(object sender, EventArgs e) {
            setSelectWrite(tsbWrite);
        }

        private void tsmTick960_Click(object sender, EventArgs e) {
            setTimeDiv(sender);
        }

        private void tsmTick480_Click(object sender, EventArgs e) {
            setTimeDiv(sender);
        }

        private void tsmTick240_Click(object sender, EventArgs e) {
            setTimeDiv(sender);
        }

        private void tsmTick120_Click(object sender, EventArgs e) {
            setTimeDiv(sender);
        }

        private void tsmTick060_Click(object sender, EventArgs e) {
            setTimeDiv(sender);
        }

        private void tsmTick640_Click(object sender, EventArgs e) {
            setTimeDiv(sender);
        }

        private void tsmTick320_Click(object sender, EventArgs e) {
            setTimeDiv(sender);
        }

        private void tsmTick160_Click(object sender, EventArgs e) {
            setTimeDiv(sender);
        }

        private void tsmTick080_Click(object sender, EventArgs e) {
            setTimeDiv(sender);
        }

        private void tsmTick040_Click(object sender, EventArgs e) {
            setTimeDiv(sender);
        }

        private void tsmTick384_Click(object sender, EventArgs e) {
            setTimeDiv(sender);
        }

        private void tsmTick192_Click(object sender, EventArgs e) {
            setTimeDiv(sender);
        }

        private void tsmTick096_Click(object sender, EventArgs e) {
            setTimeDiv(sender);
        }

        private void tsmTick048_Click(object sender, EventArgs e) {
            setTimeDiv(sender);
        }

        private void tsmTick024_Click(object sender, EventArgs e) {
            setTimeDiv(sender);
        }


        private void setEditModeList() {
            foreach (var name in editModes.Values) {
                tscEditMode.Items.Add(name);
            }
            tscEditMode.SelectedIndex = 0;
        }

        private void setSize() {
            pnlRoll.Left = 0;
            pnlRoll.Top = toolStrip1.Bottom;
            pnlRoll.Width = Width - 16;
            pnlRoll.Height = Height - toolStrip1.Bottom - 39;
            vScroll.Top = 0;
            vScroll.Left = pnlRoll.Width - vScroll.Width;
            vScroll.Height = pnlRoll.Height - hScroll.Height;
            hScroll.Left = 0;
            hScroll.Top = pnlRoll.Height - hScroll.Height;
            hScroll.Width = pnlRoll.Width - vScroll.Width;
            picRoll.Left = 0;
            picRoll.Top = 0;
            picRoll.Width = vScroll.Left;
            picRoll.Height = hScroll.Top;
        }

        private void setInputMode(object item) {
            tsbRoll.Checked = false;
            tsbRoll.Image = Properties.Resources.pianoroll_disable;
            tsbEventList.Checked = false;
            tsbEventList.Image = Properties.Resources.eventlist_disable;

            var obj = (ToolStripButton)item;
            obj.Checked = true;

            switch (obj.Name) {
            case "tsbRoll":
                tsbRoll.Image = Properties.Resources.pianoroll;
                break;
            case "tsbEventList":
                tsbEventList.Image = Properties.Resources.eventlist;
                break;
            }
        }

        private void setSelectWrite(object item) {
            tsbWrite.Checked = false;
            tsbWrite.Image = Properties.Resources.write_disable;
            tsbSelect.Checked = false;
            tsbSelect.Image = Properties.Resources.select_disable;

            var obj = (ToolStripButton)item;
            obj.Checked = true;

            switch (obj.Name) {
            case "tsbWrite":
                tsbWrite.Image = Properties.Resources.write;
                break;
            case "tsbSelect":
                tsbSelect.Image = Properties.Resources.select;
                break;
            }
        }

        private void setTimeDiv(object item) {
            tsmTick960.Checked = false;

            tsmTick960.Checked = false;
            tsmTick480.Checked = false;
            tsmTick240.Checked = false;
            tsmTick120.Checked = false;
            tsmTick060.Checked = false;

            tsmTick640.Checked = false;
            tsmTick320.Checked = false;
            tsmTick160.Checked = false;
            tsmTick080.Checked = false;
            tsmTick040.Checked = false;

            tsmTick384.Checked = false;
            tsmTick192.Checked = false;
            tsmTick096.Checked = false;
            tsmTick048.Checked = false;
            tsmTick024.Checked = false;

            var obj = (ToolStripMenuItem)item;
            obj.Checked = true;
            tsdTimeDiv.Image = obj.Image;
        }
    }
}
