﻿namespace PianoRoll {
    partial class Form1 {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージド リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent() {
            this.pnlRoll = new System.Windows.Forms.Panel();
            this.vScroll = new System.Windows.Forms.VScrollBar();
            this.hScroll = new System.Windows.Forms.HScrollBar();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.tscEditMode = new System.Windows.Forms.ToolStripComboBox();
            this.tsbSelect = new System.Windows.Forms.ToolStripButton();
            this.tsbRoll = new System.Windows.Forms.ToolStripButton();
            this.tsbEventList = new System.Windows.Forms.ToolStripButton();
            this.tsbWrite = new System.Windows.Forms.ToolStripButton();
            this.tsdTimeDiv = new System.Windows.Forms.ToolStripDropDownButton();
            this.tsmTick960 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmTick480 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmTick240 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmTick120 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmTick060 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmTick640 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmTick320 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmTick160 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmTick080 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmTick040 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmTick384 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmTick192 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmTick096 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmTick048 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmTick024 = new System.Windows.Forms.ToolStripMenuItem();
            this.picRoll = new System.Windows.Forms.PictureBox();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.pnlRoll.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picRoll)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlRoll
            // 
            this.pnlRoll.BackColor = System.Drawing.SystemColors.ControlDark;
            this.pnlRoll.Controls.Add(this.vScroll);
            this.pnlRoll.Controls.Add(this.hScroll);
            this.pnlRoll.Controls.Add(this.picRoll);
            this.pnlRoll.Location = new System.Drawing.Point(12, 58);
            this.pnlRoll.Name = "pnlRoll";
            this.pnlRoll.Size = new System.Drawing.Size(373, 190);
            this.pnlRoll.TabIndex = 1;
            // 
            // vScroll
            // 
            this.vScroll.Location = new System.Drawing.Point(350, 3);
            this.vScroll.Name = "vScroll";
            this.vScroll.Size = new System.Drawing.Size(17, 167);
            this.vScroll.TabIndex = 2;
            // 
            // hScroll
            // 
            this.hScroll.Location = new System.Drawing.Point(3, 173);
            this.hScroll.Name = "hScroll";
            this.hScroll.Size = new System.Drawing.Size(344, 17);
            this.hScroll.TabIndex = 1;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbRoll,
            this.tsbEventList,
            this.toolStripSeparator1,
            this.toolStripSeparator6,
            this.tsbWrite,
            this.tsbSelect,
            this.toolStripSeparator2,
            this.toolStripSeparator7,
            this.tsdTimeDiv,
            this.toolStripSeparator3,
            this.tscEditMode});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(494, 31);
            this.toolStrip1.TabIndex = 2;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 31);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 31);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 31);
            // 
            // tscEditMode
            // 
            this.tscEditMode.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.tscEditMode.Name = "tscEditMode";
            this.tscEditMode.Size = new System.Drawing.Size(121, 31);
            this.tscEditMode.ToolTipText = "入力タイプ";
            // 
            // tsbSelect
            // 
            this.tsbSelect.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbSelect.Image = global::PianoRoll.Properties.Resources.select;
            this.tsbSelect.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbSelect.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSelect.Name = "tsbSelect";
            this.tsbSelect.Size = new System.Drawing.Size(29, 28);
            this.tsbSelect.Text = "選択";
            this.tsbSelect.ToolTipText = "選択モード";
            this.tsbSelect.Click += new System.EventHandler(this.tsbSelect_Click);
            // 
            // tsbRoll
            // 
            this.tsbRoll.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbRoll.Image = global::PianoRoll.Properties.Resources.pianoroll;
            this.tsbRoll.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbRoll.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbRoll.Name = "tsbRoll";
            this.tsbRoll.Size = new System.Drawing.Size(28, 28);
            this.tsbRoll.Text = "toolStripButton1";
            this.tsbRoll.ToolTipText = "ピアノロール入力";
            this.tsbRoll.Click += new System.EventHandler(this.tsbRoll_Click);
            // 
            // tsbEventList
            // 
            this.tsbEventList.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbEventList.Image = global::PianoRoll.Properties.Resources.eventlist;
            this.tsbEventList.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbEventList.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbEventList.Name = "tsbEventList";
            this.tsbEventList.Size = new System.Drawing.Size(28, 28);
            this.tsbEventList.Text = "リスト入力";
            this.tsbEventList.Click += new System.EventHandler(this.tsbEventList_Click);
            // 
            // tsbWrite
            // 
            this.tsbWrite.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbWrite.Image = global::PianoRoll.Properties.Resources.write;
            this.tsbWrite.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbWrite.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbWrite.Name = "tsbWrite";
            this.tsbWrite.Size = new System.Drawing.Size(28, 28);
            this.tsbWrite.Text = "書き込み";
            this.tsbWrite.ToolTipText = "書き込みモード";
            this.tsbWrite.Click += new System.EventHandler(this.tsbWrite_Click);
            // 
            // tsdTimeDiv
            // 
            this.tsdTimeDiv.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsdTimeDiv.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmTick960,
            this.tsmTick480,
            this.tsmTick240,
            this.tsmTick120,
            this.tsmTick060,
            this.toolStripSeparator4,
            this.tsmTick640,
            this.tsmTick320,
            this.tsmTick160,
            this.tsmTick080,
            this.tsmTick040,
            this.toolStripSeparator5,
            this.tsmTick384,
            this.tsmTick192,
            this.tsmTick096,
            this.tsmTick048,
            this.tsmTick024});
            this.tsdTimeDiv.Image = global::PianoRoll.Properties.Resources.tick240;
            this.tsdTimeDiv.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsdTimeDiv.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsdTimeDiv.Name = "tsdTimeDiv";
            this.tsdTimeDiv.Size = new System.Drawing.Size(29, 28);
            this.tsdTimeDiv.Text = "入力単位";
            // 
            // tsmTick960
            // 
            this.tsmTick960.Image = global::PianoRoll.Properties.Resources.tick960;
            this.tsmTick960.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmTick960.Name = "tsmTick960";
            this.tsmTick960.Size = new System.Drawing.Size(116, 30);
            this.tsmTick960.Text = "4分";
            this.tsmTick960.Click += new System.EventHandler(this.tsmTick960_Click);
            // 
            // tsmTick480
            // 
            this.tsmTick480.Image = global::PianoRoll.Properties.Resources.tick480;
            this.tsmTick480.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmTick480.Name = "tsmTick480";
            this.tsmTick480.Size = new System.Drawing.Size(116, 30);
            this.tsmTick480.Text = "8分";
            this.tsmTick480.Click += new System.EventHandler(this.tsmTick480_Click);
            // 
            // tsmTick240
            // 
            this.tsmTick240.Checked = true;
            this.tsmTick240.CheckState = System.Windows.Forms.CheckState.Checked;
            this.tsmTick240.Image = global::PianoRoll.Properties.Resources.tick240;
            this.tsmTick240.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmTick240.Name = "tsmTick240";
            this.tsmTick240.Size = new System.Drawing.Size(116, 30);
            this.tsmTick240.Text = "16分";
            this.tsmTick240.Click += new System.EventHandler(this.tsmTick240_Click);
            // 
            // tsmTick120
            // 
            this.tsmTick120.Image = global::PianoRoll.Properties.Resources.tick120;
            this.tsmTick120.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmTick120.Name = "tsmTick120";
            this.tsmTick120.Size = new System.Drawing.Size(116, 30);
            this.tsmTick120.Text = "32分";
            this.tsmTick120.Click += new System.EventHandler(this.tsmTick120_Click);
            // 
            // tsmTick060
            // 
            this.tsmTick060.Image = global::PianoRoll.Properties.Resources.tick060;
            this.tsmTick060.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmTick060.Name = "tsmTick060";
            this.tsmTick060.Size = new System.Drawing.Size(116, 30);
            this.tsmTick060.Text = "64分";
            this.tsmTick060.Click += new System.EventHandler(this.tsmTick060_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(113, 6);
            // 
            // tsmTick640
            // 
            this.tsmTick640.Image = global::PianoRoll.Properties.Resources.tick640;
            this.tsmTick640.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmTick640.Name = "tsmTick640";
            this.tsmTick640.Size = new System.Drawing.Size(116, 30);
            this.tsmTick640.Text = "3連4分";
            this.tsmTick640.Click += new System.EventHandler(this.tsmTick640_Click);
            // 
            // tsmTick320
            // 
            this.tsmTick320.Image = global::PianoRoll.Properties.Resources.tick320;
            this.tsmTick320.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmTick320.Name = "tsmTick320";
            this.tsmTick320.Size = new System.Drawing.Size(116, 30);
            this.tsmTick320.Text = "3連8分";
            this.tsmTick320.Click += new System.EventHandler(this.tsmTick320_Click);
            // 
            // tsmTick160
            // 
            this.tsmTick160.Image = global::PianoRoll.Properties.Resources.tick160;
            this.tsmTick160.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmTick160.Name = "tsmTick160";
            this.tsmTick160.Size = new System.Drawing.Size(116, 30);
            this.tsmTick160.Text = "3連16分";
            this.tsmTick160.Click += new System.EventHandler(this.tsmTick160_Click);
            // 
            // tsmTick080
            // 
            this.tsmTick080.Image = global::PianoRoll.Properties.Resources.tick080;
            this.tsmTick080.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmTick080.Name = "tsmTick080";
            this.tsmTick080.Size = new System.Drawing.Size(116, 30);
            this.tsmTick080.Text = "3連32分";
            this.tsmTick080.Click += new System.EventHandler(this.tsmTick080_Click);
            // 
            // tsmTick040
            // 
            this.tsmTick040.Image = global::PianoRoll.Properties.Resources.tick040;
            this.tsmTick040.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmTick040.Name = "tsmTick040";
            this.tsmTick040.Size = new System.Drawing.Size(116, 30);
            this.tsmTick040.Text = "3連64分";
            this.tsmTick040.Click += new System.EventHandler(this.tsmTick040_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(113, 6);
            // 
            // tsmTick384
            // 
            this.tsmTick384.Image = global::PianoRoll.Properties.Resources.tick384;
            this.tsmTick384.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmTick384.Name = "tsmTick384";
            this.tsmTick384.Size = new System.Drawing.Size(116, 30);
            this.tsmTick384.Text = "5連4分";
            this.tsmTick384.Click += new System.EventHandler(this.tsmTick384_Click);
            // 
            // tsmTick192
            // 
            this.tsmTick192.Image = global::PianoRoll.Properties.Resources.tick192;
            this.tsmTick192.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmTick192.Name = "tsmTick192";
            this.tsmTick192.Size = new System.Drawing.Size(116, 30);
            this.tsmTick192.Text = "5連8分";
            this.tsmTick192.Click += new System.EventHandler(this.tsmTick192_Click);
            // 
            // tsmTick096
            // 
            this.tsmTick096.Image = global::PianoRoll.Properties.Resources.tick096;
            this.tsmTick096.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmTick096.Name = "tsmTick096";
            this.tsmTick096.Size = new System.Drawing.Size(116, 30);
            this.tsmTick096.Text = "5連16分";
            this.tsmTick096.Click += new System.EventHandler(this.tsmTick096_Click);
            // 
            // tsmTick048
            // 
            this.tsmTick048.Image = global::PianoRoll.Properties.Resources.tick048;
            this.tsmTick048.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmTick048.Name = "tsmTick048";
            this.tsmTick048.Size = new System.Drawing.Size(116, 30);
            this.tsmTick048.Text = "5連32分";
            this.tsmTick048.Click += new System.EventHandler(this.tsmTick048_Click);
            // 
            // tsmTick024
            // 
            this.tsmTick024.Image = global::PianoRoll.Properties.Resources.tick024;
            this.tsmTick024.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmTick024.Name = "tsmTick024";
            this.tsmTick024.Size = new System.Drawing.Size(116, 30);
            this.tsmTick024.Text = "5連64分";
            this.tsmTick024.Click += new System.EventHandler(this.tsmTick024_Click);
            // 
            // picRoll
            // 
            this.picRoll.Location = new System.Drawing.Point(3, 3);
            this.picRoll.Name = "picRoll";
            this.picRoll.Size = new System.Drawing.Size(344, 167);
            this.picRoll.TabIndex = 0;
            this.picRoll.TabStop = false;
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(6, 31);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(6, 31);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(494, 279);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.pnlRoll);
            this.Name = "Form1";
            this.Text = "Form1";
            this.SizeChanged += new System.EventHandler(this.Form1_SizeChanged);
            this.pnlRoll.ResumeLayout(false);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picRoll)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picRoll;
        private System.Windows.Forms.Panel pnlRoll;
        private System.Windows.Forms.VScrollBar vScroll;
        private System.Windows.Forms.HScrollBar hScroll;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tsbSelect;
        private System.Windows.Forms.ToolStripButton tsbEventList;
        private System.Windows.Forms.ToolStripButton tsbRoll;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton tsbWrite;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripDropDownButton tsdTimeDiv;
        private System.Windows.Forms.ToolStripMenuItem tsmTick960;
        private System.Windows.Forms.ToolStripMenuItem tsmTick480;
        private System.Windows.Forms.ToolStripMenuItem tsmTick240;
        private System.Windows.Forms.ToolStripMenuItem tsmTick120;
        private System.Windows.Forms.ToolStripMenuItem tsmTick060;
        private System.Windows.Forms.ToolStripMenuItem tsmTick640;
        private System.Windows.Forms.ToolStripMenuItem tsmTick320;
        private System.Windows.Forms.ToolStripMenuItem tsmTick160;
        private System.Windows.Forms.ToolStripMenuItem tsmTick080;
        private System.Windows.Forms.ToolStripMenuItem tsmTick040;
        private System.Windows.Forms.ToolStripMenuItem tsmTick384;
        private System.Windows.Forms.ToolStripMenuItem tsmTick192;
        private System.Windows.Forms.ToolStripMenuItem tsmTick096;
        private System.Windows.Forms.ToolStripMenuItem tsmTick048;
        private System.Windows.Forms.ToolStripMenuItem tsmTick024;
        private System.Windows.Forms.ToolStripComboBox tscEditMode;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
    }
}

