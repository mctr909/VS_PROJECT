﻿namespace PianoRoll {
    partial class Form1 {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージド リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            this.pnlRoll = new System.Windows.Forms.Panel();
            this.vScroll = new System.Windows.Forms.VScrollBar();
            this.hScroll = new System.Windows.Forms.HScrollBar();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tsbRoll = new System.Windows.Forms.ToolStripButton();
            this.tsbEventList = new System.Windows.Forms.ToolStripButton();
            this.tsbWrite = new System.Windows.Forms.ToolStripButton();
            this.tsbSelect = new System.Windows.Forms.ToolStripButton();
            this.tsdEditMode = new System.Windows.Forms.ToolStripDropDownButton();
            this.tsmEditModeNote = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmEditModeInst = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator14 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmEditModeVol = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmEditModeExp = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmEditModePan = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmEditModePitch = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmEditModeVib = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmEditModeVibDep = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmEditModeVibRate = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator10 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmEditModeDel = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmEditModeDelDep = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmEditModeDelTime = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmEditModeRev = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmEditModeCho = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator11 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmEditModeFc = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmEditModeFq = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator12 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmEditModeAttack = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmEditModeRelease = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator13 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmEditModeTempo = new System.Windows.Forms.ToolStripMenuItem();
            this.tsdTimeDiv = new System.Windows.Forms.ToolStripDropDownButton();
            this.tsmTick960 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmTick480 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmTick240 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmTick120 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmTick060 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmTick640 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmTick320 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmTick160 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmTick080 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmTick040 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmTick384 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmTick192 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmTick096 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmTick048 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmTick024 = new System.Windows.Forms.ToolStripMenuItem();
            this.picRoll = new System.Windows.Forms.PictureBox();
            this.toolStripSeparator15 = new System.Windows.Forms.ToolStripSeparator();
            this.tslStatus = new System.Windows.Forms.ToolStripLabel();
            this.pnlRoll.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picRoll)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlRoll
            // 
            this.pnlRoll.BackColor = System.Drawing.Color.White;
            this.pnlRoll.Controls.Add(this.vScroll);
            this.pnlRoll.Controls.Add(this.hScroll);
            this.pnlRoll.Controls.Add(this.picRoll);
            this.pnlRoll.Location = new System.Drawing.Point(12, 58);
            this.pnlRoll.Name = "pnlRoll";
            this.pnlRoll.Size = new System.Drawing.Size(373, 190);
            this.pnlRoll.TabIndex = 1;
            // 
            // vScroll
            // 
            this.vScroll.Location = new System.Drawing.Point(350, 3);
            this.vScroll.Name = "vScroll";
            this.vScroll.Size = new System.Drawing.Size(17, 167);
            this.vScroll.TabIndex = 2;
            // 
            // hScroll
            // 
            this.hScroll.Location = new System.Drawing.Point(3, 173);
            this.hScroll.Name = "hScroll";
            this.hScroll.Size = new System.Drawing.Size(344, 17);
            this.hScroll.TabIndex = 1;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbRoll,
            this.tsbEventList,
            this.toolStripSeparator1,
            this.toolStripSeparator6,
            this.tsbWrite,
            this.tsbSelect,
            this.toolStripSeparator2,
            this.toolStripSeparator7,
            this.tsdEditMode,
            this.tsdTimeDiv,
            this.toolStripSeparator3,
            this.toolStripSeparator15,
            this.tslStatus});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(494, 31);
            this.toolStrip1.TabIndex = 2;
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 31);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(6, 31);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 31);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(6, 31);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 31);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // tsbRoll
            // 
            this.tsbRoll.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbRoll.Image = global::PianoRoll.Properties.Resources.pianoroll;
            this.tsbRoll.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbRoll.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbRoll.Name = "tsbRoll";
            this.tsbRoll.Size = new System.Drawing.Size(28, 28);
            this.tsbRoll.Text = "toolStripButton1";
            this.tsbRoll.ToolTipText = "ピアノロール入力";
            this.tsbRoll.Click += new System.EventHandler(this.tsbRoll_Click);
            // 
            // tsbEventList
            // 
            this.tsbEventList.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbEventList.Image = global::PianoRoll.Properties.Resources.eventlist;
            this.tsbEventList.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbEventList.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbEventList.Name = "tsbEventList";
            this.tsbEventList.Size = new System.Drawing.Size(28, 28);
            this.tsbEventList.Text = "リスト入力";
            this.tsbEventList.Click += new System.EventHandler(this.tsbEventList_Click);
            // 
            // tsbWrite
            // 
            this.tsbWrite.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbWrite.Image = global::PianoRoll.Properties.Resources.write;
            this.tsbWrite.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbWrite.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbWrite.Name = "tsbWrite";
            this.tsbWrite.Size = new System.Drawing.Size(28, 28);
            this.tsbWrite.Text = "書き込み";
            this.tsbWrite.ToolTipText = "書き込みモード";
            this.tsbWrite.Click += new System.EventHandler(this.tsbWrite_Click);
            // 
            // tsbSelect
            // 
            this.tsbSelect.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbSelect.Image = global::PianoRoll.Properties.Resources.select;
            this.tsbSelect.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbSelect.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSelect.Name = "tsbSelect";
            this.tsbSelect.Size = new System.Drawing.Size(29, 28);
            this.tsbSelect.Text = "選択";
            this.tsbSelect.ToolTipText = "選択モード";
            this.tsbSelect.Click += new System.EventHandler(this.tsbSelect_Click);
            // 
            // tsdEditMode
            // 
            this.tsdEditMode.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsdEditMode.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmEditModeNote,
            this.toolStripSeparator8,
            this.tsmEditModeInst,
            this.toolStripSeparator14,
            this.tsmEditModeVol,
            this.tsmEditModeExp,
            this.tsmEditModePan,
            this.toolStripSeparator9,
            this.tsmEditModePitch,
            this.tsmEditModeVib,
            this.toolStripSeparator10,
            this.tsmEditModeDel,
            this.tsmEditModeRev,
            this.tsmEditModeCho,
            this.toolStripSeparator11,
            this.tsmEditModeFc,
            this.tsmEditModeFq,
            this.toolStripSeparator12,
            this.tsmEditModeAttack,
            this.tsmEditModeRelease,
            this.toolStripSeparator13,
            this.tsmEditModeTempo});
            this.tsdEditMode.Image = global::PianoRoll.Properties.Resources.edit_note;
            this.tsdEditMode.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsdEditMode.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsdEditMode.Name = "tsdEditMode";
            this.tsdEditMode.Size = new System.Drawing.Size(37, 28);
            this.tsdEditMode.Text = "入力種別";
            // 
            // tsmEditModeNote
            // 
            this.tsmEditModeNote.Image = global::PianoRoll.Properties.Resources.edit_note;
            this.tsmEditModeNote.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmEditModeNote.Name = "tsmEditModeNote";
            this.tsmEditModeNote.Size = new System.Drawing.Size(157, 30);
            this.tsmEditModeNote.Text = "音符";
            this.tsmEditModeNote.Click += new System.EventHandler(this.tsmEditModeNote_Click);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(154, 6);
            // 
            // tsmEditModeInst
            // 
            this.tsmEditModeInst.Image = global::PianoRoll.Properties.Resources.edit_inst;
            this.tsmEditModeInst.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmEditModeInst.Name = "tsmEditModeInst";
            this.tsmEditModeInst.Size = new System.Drawing.Size(157, 30);
            this.tsmEditModeInst.Text = "音色";
            this.tsmEditModeInst.Click += new System.EventHandler(this.tsmEditModeInst_Click);
            // 
            // toolStripSeparator14
            // 
            this.toolStripSeparator14.Name = "toolStripSeparator14";
            this.toolStripSeparator14.Size = new System.Drawing.Size(154, 6);
            // 
            // tsmEditModeVol
            // 
            this.tsmEditModeVol.Image = global::PianoRoll.Properties.Resources.edit_vol;
            this.tsmEditModeVol.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmEditModeVol.Name = "tsmEditModeVol";
            this.tsmEditModeVol.Size = new System.Drawing.Size(157, 30);
            this.tsmEditModeVol.Text = "音量";
            this.tsmEditModeVol.Click += new System.EventHandler(this.tsmEditModeVol_Click);
            // 
            // tsmEditModeExp
            // 
            this.tsmEditModeExp.Image = global::PianoRoll.Properties.Resources.edit_exp;
            this.tsmEditModeExp.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmEditModeExp.Name = "tsmEditModeExp";
            this.tsmEditModeExp.Size = new System.Drawing.Size(157, 30);
            this.tsmEditModeExp.Text = "強弱";
            this.tsmEditModeExp.Click += new System.EventHandler(this.tsmEditModeExp_Click);
            // 
            // tsmEditModePan
            // 
            this.tsmEditModePan.Image = global::PianoRoll.Properties.Resources.edit_pan;
            this.tsmEditModePan.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmEditModePan.Name = "tsmEditModePan";
            this.tsmEditModePan.Size = new System.Drawing.Size(157, 30);
            this.tsmEditModePan.Text = "定位";
            this.tsmEditModePan.Click += new System.EventHandler(this.tsmEditModePan_Click);
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(154, 6);
            // 
            // tsmEditModePitch
            // 
            this.tsmEditModePitch.Image = global::PianoRoll.Properties.Resources.edit_pitch;
            this.tsmEditModePitch.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmEditModePitch.Name = "tsmEditModePitch";
            this.tsmEditModePitch.Size = new System.Drawing.Size(157, 30);
            this.tsmEditModePitch.Text = "ピッチ";
            this.tsmEditModePitch.Click += new System.EventHandler(this.tsmEditModePitch_Click);
            // 
            // tsmEditModeVib
            // 
            this.tsmEditModeVib.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmEditModeVibDep,
            this.tsmEditModeVibRate});
            this.tsmEditModeVib.Image = global::PianoRoll.Properties.Resources.edit_vib;
            this.tsmEditModeVib.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmEditModeVib.Name = "tsmEditModeVib";
            this.tsmEditModeVib.Size = new System.Drawing.Size(157, 30);
            this.tsmEditModeVib.Text = "ビブラート";
            // 
            // tsmEditModeVibDep
            // 
            this.tsmEditModeVibDep.Image = global::PianoRoll.Properties.Resources.edit_vib_dep;
            this.tsmEditModeVibDep.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmEditModeVibDep.Name = "tsmEditModeVibDep";
            this.tsmEditModeVibDep.Size = new System.Drawing.Size(102, 30);
            this.tsmEditModeVibDep.Text = "深さ";
            this.tsmEditModeVibDep.Click += new System.EventHandler(this.tsmEditModeVibDep_Click);
            // 
            // tsmEditModeVibRate
            // 
            this.tsmEditModeVibRate.Image = global::PianoRoll.Properties.Resources.edit_vib_rate;
            this.tsmEditModeVibRate.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmEditModeVibRate.Name = "tsmEditModeVibRate";
            this.tsmEditModeVibRate.Size = new System.Drawing.Size(102, 30);
            this.tsmEditModeVibRate.Text = "速さ";
            this.tsmEditModeVibRate.Click += new System.EventHandler(this.tsmEditModeVibRate_Click);
            // 
            // toolStripSeparator10
            // 
            this.toolStripSeparator10.Name = "toolStripSeparator10";
            this.toolStripSeparator10.Size = new System.Drawing.Size(154, 6);
            // 
            // tsmEditModeDel
            // 
            this.tsmEditModeDel.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmEditModeDelDep,
            this.tsmEditModeDelTime});
            this.tsmEditModeDel.Image = global::PianoRoll.Properties.Resources.edit_del;
            this.tsmEditModeDel.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmEditModeDel.Name = "tsmEditModeDel";
            this.tsmEditModeDel.Size = new System.Drawing.Size(157, 30);
            this.tsmEditModeDel.Text = "ディレイ";
            // 
            // tsmEditModeDelDep
            // 
            this.tsmEditModeDelDep.Image = global::PianoRoll.Properties.Resources.edit_del_dep;
            this.tsmEditModeDelDep.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmEditModeDelDep.Name = "tsmEditModeDelDep";
            this.tsmEditModeDelDep.Size = new System.Drawing.Size(106, 30);
            this.tsmEditModeDelDep.Text = "深さ";
            this.tsmEditModeDelDep.Click += new System.EventHandler(this.tsmEditModeDelDep_Click);
            // 
            // tsmEditModeDelTime
            // 
            this.tsmEditModeDelTime.Image = global::PianoRoll.Properties.Resources.edit_del_time;
            this.tsmEditModeDelTime.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmEditModeDelTime.Name = "tsmEditModeDelTime";
            this.tsmEditModeDelTime.Size = new System.Drawing.Size(106, 30);
            this.tsmEditModeDelTime.Text = "間隔";
            this.tsmEditModeDelTime.Click += new System.EventHandler(this.tsmEditModeDelTime_Click);
            // 
            // tsmEditModeRev
            // 
            this.tsmEditModeRev.Image = global::PianoRoll.Properties.Resources.edit_rev;
            this.tsmEditModeRev.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmEditModeRev.Name = "tsmEditModeRev";
            this.tsmEditModeRev.Size = new System.Drawing.Size(157, 30);
            this.tsmEditModeRev.Text = "リバーブ";
            this.tsmEditModeRev.Click += new System.EventHandler(this.tsmEditModeRev_Click);
            // 
            // tsmEditModeCho
            // 
            this.tsmEditModeCho.Image = global::PianoRoll.Properties.Resources.edit_cho;
            this.tsmEditModeCho.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmEditModeCho.Name = "tsmEditModeCho";
            this.tsmEditModeCho.Size = new System.Drawing.Size(157, 30);
            this.tsmEditModeCho.Text = "コーラス";
            this.tsmEditModeCho.Click += new System.EventHandler(this.tsmEditModeCho_Click);
            // 
            // toolStripSeparator11
            // 
            this.toolStripSeparator11.Name = "toolStripSeparator11";
            this.toolStripSeparator11.Size = new System.Drawing.Size(154, 6);
            // 
            // tsmEditModeFc
            // 
            this.tsmEditModeFc.Image = global::PianoRoll.Properties.Resources.edit_fc;
            this.tsmEditModeFc.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmEditModeFc.Name = "tsmEditModeFc";
            this.tsmEditModeFc.Size = new System.Drawing.Size(157, 30);
            this.tsmEditModeFc.Text = "カットオフ";
            this.tsmEditModeFc.Click += new System.EventHandler(this.tsmEditModeFc_Click);
            // 
            // tsmEditModeFq
            // 
            this.tsmEditModeFq.Image = global::PianoRoll.Properties.Resources.edit_fq;
            this.tsmEditModeFq.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmEditModeFq.Name = "tsmEditModeFq";
            this.tsmEditModeFq.Size = new System.Drawing.Size(157, 30);
            this.tsmEditModeFq.Text = "レゾナンス";
            this.tsmEditModeFq.Click += new System.EventHandler(this.tsmEditModeFq_Click);
            // 
            // toolStripSeparator12
            // 
            this.toolStripSeparator12.Name = "toolStripSeparator12";
            this.toolStripSeparator12.Size = new System.Drawing.Size(154, 6);
            // 
            // tsmEditModeAttack
            // 
            this.tsmEditModeAttack.Image = global::PianoRoll.Properties.Resources.edit_attack;
            this.tsmEditModeAttack.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmEditModeAttack.Name = "tsmEditModeAttack";
            this.tsmEditModeAttack.Size = new System.Drawing.Size(157, 30);
            this.tsmEditModeAttack.Text = "立ち上がり時間";
            this.tsmEditModeAttack.Click += new System.EventHandler(this.tsmEditModeAttack_Click);
            // 
            // tsmEditModeRelease
            // 
            this.tsmEditModeRelease.Image = global::PianoRoll.Properties.Resources.edit_release;
            this.tsmEditModeRelease.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmEditModeRelease.Name = "tsmEditModeRelease";
            this.tsmEditModeRelease.Size = new System.Drawing.Size(157, 30);
            this.tsmEditModeRelease.Text = "持続時間";
            this.tsmEditModeRelease.Click += new System.EventHandler(this.tsmEditModeRelease_Click);
            // 
            // toolStripSeparator13
            // 
            this.toolStripSeparator13.Name = "toolStripSeparator13";
            this.toolStripSeparator13.Size = new System.Drawing.Size(154, 6);
            // 
            // tsmEditModeTempo
            // 
            this.tsmEditModeTempo.Image = global::PianoRoll.Properties.Resources.edit_tempo;
            this.tsmEditModeTempo.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmEditModeTempo.Name = "tsmEditModeTempo";
            this.tsmEditModeTempo.Size = new System.Drawing.Size(157, 30);
            this.tsmEditModeTempo.Text = "テンポ";
            this.tsmEditModeTempo.Click += new System.EventHandler(this.tsmEditModeTempo_Click);
            // 
            // tsdTimeDiv
            // 
            this.tsdTimeDiv.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsdTimeDiv.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmTick960,
            this.tsmTick480,
            this.tsmTick240,
            this.tsmTick120,
            this.tsmTick060,
            this.toolStripSeparator4,
            this.tsmTick640,
            this.tsmTick320,
            this.tsmTick160,
            this.tsmTick080,
            this.tsmTick040,
            this.toolStripSeparator5,
            this.tsmTick384,
            this.tsmTick192,
            this.tsmTick096,
            this.tsmTick048,
            this.tsmTick024});
            this.tsdTimeDiv.Image = global::PianoRoll.Properties.Resources.tick240;
            this.tsdTimeDiv.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsdTimeDiv.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsdTimeDiv.Name = "tsdTimeDiv";
            this.tsdTimeDiv.Size = new System.Drawing.Size(29, 28);
            this.tsdTimeDiv.Text = "入力単位";
            // 
            // tsmTick960
            // 
            this.tsmTick960.Image = global::PianoRoll.Properties.Resources.tick960;
            this.tsmTick960.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmTick960.Name = "tsmTick960";
            this.tsmTick960.Size = new System.Drawing.Size(116, 30);
            this.tsmTick960.Text = "4分";
            this.tsmTick960.Click += new System.EventHandler(this.tsmTick960_Click);
            // 
            // tsmTick480
            // 
            this.tsmTick480.Image = global::PianoRoll.Properties.Resources.tick480;
            this.tsmTick480.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmTick480.Name = "tsmTick480";
            this.tsmTick480.Size = new System.Drawing.Size(116, 30);
            this.tsmTick480.Text = "8分";
            this.tsmTick480.Click += new System.EventHandler(this.tsmTick480_Click);
            // 
            // tsmTick240
            // 
            this.tsmTick240.Checked = true;
            this.tsmTick240.CheckState = System.Windows.Forms.CheckState.Checked;
            this.tsmTick240.Image = global::PianoRoll.Properties.Resources.tick240;
            this.tsmTick240.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmTick240.Name = "tsmTick240";
            this.tsmTick240.Size = new System.Drawing.Size(116, 30);
            this.tsmTick240.Text = "16分";
            this.tsmTick240.Click += new System.EventHandler(this.tsmTick240_Click);
            // 
            // tsmTick120
            // 
            this.tsmTick120.Image = global::PianoRoll.Properties.Resources.tick120;
            this.tsmTick120.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmTick120.Name = "tsmTick120";
            this.tsmTick120.Size = new System.Drawing.Size(116, 30);
            this.tsmTick120.Text = "32分";
            this.tsmTick120.Click += new System.EventHandler(this.tsmTick120_Click);
            // 
            // tsmTick060
            // 
            this.tsmTick060.Image = global::PianoRoll.Properties.Resources.tick060;
            this.tsmTick060.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmTick060.Name = "tsmTick060";
            this.tsmTick060.Size = new System.Drawing.Size(116, 30);
            this.tsmTick060.Text = "64分";
            this.tsmTick060.Click += new System.EventHandler(this.tsmTick060_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(113, 6);
            // 
            // tsmTick640
            // 
            this.tsmTick640.Image = global::PianoRoll.Properties.Resources.tick640;
            this.tsmTick640.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmTick640.Name = "tsmTick640";
            this.tsmTick640.Size = new System.Drawing.Size(116, 30);
            this.tsmTick640.Text = "3連4分";
            this.tsmTick640.Click += new System.EventHandler(this.tsmTick640_Click);
            // 
            // tsmTick320
            // 
            this.tsmTick320.Image = global::PianoRoll.Properties.Resources.tick320;
            this.tsmTick320.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmTick320.Name = "tsmTick320";
            this.tsmTick320.Size = new System.Drawing.Size(116, 30);
            this.tsmTick320.Text = "3連8分";
            this.tsmTick320.Click += new System.EventHandler(this.tsmTick320_Click);
            // 
            // tsmTick160
            // 
            this.tsmTick160.Image = global::PianoRoll.Properties.Resources.tick160;
            this.tsmTick160.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmTick160.Name = "tsmTick160";
            this.tsmTick160.Size = new System.Drawing.Size(116, 30);
            this.tsmTick160.Text = "3連16分";
            this.tsmTick160.Click += new System.EventHandler(this.tsmTick160_Click);
            // 
            // tsmTick080
            // 
            this.tsmTick080.Image = global::PianoRoll.Properties.Resources.tick080;
            this.tsmTick080.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmTick080.Name = "tsmTick080";
            this.tsmTick080.Size = new System.Drawing.Size(116, 30);
            this.tsmTick080.Text = "3連32分";
            this.tsmTick080.Click += new System.EventHandler(this.tsmTick080_Click);
            // 
            // tsmTick040
            // 
            this.tsmTick040.Image = global::PianoRoll.Properties.Resources.tick040;
            this.tsmTick040.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmTick040.Name = "tsmTick040";
            this.tsmTick040.Size = new System.Drawing.Size(116, 30);
            this.tsmTick040.Text = "3連64分";
            this.tsmTick040.Click += new System.EventHandler(this.tsmTick040_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(113, 6);
            // 
            // tsmTick384
            // 
            this.tsmTick384.Image = global::PianoRoll.Properties.Resources.tick384;
            this.tsmTick384.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmTick384.Name = "tsmTick384";
            this.tsmTick384.Size = new System.Drawing.Size(116, 30);
            this.tsmTick384.Text = "5連4分";
            this.tsmTick384.Click += new System.EventHandler(this.tsmTick384_Click);
            // 
            // tsmTick192
            // 
            this.tsmTick192.Image = global::PianoRoll.Properties.Resources.tick192;
            this.tsmTick192.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmTick192.Name = "tsmTick192";
            this.tsmTick192.Size = new System.Drawing.Size(116, 30);
            this.tsmTick192.Text = "5連8分";
            this.tsmTick192.Click += new System.EventHandler(this.tsmTick192_Click);
            // 
            // tsmTick096
            // 
            this.tsmTick096.Image = global::PianoRoll.Properties.Resources.tick096;
            this.tsmTick096.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmTick096.Name = "tsmTick096";
            this.tsmTick096.Size = new System.Drawing.Size(116, 30);
            this.tsmTick096.Text = "5連16分";
            this.tsmTick096.Click += new System.EventHandler(this.tsmTick096_Click);
            // 
            // tsmTick048
            // 
            this.tsmTick048.Image = global::PianoRoll.Properties.Resources.tick048;
            this.tsmTick048.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmTick048.Name = "tsmTick048";
            this.tsmTick048.Size = new System.Drawing.Size(116, 30);
            this.tsmTick048.Text = "5連32分";
            this.tsmTick048.Click += new System.EventHandler(this.tsmTick048_Click);
            // 
            // tsmTick024
            // 
            this.tsmTick024.Image = global::PianoRoll.Properties.Resources.tick024;
            this.tsmTick024.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmTick024.Name = "tsmTick024";
            this.tsmTick024.Size = new System.Drawing.Size(116, 30);
            this.tsmTick024.Text = "5連64分";
            this.tsmTick024.Click += new System.EventHandler(this.tsmTick024_Click);
            // 
            // picRoll
            // 
            this.picRoll.Location = new System.Drawing.Point(3, 3);
            this.picRoll.Name = "picRoll";
            this.picRoll.Size = new System.Drawing.Size(344, 167);
            this.picRoll.TabIndex = 0;
            this.picRoll.TabStop = false;
            this.picRoll.MouseDown += new System.Windows.Forms.MouseEventHandler(this.picRoll_MouseDown);
            this.picRoll.MouseMove += new System.Windows.Forms.MouseEventHandler(this.picRoll_MouseMove);
            this.picRoll.MouseUp += new System.Windows.Forms.MouseEventHandler(this.picRoll_MouseUp);
            // 
            // toolStripSeparator15
            // 
            this.toolStripSeparator15.Name = "toolStripSeparator15";
            this.toolStripSeparator15.Size = new System.Drawing.Size(6, 31);
            // 
            // tslStatus
            // 
            this.tslStatus.Name = "tslStatus";
            this.tslStatus.Size = new System.Drawing.Size(86, 28);
            this.tslStatus.Text = "toolStripLabel1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(494, 279);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.pnlRoll);
            this.Name = "Form1";
            this.Text = "Form1";
            this.SizeChanged += new System.EventHandler(this.Form1_SizeChanged);
            this.pnlRoll.ResumeLayout(false);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picRoll)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picRoll;
        private System.Windows.Forms.Panel pnlRoll;
        private System.Windows.Forms.VScrollBar vScroll;
        private System.Windows.Forms.HScrollBar hScroll;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tsbSelect;
        private System.Windows.Forms.ToolStripButton tsbEventList;
        private System.Windows.Forms.ToolStripButton tsbRoll;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton tsbWrite;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripDropDownButton tsdTimeDiv;
        private System.Windows.Forms.ToolStripMenuItem tsmTick960;
        private System.Windows.Forms.ToolStripMenuItem tsmTick480;
        private System.Windows.Forms.ToolStripMenuItem tsmTick240;
        private System.Windows.Forms.ToolStripMenuItem tsmTick120;
        private System.Windows.Forms.ToolStripMenuItem tsmTick060;
        private System.Windows.Forms.ToolStripMenuItem tsmTick640;
        private System.Windows.Forms.ToolStripMenuItem tsmTick320;
        private System.Windows.Forms.ToolStripMenuItem tsmTick160;
        private System.Windows.Forms.ToolStripMenuItem tsmTick080;
        private System.Windows.Forms.ToolStripMenuItem tsmTick040;
        private System.Windows.Forms.ToolStripMenuItem tsmTick384;
        private System.Windows.Forms.ToolStripMenuItem tsmTick192;
        private System.Windows.Forms.ToolStripMenuItem tsmTick096;
        private System.Windows.Forms.ToolStripMenuItem tsmTick048;
        private System.Windows.Forms.ToolStripMenuItem tsmTick024;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ToolStripDropDownButton tsdEditMode;
        private System.Windows.Forms.ToolStripMenuItem tsmEditModeNote;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripMenuItem tsmEditModeVol;
        private System.Windows.Forms.ToolStripMenuItem tsmEditModeExp;
        private System.Windows.Forms.ToolStripMenuItem tsmEditModePan;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
        private System.Windows.Forms.ToolStripMenuItem tsmEditModePitch;
        private System.Windows.Forms.ToolStripMenuItem tsmEditModeVib;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator10;
        private System.Windows.Forms.ToolStripMenuItem tsmEditModeRev;
        private System.Windows.Forms.ToolStripMenuItem tsmEditModeDel;
        private System.Windows.Forms.ToolStripMenuItem tsmEditModeCho;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator11;
        private System.Windows.Forms.ToolStripMenuItem tsmEditModeFc;
        private System.Windows.Forms.ToolStripMenuItem tsmEditModeFq;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator12;
        private System.Windows.Forms.ToolStripMenuItem tsmEditModeAttack;
        private System.Windows.Forms.ToolStripMenuItem tsmEditModeRelease;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator13;
        private System.Windows.Forms.ToolStripMenuItem tsmEditModeTempo;
        private System.Windows.Forms.ToolStripMenuItem tsmEditModeVibDep;
        private System.Windows.Forms.ToolStripMenuItem tsmEditModeVibRate;
        private System.Windows.Forms.ToolStripMenuItem tsmEditModeDelDep;
        private System.Windows.Forms.ToolStripMenuItem tsmEditModeDelTime;
        private System.Windows.Forms.ToolStripMenuItem tsmEditModeInst;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator14;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator15;
        private System.Windows.Forms.ToolStripLabel tslStatus;
    }
}

