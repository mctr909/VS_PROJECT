#include <math.h>
#include <stdlib.h>
#include "dft.h"

/******************************************************************************/
int    _stop        = 1;
int    _stoped      = 1;
int    *_pBeginTbl  = NULL;
int    *_pBeginWave = NULL;
double *_pWaveBuff  = NULL;
double *_pTbl       = NULL;

/******************************************************************************/
void dft_init(double baseFreq, double sigma, int length, int notes, int octDiv, int sampleRate) {
	double pi = 4.0*atan(1.0);
	double sigma2 = sigma*sigma;

	_stop = 1;
	while(!_stoped) {
		sleep(10);
	}

	// release
	if (NULL != dft_pAmp) {
		free(dft_pAmp);
	}
	if (NULL != _pWaveBuff) {
		free(_pWaveBuff);
	}
	if (NULL != _pTbl) {
		free(_pTbl);
	}
	if (NULL != _pBeginTbl) {
		free(_pBeginTbl);
	}
	if (NULL != _pBeginWave) {
		free(_pBeginWave);
	}

	// create
	dft_pAmp    = (double*)malloc(sizeof(double)*notes);
	_pWaveBuff  = (double*)malloc(sizeof(double)*length);
	_pTbl       = (double*)malloc(sizeof(double)*notes*length*2);
	_pBeginTbl  = (int*)malloc(sizeof(int)*notes);
	_pBeginWave = (int*)malloc(sizeof(int)*notes);

	// clear
	memset(dft_pAmp, 0, sizeof(double)*notes);
	memset(_pWaveBuff, 0, sizeof(double)*length);

	// set value
	int idx = 0;
	for (int no=0; no<notes; ++no) {
		double w = baseFreq*pow(2.0, (double)no/octDiv) / sampleRate;
		double v = 2.0*sqrt(pi)*w/sigma;
		double mx = 0.0;
		_pBeginTbl[no] = idx;
		_pBeginWave[no] = 0;
		for (int t=0; t<length; ++t) {
			double pwt = pi*w*(2*t - length+1) / length;
			double ex = v * exp(-pwt*pwt/sigma2);
			if (mx < ex) {
				mx = ex;
			}
			if (mx < 1/32768.0) {
				_pBeginTbl[no] = idx;
				_pBeginWave[no] = t;
			}
			_pTbl[idx]   = cos(pwt) * ex / length;
			_pTbl[idx+1] = sin(pwt) * ex / length;
			idx += 2;
		}
	}

	dft_notes = notes;
	dft_length = length;
	_stop = 0;
	_stoped = 0;
}

int dft_exec(short *pInput, int samples, double gamma) {
	if (_stop) {
		_stoped = 1;
		return 0;
	}

	memcpy(_pWaveBuff, _pWaveBuff+samples, sizeof(double)*(dft_length-samples));
	for (int a=0; b=dft_length-samples; b<dft_length; a+=2; ++b) {
		_pWaveBuff[b] = (pInput[a] + pInput[a+1]) / 65536.0;
	}

	for (int no=0; no<dft_notes; ++no) {
		double re = 0.0;
		double im = 0.0;
		int end = dft_length - _pBeginWave[no];
		for (int t=_pBeginWave[no], u=_pBeginTbl[no]; t<end; ++t, u+=2) {
			re -= _pWaveBuff[t]*_pTbl[u];
			im += _pWaveBuff[t]*_pTbl[u+1];
		}
		re = sqrt(re*re + im*im);
		dft_pAmp[no] = (1.0 + gamma) * re / (re + gamma);
	}

	return 1;
}
