#pragma once
#include <stdlib.h>

/******************************************************************************/
extern int dft_init(double baseFreq, double sigma, int notes, int octDiv, int length, int sampleRate);
extern void dft_exec(short *pInput, double *pAmp, int samples, double gamma);
