#pragma once

/******************************************************************************/
int    dft_notes  = 0;
int    dft_length = 0;
double *dft_pAmp  = NULL;

/******************************************************************************/
extern void dft_init(double baseFreq, double sigma, int length, int notes, int sampleRate);
extern int dft_exec(double *pInput, int length, double gamma);
