#include "vec3.h"
#include "camera.h"
#include "objects.h"
#include <stdlib.h>
#include <stdio.h>

#pragma pack(push, 2)
typedef struct BITMAP_FILE {
    unsigned char id[2];
    unsigned int size;
    unsigned short reserved1;
    unsigned short reserved2;
    unsigned int offset;
} BITMAP_FILE;
#pragma pack(pop)

#pragma pack(push, 2)
typedef struct BITMAP_INFO {
    unsigned int size;
    unsigned int width;
    unsigned int height;
    unsigned short planes;
    unsigned short bits;
    unsigned int comp;
    unsigned int data_size;
    unsigned int pix_per_meter_x;
    unsigned int pix_per_meter_y;
    unsigned int clr_used;
    unsigned int clr_important;
} BITMAP_INFO;
#pragma pack(pop)

Hitable randomScene() {
    auto ret = Hitable();
    ret.add(new Sphere(vec3(0, -10000, 0), 10000, new Lambertian(vec3(0.25, 1.0, 0.75))));
    for (int a = -11; a < 11; a++) {
        for (int b = -11; b < 11; b++) {
            auto chooseMat = drand48();
            auto center = vec3(a + 0.9*drand48(), 0.2, b + 0.9*drand48());
            if (0.9 < !(center - vec3(4, 0.2, 0))) {
                if (chooseMat < 0.5) {
                    ret.add(new Sphere(center, 0.2,
                        new Lambertian(vec3(0.25, 1.0, 0.25))));
                } else {
                    ret.add(new Sphere(center, 0.2,
                        new Metal(vec3(0.26, 1.0, 0.66), 0.1)));
                }
            }
        }
    }
    ret.add(new Sphere(vec3(-4, 1, 0), 1.0, new Lambertian(vec3(0.25, 1.0, 0.25))));
    ret.add(new Sphere(vec3(0, 1, 3), 1.0, new Dielectric(100.0)));
    ret.add(new Sphere(vec3(4, 1, 0), 1.0, new Metal(vec3(0.26, 1.0, 0.66), 0.1)));
    return ret;
}

int main() {
    int nx = 200;
    int ny = 150;
    int ns = 200;

    int buff_size = sizeof(unsigned char) * nx * ny * 3;
    unsigned char *pBuff = (unsigned char *)malloc(buff_size);
    auto *pPix = pBuff;
    if (NULL == pBuff) {
        return 0;
    }

    auto world = randomScene();
    vec3 lookfrom(20, 2.25, 1.5);
    vec3 lookat(0, 0, 0);
    double dist_to_focus = 10.0;
    Camera cam(lookfrom, lookat, vec3(0, 1, 0), 20, double(nx) / double(ny), dist_to_focus);

    for (int py = 0; py < ny; py++) {
        for (int px = 0; px < nx; px++) {
            auto col = vec3();
            for (int s = 0; s < ns; s++) {
                auto u = double(px + drand48() - 0.5) / double(nx);
                auto v = double(py + drand48() - 0.5) / double(ny);
                auto r = cam.getRay(u, v);
                col += Hitable::color(r, world, 0);
            }
            col /= double(ns);
            if (col.x < 0.0) col.x = 0.0;
            if (1.0 < col.x) col.x = 1.0;
            if (col.y < 0.0) col.y = 0.0;
            if (1.0 < col.y) col.y = 1.0;
            if (col.z < 0.0) col.z = 0.0;
            if (1.0 < col.z) col.z = 1.0;
            col = vec3(sqrt(col.x), sqrt(col.y), sqrt(col.z));
            pPix[0] = unsigned char(255.99 * col.y);
            pPix[1] = unsigned char(255.99 * col.x);
            pPix[2] = unsigned char(255.99 * col.z);
            pPix += 3;
        }
    }

    BITMAP_FILE bf;
    bf.id[0] = 'B';
    bf.id[1] = 'M';
    bf.size = buff_size + 54;
    bf.reserved1 = 0;
    bf.reserved2 = 0;
    bf.offset = 54;

    BITMAP_INFO bi;
    bi.size = 40;
    bi.width = nx;
    bi.height = ny;
    bi.planes = 1;
    bi.bits = 24;
    bi.comp = 0;
    bi.data_size = buff_size;
    bi.pix_per_meter_x = 1000;
    bi.pix_per_meter_y = 1000;
    bi.clr_used = 0;
    bi.clr_important = 0;

    FILE *fp = NULL;
    fopen_s(&fp, "C:\\Users\\9004054911\\Desktop\\test.bmp", "wb");
    fwrite(&bf, sizeof(bf), 1, fp);
    fwrite(&bi, sizeof(bi), 1, fp);
    fwrite(pBuff, buff_size, 1, fp);
    fclose(fp);

    free(pBuff);
}
