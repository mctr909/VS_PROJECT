#pragma once
#include "vec3.h"
#include "material.h"

#include <vector>

//**************************************************************
class Hitable {
private:
    std::vector<Hitable*> mList;
public:
    void add(Hitable *list) {
        this->mList.push_back(list);
    }
    virtual bool hit(const Ray &ray, double r_min, double r_max, HitRecord &rec) const {
        HitRecord tempRec;
        bool hitAnything = false;
        double closestSoFar = r_max;
        for (int i = 0; i < mList.size(); i++) {
            if (mList[i]->hit(ray, r_min, closestSoFar, tempRec)) {
                hitAnything = true;
                closestSoFar = tempRec.r;
                rec = tempRec;
            }
        }
        return hitAnything;
    }
public:
    static vec3 color(const Ray& ray, const Hitable &world, int depth) {
        auto rec = HitRecord();
        if (world.hit(ray, 0.1, 10.0, rec)) {
            Ray scattered;
            auto attenuation = vec3();
            if (depth < 50 && rec.pMat->scatter(ray, rec, attenuation, scattered)) {
                return attenuation * color(scattered, world, depth + 1);
            }
            return vec3();
        }
        auto ud = ~- ray.dir;
        return vec3(1.0, 1.0, 1.0) * (1.0 - ud.y) + vec3(0.1, 0.1, 0.1) * ud.y;
    }
};

//**************************************************************
class Sphere : public Hitable {
private:
    vec3 mCenter;
    double mRadius;
    Material * mpMat;
public:
    Sphere(vec3 pos, double radius, Material *material) :
        mCenter(pos),
        mRadius(radius),
        mpMat(material) {}
public:
    bool hit(const Ray& ray, double r_min, double r_max, HitRecord& rec) const {
        // ray   : p(t) = A + tB
        // sphere: (p - c).(p - c) = r^2
        auto pc = ray.org - mCenter;
        auto a = ray.dir & ray.dir;
        auto b = pc & ray.dir;
        auto c = (pc & pc) - mRadius * mRadius;
        auto discriminant = b * b - a * c;
        if (0.0 < discriminant) {
            auto r = (-b - sqrt(discriminant)) / a;
            if (r_min < r && r < r_max) {
                rec.r = r;
                rec.pos = ray.pointAtPosition(r);
                rec.normal = (rec.pos - mCenter) / mRadius;
                rec.pMat = mpMat;
                return true;
            }
            r = (-b + sqrt(discriminant)) / a;
            if (r_min < r && r < r_max) {
                rec.r = r;
                rec.pos = ray.pointAtPosition(r);
                rec.normal = (rec.pos - mCenter) / mRadius;
                rec.pMat = mpMat;
                return true;
            }
        }
        return false;
    }
};
