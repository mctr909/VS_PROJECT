#pragma once
#include "vec3.h"

//**************************************************************
class Camera {
private:
    vec3 mOrigin;
    vec3 mLowerLeftCorner;
    vec3 mHorizontal;
    vec3 mVertical;
public:
    Camera(vec3 lookfrom, vec3 lookat, vec3 vup, double vfov, double aspect, double focusDist) {
        double theta = vfov * atan(1.0) / 45.0;
        double halfHeight = tan(theta / 2);
        double halfWidth = aspect * halfHeight;
        mOrigin = lookfrom;
        auto w = ~(lookfrom - lookat);
        auto u = ~(vup * w);
        auto v = w * u;
        mLowerLeftCorner = mOrigin - halfWidth * focusDist * u - halfHeight * focusDist * v - focusDist * w;
        mHorizontal = 2 * halfWidth * focusDist * u;
        mVertical = 2 * halfHeight * focusDist * v;
    }
public:
    Ray getRay(double s, double t) {
        return Ray(mOrigin, mLowerLeftCorner + s * mHorizontal + t * mVertical - mOrigin);
    }
};
