#pragma once
#include <math.h>

//**************************************************************
typedef struct vec3 {
    double x;
    double y;
    double z;
    vec3() {
        x = 0.0;
        y = 0.0;
        z = 0.0;
    }
    vec3(double px, double py, double pz) {
        x = px;
        y = py;
        z = pz;
    }
} vec3;

//**************************************************************
// add
void operator+=(vec3& ret, const vec3& v) {
    ret.x += v.x;
    ret.y += v.y;
    ret.z += v.z;
}
// sub
void operator-=(vec3& ret, const vec3& v) {
    ret.x -= v.x;
    ret.y -= v.y;
    ret.z -= v.z;
}
// cross product
void operator*=(vec3& ret, const vec3& v) {
    auto tx = ret.y * v.z - ret.z * v.y;
    auto ty = ret.z * v.x - ret.x * v.z;
    ret.z = ret.x * v.y - ret.y * v.x;
    ret.x = tx;
    ret.y = ty;
}
// scalar multiple
void operator*=(vec3& ret, double k) {
    ret.x *= k;
    ret.y *= k;
    ret.z *= k;
}
// scalar divide
void operator/=(vec3& ret, double k) {
    ret.x /= k;
    ret.y /= k;
    ret.z /= k;
}

// add
vec3 operator+(const vec3& a, const vec3& b) {
    return vec3(a.x + b.x, a.y + b.y, a.z + b.z);
}
// sub
vec3 operator-(const vec3& a, const vec3& b) {
    return vec3(a.x - b.x, a.y - b.y, a.z - b.z);
}
// cross product
vec3 operator*(const vec3& a, const vec3& b) {
    return vec3(
        a.y*b.z - a.z * b.y,
        a.z*b.x - a.x * b.z,
        a.x*b.y - a.y * b.x
    );
}
// scalar multiple
vec3 operator*(const vec3& v, double k) {
    return vec3(v.x * k, v.y * k, v.z * k);
}
// scalar multiple
vec3 operator*(double k, const vec3 &v) {
    return vec3(v.x * k, v.y * k, v.z * k);
}
// scalar divide
vec3 operator/(const vec3& v, double k) {
    return vec3(v.x / k, v.y / k, v.z / k);
}
// dot product
double operator&(const vec3& a, const vec3& b) {
    return a.x * b.x + a.y * b.y + a.z * b.z;
}

// inverse
vec3 operator-(const vec3& v) {
    return vec3(-v.x, -v.y, -v.z);
}
// normalize
vec3 operator~(const vec3& v) {
    double r = sqrt(v.x * v.x + v.y * v.y + v.z * v.z);
    if (0.0 < r) {
        return vec3(v.x / r, v.y / r, v.z / r);
    } else {
        return vec3();
    }
}
// norm
double operator!(const vec3& v) {
    return sqrt(v.x * v.x + v.y * v.y + v.z * v.z);
}

//**************************************************************
vec3 reflect(const vec3& v, const vec3& normal) {
    auto uv = ~v;
    auto n = ~normal;
    return (uv - 2.0 * (uv & n) * n) * !v;
}
bool refract(const vec3& v, const vec3& normal, double ni_over_nt, vec3& refracted) {
    auto uv = ~v;
    auto n = ~normal;
    double dt = uv & n;
    double discriminant = 1.0 - ni_over_nt * ni_over_nt * (1 - dt * dt);
    if (0.0 < discriminant) {
        refracted = (uv - n * dt) * ni_over_nt - n * sqrt(discriminant);
        return true;
    } else {
        return false;
    }
}

//**************************************************************
class Ray {
public:
    vec3 org;
    vec3 dir;
public:
    Ray() {}
    Ray(const vec3& pos, const vec3& dir) {
        this->org = pos;
        this->dir = dir;
    }
public:
    vec3 pointAtPosition(double r) const {
        return org + (r * dir);
    }
};
